# Reproducing

Three levels, in increasing order of what they need from you.

## Level 1 — no data, no GPU, a few minutes

Everything here runs on a deterministic synthetic scene rebuilt from the
Fig. 1 description. It establishes that the code implements the equations.

```bash
pip install -e ".[dev]"
pytest -q                       # 134 tests
svrdun verify-tables            # 70/70 consistency checks on the paper
svrdun recoverability           # Proposition 2(b) and 2(c)
svrdun figures -o outputs/figs  # Figs. 1 and 4, no dataset needed
svrdun run -c configs/quick.yaml
```

What this proves:

* `(BS)ᵀ` is **exactly** the adjoint of `BS`, and the torch and numpy
  operators agree to ~1e-9 in double precision;
* `ε_k` is non-increasing with `ε₀ = 1`, as equation (5) requires;
* equation (4)'s cumulative-sum identity matches a direct projection;
* the budget knob is monotone: raising `λ_ρ` never raises the mean rank;
* `σ_min(R D_k)` is zero beyond `k = L` and non-increasing in `k`;
* the network trains, resumes from a checkpoint, and its atoms stay
  orthonormal through the QR step of equation (18).

What it does **not** prove: anything about the paper's accuracy numbers.

## Level 2 — your own data, one GPU

```bash
# 1. put CAVE (or ICVL / KAIST) somewhere and fix the split
svrdun materialise-split CAVE /data/CAVE
svrdun verify-split splits/CAVE_split.json /data/CAVE

# 2. supply the measured Nikon D700 response
#    (edit configs/cave.yaml: data.response_file: /data/responses/nikon_d700.npy)

# 3. train, three seeds
for s in 1 2 3; do
  svrdun run -c configs/cave.yaml --seed $s --data-root /data/CAVE
done

# 4. cost on the paper's output size
svrdun cost -c configs/cave.yaml --size 512 \
    --checkpoint outputs/cave_seed1/checkpoint_last.pt
```

`FULL` runs follow Section V-C: 1000 / 120 / 300 epochs on CAVE / ICVL /
KAIST, batch 16, Adam at 4e-4 with cosine annealing. Training checkpoints
every epoch and resumes automatically, so a dropped session costs one epoch.

**Expect a gap.** The model here is written from equations (8)–(34), not the
authors' code, and the block widths are not published. Treat the paper's
values — carried in each config under `meta.reported_result` — as the target,
not as something this code will hit.

## Level 3 — the paired statistics

Table XIV's p-values, intervals and rank-biserial *r* need per-image values
for both methods under the same protocol. Produce them for each of the three
retrained baselines:

```
image_index, PSNR, ERGAS, SAM, UIQI      # one row per test image per seed
```

Then:

```python
from svrdun.stats import paired_comparison, holm_bonferroni

res = paired_comparison(ours_per_image, baseline_per_image,
                        dataset="CAVE", baseline="RASD-FuNet (retrained)",
                        metric="PSNR", higher_is_better=True,
                        per_image_per_seed_a=ours_img_x_seed,
                        per_image_per_seed_b=base_img_x_seed)
adj = holm_bonferroni([r.p_wilcoxon_raw for r in all_twelve])
```

Holm runs over the 3 baselines × 4 metrics = 12 comparisons **within each
dataset**, as the paper specifies. See [BASELINES.md](../BASELINES.md) for the
fair-comparison checklist.

## Running a whole table

```bash
# Table VI, the ablation study
for c in configs/ablation_*.yaml; do svrdun run -c "$c" --data-root /data/CAVE; done

# Table VII, sensitivity
for c in configs/sensitivity_*.yaml; do svrdun run -c "$c" --data-root /data/CAVE; done

# Table XI, the noise sweep
for c in configs/noise_*.yaml; do svrdun run -c "$c" --data-root /data/CAVE; done
```

Each config carries its published target under `meta.reported_result`, so a
run can be compared with the paper without looking anything up.

## Comparing two runs

```bash
svrdun manifest outputs/run_a -n MANIFEST_A
svrdun manifest outputs/run_b -n MANIFEST_B
diff outputs/run_a/MANIFEST_A.txt outputs/run_b/MANIFEST_B.txt
```

Identical SHA-256 for an artifact means bit-identical output. The reference
run in `outputs/reference_runs/` gives a fresh clone something to diff
against.
