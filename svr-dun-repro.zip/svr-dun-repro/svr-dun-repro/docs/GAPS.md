# Known gaps

Things this repository cannot reproduce from the paper alone, each with what
would close it. None of these is hidden in the code: every one has a
corresponding `_note`, caveat field or `NOT_RECOMPUTABLE` entry.

## In the paper

| Gap | Where it bites | What would close it |
|---|---|---|
| **"The last 12 images" has no stated ordering** (CAVE; likewise "last 10" for KAIST) | the test set differs if the authors ordered by dataset numbering rather than alphabetically | one sentence in Section V-A, or the authors' split file |
| **ICVL's 40 test scenes are drawn "at random" with no stated seed** | an exactly matching ICVL split cannot be rebuilt at all | the seed, or the split file |
| **Per-image metrics behind Table XIV are not published** | its p-values, 95% intervals and rank-biserial *r* cannot be recomputed | per-image CSVs for the three retrained baselines |
| **Learned-block widths are not published** | the parameter count cannot match the 0.714 M of Table V | the architecture's channel widths |
| **`mu`, the weight of the HRMSI term in (12)** | affects the DCM gradient step of (14) | its value |
| **UIQI sliding-window size** | UIQI is not comparable across implementations without it | the window size |
| **`lambda_s` and `lambda_R` of equations (33)–(34)** | joint response estimation is not reproducible as stated | their values |
| **Fig. 1's eight endmember spectra** | the motivating scene can only be reconstructed to spec, not reproduced | the spectra, or the scene file |

## In this repository

| Gap | Consequence |
|---|---|
| The model is a **reference implementation written from the equations**, not the authors' code | accuracy and parameter count differ; it is a comparator for structure, not for accuracy |
| Nikon D700 and Canon 60D responses are measured data and are not shipped | the camera rows of Tables VIII–XII need your own response files; `approximate_rgb_response` is a labelled stand-in, never a substitute |
| `L_omega` of equation (22) uses a gated directional scan rather than a selective state-space scan | same information flow, no Mamba dependency; not bit-equivalent to the paper's LSEA-style block |
| Baseline URLs and commits cannot be verified by this code | `configs/baselines.yaml` ships blank rather than carrying unverified links |
| Timing depends on hardware | only RTX 4090 measurements compare with Table V; every cost row records its device |
| FLOPs are **analytic** (equation 28), not profiled | a model of the cost, not a measurement of it |

## What is *not* a gap

Worth stating, because these are the parts that genuinely do reproduce:

* **The Gaussian sensors of Table XII.** Section V-J specifies them completely,
  so `gaussian_response` reproduces them exactly and the recoverability
  analysis is genuine linear algebra given the atoms.
* **Every arithmetic relation among the published tables.** All 70 checks pass:
  mean ± sd, all 18 mean Δ values, every interval, the Wilcoxon floors,
  QNR = (1 − D_λ)(1 − D_s), and Proposition 2(b)/(c) in Table XII.
* **The exact Wilcoxon floors.** 12 × 2/2¹² = 5.9×10⁻³ on CAVE,
  12 × 2/2¹⁰ = 2.3×10⁻² on KAIST, 2/2⁴⁰ = 1.8×10⁻¹² on ICVL — all three
  reproduce the paper's own statements, and the implementation agrees with
  SciPy on every tested case.
