# Provenance

This repository mixes three kinds of number, and the whole design exists to
keep them apart. A reproducibility repository that blurs them is worse than no
repository at all, because it makes transcribed values look reproduced.

## The three tags

| Tag | Meaning | Example |
|---|---|---|
| `COMPUTED` | Produced by running this code on real inputs, in this session. | a PSNR from `svrdun run`, a figure drawn from a scene |
| `REPORTED` | Transcribed from a table in the paper. **Not a reproduction.** | every value in `svrdun/reported.py` |
| `DERIVED_REPORTED` | Recomputed by this code, but from `REPORTED` inputs. The arithmetic is genuine; the inputs are transcribed. | Table XIII's mean ± sd, recomputed from its own per-seed values |

Every artifact written through `svrdun.provenance.Manifest` carries one of
these, and `MANIFEST.txt` counts them. A `REPORTED` entry must also name its
source — `Manifest.record` raises if it does not:

```python
man.record(path, REPORTED)                          # ValueError
man.record(path, REPORTED, source="Paper Table V")  # fine
```

## Why `DERIVED_REPORTED` is its own tag

Some checks are real arithmetic that happens to run on transcribed inputs.
Recomputing Table XIII's standard deviations from its own per-seed values is
a genuine calculation — it would catch a typo — but it is not a reproduction
of the experiment. Calling it `COMPUTED` would overstate it; calling it
`REPORTED` would understate it.

All 70 of these checks currently pass (`svrdun verify-tables`):

| Check | Count |
|---|---|
| Table XIII mean ± sd recomputed from per-seed values | 24 |
| Table XIV mean Δ equals the difference of Table XIII means | 18 |
| Every interval contains its point estimate and excludes zero | 18 |
| No Wilcoxon p below the exact floor after Holm over 12 | 3 |
| QNR = (1 − D_λ)(1 − D_s) | 1 |
| Table XII obeys Proposition 2(b) and 2(c) | 6 |

## What is deliberately *not* computed

Three columns of Table XIV cannot be recomputed from the paper, and the code
says so rather than approximating them:

| Quantity | Why not |
|---|---|
| `p (Wilcoxon)`, `p (paired t)` | need **per-image** values; the paper prints only dataset means per seed (Table XIII) |
| 95% bootstrap confidence intervals | the two-level bootstrap resamples test images |
| rank-biserial *r* | derived from per-image signed ranks |

`svrdun.verify.NOT_RECOMPUTABLE` carries this list, a reason and what would
make each one available. Supply per-image CSVs for the three retrained
baselines and `svrdun.stats.paired_comparison` produces all three columns —
see [BASELINES.md](../BASELINES.md).

## Stand-ins are named as stand-ins

`svrdun.responses.approximate_rgb_response` is a plausible broad RGB response
used for the QUICK path and for plots. It is **not** the Nikon D700, and
nothing computed with it is comparable with the paper. The function name, its
docstring and the config field `response: approx_rgb_stand_in` all say so.

The Gaussian sensors are the opposite case: Section V-J specifies them
completely ("equally spaced centres over 400–700 nm and a full width at half
maximum equal to the centre spacing"), so `gaussian_response` reproduces them
exactly and the Gaussian rows of Table XII are genuinely reproducible given
the atoms.

The synthetic scene is a **reconstruction** of the Fig. 1 scene from its
published description, not the authors' scene — their endmember spectra are
not published. `synthetic_scene()["_provenance_note"]` says this, and a test
asserts the note stays there.

## Manifests

```bash
svrdun manifest outputs/my_run        # hash a directory
```

A manifest records, for each artifact: relative path, SHA-256, size,
provenance, description and what produced it. It also captures the
environment (OS, Python, NumPy/SciPy/torch versions, CUDA, GPU model, full
`pip freeze`) and **hashes itself**, so tampering with the list shows up.

Recording the same path twice does not duplicate it; the later record wins, so
a file re-recorded after a change picks up its new hash.

## Reading a manifest

```
Counts by provenance
  COMPUTED           77
  DERIVED_REPORTED    6
  REPORTED            2
```

Two `REPORTED` entries is the expected number for a standard run: the
transcribed tables themselves, and the figure drawn from them. If a run shows
more, something that should have been computed was taken from the paper
instead.
