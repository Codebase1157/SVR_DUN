---
name: Reproduction gap
about: Something in the paper cannot be reproduced from what is published
labels: reproducibility
---

**What cannot be reproduced**

**What the paper states**
Quote the sentence and give the section or table.

**What is missing**
e.g. an ordering, a seed, per-image values, a hyperparameter.

**What would close it**

**Is it already listed?**
Check docs/GAPS.md — if it is there, say whether your case adds anything.
