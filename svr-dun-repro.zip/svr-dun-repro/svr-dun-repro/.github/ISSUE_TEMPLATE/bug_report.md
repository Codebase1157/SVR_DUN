---
name: Bug report
about: Something behaves differently from what the paper or the docs say
labels: bug
---

**What happened**

**What you expected**
If this is about a number, say which table or equation it should match.

**Provenance**
Which class is the output you are questioning? (`COMPUTED`, `REPORTED`,
`DERIVED_REPORTED` — see docs/PROVENANCE.md.) Transcribed values are not
reproductions; a mismatch against one may be expected.

**To reproduce**
```bash
svrdun ... # the exact command
```

**Environment**
Paste `environment.json` from the run's output directory, or:
```bash
python -c "import torch,sys;print(sys.version,torch.__version__,torch.cuda.is_available())"
```

**Config and split**
- config file used:
- split file SHA-256 (from `svrdun verify-split`):
