## What this changes

## Provenance

- [ ] Any new output is tagged `COMPUTED`, `REPORTED` or `DERIVED_REPORTED`
- [ ] Any value taken from the paper lives in `svrdun/reported.py` with a `_source`
- [ ] Any value the paper does not state carries a `_note` and appears in `docs/GAPS.md`

## Checks

- [ ] `pytest -q` passes
- [ ] `ruff check svrdun tests scripts` passes
- [ ] `svrdun verify-tables` still reports 70/70
- [ ] Configs regenerate identically (`make verify`)
