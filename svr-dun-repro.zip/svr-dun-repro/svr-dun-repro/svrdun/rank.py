"""Local spectral rank and the rank field estimator.

Equation (4)   e_k(p) = ||x_p||^2 - sum_{j<=k} (d_j^T x_p)^2
Equation (5)   eps_k(p) = sum_{q in N(p)} e_k(q) / sum_{q in N(p)} ||x_q||^2
Definition 1   delta-local spectral rank = min{ k : eps_k(p) <= delta }
Equation (15)  J_k(p) = eps_k(p) + lambda_rho * k
Equation (16)  soft-argmin over k with temperature kappa
Equation (32)  noise-aware residual, subtracting the floor (C-k) sigma^2

All of this is plain linear algebra on a cube, so it runs without torch and is
used both inside the network and for the standalone analyses (Fig. 1, Fig. 4).
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import uniform_filter

__all__ = ["ordered_atoms_from_cube", "squared_projections", "residual_curve",
           "windowed_relative_residual", "local_spectral_rank",
           "rank_cost", "soft_argmin_rank", "noise_aware_residual",
           "gate", "mean_rank"]


def ordered_atoms_from_cube(cube: np.ndarray, K: int) -> np.ndarray:
    """Leading K left singular vectors of the band-by-pixel matrix.

    This is U_{K_max}(Y_h) of equation (24) when applied to the LRHSI.
    Returns D of shape (C, K) with orthonormal columns in decreasing order of
    singular value, which is the ordering the paper's nested loss preserves.
    """
    a = np.asarray(cube, dtype=np.float64)
    X = a.reshape(-1, a.shape[2]).T                  # (C, N)
    U, S, _ = np.linalg.svd(X, full_matrices=False)
    return U[:, :K]


def squared_projections(cube: np.ndarray, D: np.ndarray) -> np.ndarray:
    """(d_j^T x_p)^2 for every pixel and atom. Returns (H, W, K)."""
    a = np.asarray(cube, dtype=np.float64)
    proj = np.einsum("hwc,ck->hwk", a, np.asarray(D, dtype=np.float64))
    return proj ** 2


def residual_curve(cube: np.ndarray, D: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Equation (4) for k = 0..K via one cumulative sum.

    Returns (e, energy) where e is (H, W, K+1) with e[..., 0] = ||x_p||^2.
    """
    a = np.asarray(cube, dtype=np.float64)
    energy = np.sum(a ** 2, axis=2)                  # (H, W)
    sq = squared_projections(a, D)                   # (H, W, K)
    cum = np.cumsum(sq, axis=2)
    e = energy[..., None] - cum                      # k = 1..K
    e = np.concatenate([energy[..., None], e], axis=2)
    return np.maximum(e, 0.0), energy


def _window_sum(arr: np.ndarray, w: int) -> np.ndarray:
    """Sum over a w x w window, applied to the leading two axes."""
    if w <= 1:
        return arr
    return uniform_filter(arr, size=(w, w) + (1,) * (arr.ndim - 2),
                          mode="nearest") * (w * w)


def windowed_relative_residual(cube: np.ndarray, D: np.ndarray, w: int = 8
                               ) -> np.ndarray:
    """Equation (5). Returns eps of shape (H, W, K+1) with eps[..., 0] = 1."""
    e, energy = residual_curve(cube, D)
    num = _window_sum(e, w)
    den = _window_sum(energy, w)[..., None]
    return num / np.maximum(den, 1e-12)


def noise_aware_residual(cube: np.ndarray, D: np.ndarray, sigma2: float,
                         w: int = 8, C: int | None = None) -> np.ndarray:
    """Equation (32): subtract the expected noise floor |N| (C-k) sigma^2."""
    a = np.asarray(cube, dtype=np.float64)
    C = C or a.shape[2]
    e, energy = residual_curve(a, D)
    K = e.shape[2] - 1
    num = _window_sum(e, w)
    den = _window_sum(energy, w)[..., None]
    n_win = float(w * w)
    ks = np.arange(0, K + 1, dtype=np.float64)
    floor = n_win * (C - ks) * float(sigma2)
    num = np.maximum(num - floor[None, None, :], 0.0)
    return num / np.maximum(den, 1e-12)


def local_spectral_rank(cube: np.ndarray, D: np.ndarray, delta: float = 2e-3,
                        w: int = 8, K_max: int | None = None) -> np.ndarray:
    """Definition 1: smallest k with eps_k(p) <= delta, clipped at K_max."""
    eps = windowed_relative_residual(cube, D, w)
    K = eps.shape[2] - 1
    K_max = K if K_max is None else min(K_max, K)
    below = eps[..., :K_max + 1] <= delta
    # first k (0-based index) where the tolerance is met; K_max if never
    idx = np.argmax(below, axis=2)
    never = ~below.any(axis=2)
    idx = np.where(never, K_max, idx)
    return idx.astype(np.float64)


def rank_cost(eps: np.ndarray, lambda_rho: float) -> np.ndarray:
    """Equation (15): J_k(p) = eps_k(p) + lambda_rho k, for k = 1..K."""
    K = eps.shape[2] - 1
    ks = np.arange(1, K + 1, dtype=np.float64)
    return eps[..., 1:] + lambda_rho * ks[None, None, :]


def soft_argmin_rank(J: np.ndarray, kappa: float = 1e-3) -> np.ndarray:
    """Equation (16): soft-argmin of J over k = 1..K with temperature kappa."""
    K = J.shape[2]
    ks = np.arange(1, K + 1, dtype=np.float64)
    z = -J / max(kappa, 1e-12)
    z = z - z.max(axis=2, keepdims=True)             # stabilise
    wts = np.exp(z)
    wts = wts / np.maximum(wts.sum(axis=2, keepdims=True), 1e-300)
    return np.einsum("hwk,k->hw", wts, ks)


def gate(rho: np.ndarray, k: int, tau: float = 0.05) -> np.ndarray:
    """Equation (9): g_k(rho) = sigmoid((rho - k + 1/2) / tau)."""
    z = (np.asarray(rho, dtype=np.float64) - k + 0.5) / max(tau, 1e-6)
    return 1.0 / (1.0 + np.exp(-np.clip(z, -60.0, 60.0)))


def mean_rank(rho: np.ndarray) -> float:
    """Mean rank over the image, the quantity reported in Tables V, VII, XI."""
    return float(np.mean(np.asarray(rho, dtype=np.float64)))
