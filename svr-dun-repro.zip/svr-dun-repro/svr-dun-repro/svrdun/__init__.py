"""SVR-DUN reproducibility package.

Reference implementation and verification tooling for "Learning Where Rank
Matters: Spatially-Varying-Rank Deep Unfolding for Budget-Adaptive
Hyperspectral and Multispectral Image Fusion".

Provenance is tracked explicitly throughout. See docs/PROVENANCE.md.
"""

__version__ = "0.1.0"

from .provenance import COMPUTED, DERIVED_REPORTED, REPORTED  # noqa: F401

__all__ = ["COMPUTED", "REPORTED", "DERIVED_REPORTED", "__version__"]
