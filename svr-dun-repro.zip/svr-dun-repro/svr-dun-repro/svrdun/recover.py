"""Local recoverability: Proposition 2, Corollary 1 and equation (30).

Proposition 2(a)  A_Omega is uniquely determined by the HRMSI iff
                  rank(R D_rho) = rho, i.e. R D_rho has full column rank.
Proposition 2(b)  rho <= L is necessary but NOT sufficient.
Proposition 2(c)  sigma_min(R D_j) >= sigma_min(R D_k) for every j <= k.
Equation (30)     the epsilon-recoverable rank of a response:
                  the largest k for which sigma_min(R D_k)/||R||_2 >= epsilon.
Equation (31)     the perturbation bound of Corollary 1.

This is exact linear algebra on a response R and an ordered atom set D, so it
is genuinely recomputable: given the same R and D it reproduces the columns of
Table XII. The paper's Table XII uses the CAVE atoms, which require the CAVE
dataset; with any other atom set the numbers will differ and the caller must
say which atoms were used.
"""
from __future__ import annotations

import numpy as np

__all__ = ["sigma_min_ratio", "recoverable_rank", "recoverability_table",
           "corollary1_bound", "windows_above_rank"]


def sigma_min_ratio(R: np.ndarray, D: np.ndarray, k: int) -> float:
    """sigma_min(R D_k) / ||R||_2 for the first k atoms."""
    R = np.asarray(R, dtype=np.float64)
    D = np.asarray(D, dtype=np.float64)
    L = R.shape[0]
    if k > L:
        return 0.0            # Proposition 2(b): more columns than rows
    M = R @ D[:, :k]
    sv = np.linalg.svd(M, compute_uv=False)
    rnorm = np.linalg.svd(R, compute_uv=False)[0]
    if sv.size < k:
        return 0.0
    return float(sv[-1] / max(rnorm, 1e-300))


def recoverable_rank(R: np.ndarray, D: np.ndarray, epsilon: float = 0.01,
                     K_max: int | None = None) -> int:
    """Equation (30): largest k with sigma_min(R D_k)/||R||_2 >= epsilon.

    With epsilon = 0 this is the largest rank satisfying Proposition 2(a).
    Returns 0 when even a single atom fails the test.
    """
    D = np.asarray(D, dtype=np.float64)
    K = D.shape[1] if K_max is None else min(K_max, D.shape[1])
    best = 0
    for k in range(1, K + 1):
        if sigma_min_ratio(R, D, k) >= epsilon:
            best = k
        else:
            break                 # non-increasing by Proposition 2(c)
    return best


def recoverability_table(responses: dict, D: np.ndarray, K_max: int = 6,
                         epsilon: float = 0.01,
                         atoms_description: str = "unspecified atoms") -> dict:
    """Recompute the structure of Table XII for a set of responses.

    `responses` maps a sensor name to its (L, C) matrix.
    """
    rows = []
    for name, R in responses.items():
        R = np.asarray(R, dtype=np.float64)
        sig = [sigma_min_ratio(R, D, k) for k in range(1, K_max + 1)]
        rows.append({
            "sensor": name,
            "L": int(R.shape[0]),
            "sigma": [round(s, 6) for s in sig],
            "recoverable_rank": recoverable_rank(R, D, epsilon, K_max),
            "zeros_beyond_L": all(sig[k] == 0.0 for k in range(K_max)
                                  if (k + 1) > R.shape[0]),
            "non_increasing": all(sig[i] >= sig[i + 1] - 1e-12
                                  for i in range(len(sig) - 1)),
        })
    return {
        "rows": rows, "epsilon": epsilon, "K_max": K_max,
        "atoms": atoms_description,
        "provenance": "COMPUTED",
        "note": ("Exact linear algebra on the given R and D. The paper's "
                 f"Table XII uses the CAVE atoms; these use {atoms_description}, "
                 "so the values are comparable in structure, not in magnitude."),
    }


def corollary1_bound(R: np.ndarray, D: np.ndarray, rho: int,
                     dR_norm: float, a_norm: float, n_norm: float) -> float:
    """Equation (31): the coefficient-error bound under response error.

        ||a_hat - a||_2 <= (||dR||_2 ||a||_2 + ||n||_2)
                           / (sigma_min(R D_rho) - ||dR||_2)

    Returns infinity when the denominator is non-positive, which is exactly
    the near-deficiency the paper warns about.
    """
    R = np.asarray(R, dtype=np.float64)
    D = np.asarray(D, dtype=np.float64)
    sv = np.linalg.svd(R @ D[:, :rho], compute_uv=False)
    s_min = float(sv[-1]) if sv.size >= rho else 0.0
    denom = s_min - float(dR_norm)
    if denom <= 0:
        return float("inf")
    return float((dR_norm * a_norm + n_norm) / denom)


def windows_above_rank(rho_field: np.ndarray, threshold: int) -> float:
    """Share of windows whose estimated rank exceeds `threshold`, in percent.

    This is the "windows above it (%)" column of Table XII.
    """
    r = np.asarray(rho_field, dtype=np.float64)
    return float(100.0 * np.mean(r > threshold + 1e-9))
