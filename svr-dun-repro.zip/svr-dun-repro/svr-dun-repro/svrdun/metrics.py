"""Evaluation metrics, implemented from the equations in the SVR-DUN paper.

PSNR  (35)   mean over bands of 10 log10( max(x^c)^2 / MSE_c ),  higher better
ERGAS (36)   100/s * sqrt( mean_c MSE_c / mean(x^c)^2 ),         lower better
SAM   (37)   mean over pixels of arccos(<x_p, xhat_p>/(|x||xhat|)) in degrees
UIQI  (38)   Q averaged over sliding windows and bands,          higher better
QNR   (39)   (1-D_lambda)^a (1-D_s)^b with a=b=1,                higher better

Cubes are (H, W, C) float arrays in [0, 1] unless stated otherwise.
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import uniform_filter

__all__ = ["psnr", "ergas", "sam", "uiqi", "d_lambda", "d_s", "qnr",
           "all_reference_metrics"]

_EPS = 1e-12


def _as_cube(x: np.ndarray) -> np.ndarray:
    a = np.asarray(x, dtype=np.float64)
    if a.ndim != 3:
        raise ValueError(f"expected (H, W, C) cube, got shape {a.shape}")
    return a


def psnr(ref: np.ndarray, est: np.ndarray) -> float:
    """Equation (35): band-wise PSNR using each band's own max as the peak."""
    ref, est = _as_cube(ref), _as_cube(est)
    C = ref.shape[2]
    vals = []
    for c in range(C):
        r = ref[:, :, c]
        e = est[:, :, c]
        mse = float(np.mean((r - e) ** 2))
        peak = float(np.max(r))
        if mse <= _EPS:
            vals.append(float("inf"))
        else:
            vals.append(10.0 * np.log10((peak ** 2) / mse))
    finite = [v for v in vals if np.isfinite(v)]
    if not finite:
        return float("inf")
    return float(np.mean(finite))


def ergas(ref: np.ndarray, est: np.ndarray, scale: int = 8) -> float:
    """Equation (36). `scale` is the spatial downsampling factor s."""
    ref, est = _as_cube(ref), _as_cube(est)
    C = ref.shape[2]
    acc = 0.0
    for c in range(C):
        r = ref[:, :, c]
        e = est[:, :, c]
        mse = float(np.mean((r - e) ** 2))
        mu = float(np.mean(r))
        acc += mse / max(mu ** 2, _EPS)
    return float(100.0 / scale * np.sqrt(acc / C))


def sam(ref: np.ndarray, est: np.ndarray, degrees: bool = True,
        ignore_zero: bool = True) -> float:
    """Equation (37), averaged over pixels."""
    ref, est = _as_cube(ref), _as_cube(est)
    a = ref.reshape(-1, ref.shape[2])
    b = est.reshape(-1, est.shape[2])
    na = np.linalg.norm(a, axis=1)
    nb = np.linalg.norm(b, axis=1)
    denom = na * nb
    valid = denom > _EPS if ignore_zero else np.ones_like(denom, dtype=bool)
    if not np.any(valid):
        return 0.0
    cos = np.sum(a[valid] * b[valid], axis=1) / denom[valid]
    cos = np.clip(cos, -1.0, 1.0)
    ang = np.arccos(cos)
    return float(np.degrees(np.mean(ang)) if degrees else np.mean(ang))


def _q_index(a: np.ndarray, b: np.ndarray, win: int) -> float:
    """Equation (38) averaged over sliding windows of one 2-D band."""
    a = a.astype(np.float64)
    b = b.astype(np.float64)
    mu_a = uniform_filter(a, win)
    mu_b = uniform_filter(b, win)
    maa = uniform_filter(a * a, win)
    mbb = uniform_filter(b * b, win)
    mab = uniform_filter(a * b, win)
    n = win * win
    corr = n / max(n - 1, 1)                      # unbiased sample moments
    var_a = np.maximum(corr * (maa - mu_a * mu_a), 0.0)
    var_b = np.maximum(corr * (mbb - mu_b * mu_b), 0.0)
    cov_ab = corr * (mab - mu_a * mu_b)
    num = 4.0 * cov_ab * mu_a * mu_b
    den = (var_a + var_b) * (mu_a ** 2 + mu_b ** 2)
    q = np.where(np.abs(den) < _EPS, 0.0, num / np.where(np.abs(den) < _EPS, 1.0, den))
    # trim the border where the window is not fully inside the image
    pad = win // 2
    if a.shape[0] > 2 * pad and a.shape[1] > 2 * pad:
        q = q[pad:a.shape[0] - pad, pad:a.shape[1] - pad]
    return float(np.mean(q))


def uiqi(ref: np.ndarray, est: np.ndarray, win: int = 32) -> float:
    """Equation (38), averaged over sliding windows and bands."""
    ref, est = _as_cube(ref), _as_cube(est)
    win = int(min(win, ref.shape[0], ref.shape[1]))
    return float(np.mean([_q_index(ref[:, :, c], est[:, :, c], win)
                          for c in range(ref.shape[2])]))


# ------------------------------------------------------------------ no-reference
def d_lambda(fused: np.ndarray, lrhsi: np.ndarray, win: int = 32, p: int = 1) -> float:
    """Spectral distortion of the QNR index (39).

    Compares inter-band Q values of the fused cube with those of the LRHSI.
    """
    f = _as_cube(fused)
    l = _as_cube(lrhsi)
    C = f.shape[2]
    if l.shape[2] != C:
        raise ValueError("fused and LRHSI must have the same number of bands")
    wf = int(min(win, f.shape[0], f.shape[1]))
    wl = int(min(win, l.shape[0], l.shape[1]))
    diffs = []
    for i in range(C):
        for j in range(i + 1, C):
            qf = _q_index(f[:, :, i], f[:, :, j], wf)
            ql = _q_index(l[:, :, i], l[:, :, j], wl)
            diffs.append(abs(qf - ql) ** p)
    if not diffs:
        return 0.0
    return float(np.mean(diffs) ** (1.0 / p))


def d_s(fused: np.ndarray, lrhsi: np.ndarray, hrmsi: np.ndarray,
        lr_hrmsi: np.ndarray, win: int = 32, q: int = 1) -> float:
    """Spatial distortion of the QNR index (39).

    `lr_hrmsi` is the HRMSI degraded to the LRHSI grid.
    """
    f = _as_cube(fused)
    l = _as_cube(lrhsi)
    m = _as_cube(hrmsi)
    ml = _as_cube(lr_hrmsi)
    C = f.shape[2]
    L = m.shape[2]
    wf = int(min(win, f.shape[0], f.shape[1]))
    wl = int(min(win, l.shape[0], l.shape[1]))
    diffs = []
    for c in range(C):
        for b in range(L):
            qf = _q_index(f[:, :, c], m[:, :, b], wf)
            ql = _q_index(l[:, :, c], ml[:, :, b], wl)
            diffs.append(abs(qf - ql) ** q)
    if not diffs:
        return 0.0
    return float(np.mean(diffs) ** (1.0 / q))


def qnr(dl: float, ds: float, a: float = 1.0, b: float = 1.0) -> float:
    """Equation (39) with a = b = 1 as used in the paper."""
    return float((1.0 - dl) ** a * (1.0 - ds) ** b)


def all_reference_metrics(ref: np.ndarray, est: np.ndarray, scale: int = 8,
                          win: int = 32) -> dict:
    return {
        "PSNR": psnr(ref, est),
        "ERGAS": ergas(ref, est, scale=scale),
        "SAM": sam(ref, est),
        "UIQI": uiqi(ref, est, win=win),
    }
