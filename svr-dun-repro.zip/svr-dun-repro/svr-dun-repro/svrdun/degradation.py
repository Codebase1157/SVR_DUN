"""Spatial and spectral degradation operators of equations (1) and (2).

    Y_h = X B S + N_h      blur, then keep one pixel in every s x s block
    Y_m = R X   + N_m      spectral response

Protocol of the paper (Section III-A / V-A): C = 31, s = 8, B is a Gaussian
blur of kernel size 8 and variance 3, and R is a camera response with L = 3.

Cubes are (H, W, C). Matrices follow the paper's band-by-pixel convention
X (C, N) where needed.
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import convolve1d

__all__ = ["gaussian_kernel", "blur_cube", "blur_cube_adjoint", "downsample",
           "upsample_bicubic", "apply_BS", "apply_BS_adjoint", "apply_R",
           "apply_R_adjoint", "simulate_pair", "add_noise_snr",
           "cube_to_matrix", "matrix_to_cube"]


def cube_to_matrix(cube: np.ndarray) -> np.ndarray:
    """(H, W, C) -> (C, N) band-by-pixel."""
    H, W, C = cube.shape
    return cube.reshape(-1, C).T


def matrix_to_cube(mat: np.ndarray, H: int, W: int) -> np.ndarray:
    """(C, N) -> (H, W, C)."""
    C = mat.shape[0]
    return mat.T.reshape(H, W, C)


def gaussian_kernel(size: int = 8, variance: float = 3.0) -> np.ndarray:
    """1-D Gaussian kernel of `size` taps with the given variance.

    For an even size the taps straddle the centre, which is the usual
    convention for an 8-tap kernel.
    """
    sigma = float(np.sqrt(variance))
    half = (size - 1) / 2.0
    x = np.arange(size, dtype=np.float64) - half
    k = np.exp(-0.5 * (x / sigma) ** 2)
    return k / k.sum()


def _psf2otf(k1d: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    """Optical transfer function of the separable kernel on an (H, W) grid.

    The kernel is placed so that its centre of mass sits at pixel (0, 0) under
    circular wrap-around, which is the standard convention for the circular
    boundary assumption of equation (13).
    """
    H, W = shape
    m = k1d.size
    psf = np.zeros((H, W), dtype=np.float64)
    psf[:m, :m] = np.outer(k1d, k1d)
    psf = np.roll(psf, -((m - 1) // 2), axis=0)
    psf = np.roll(psf, -((m - 1) // 2), axis=1)
    return np.fft.rfft2(psf)


def blur_cube(cube: np.ndarray, size: int = 8, variance: float = 3.0,
              mode: str = "wrap") -> np.ndarray:
    """Circular separable Gaussian blur, band by band (operator B).

    Implemented in the Fourier domain so that `blur_cube_adjoint` is its exact
    adjoint, which matters for the gradient step of equation (14) and for the
    circular boundary assumption under which (13) is exactly solvable.
    """
    a = np.asarray(cube, dtype=np.float64)
    if mode != "wrap":
        k = gaussian_kernel(size, variance)
        out = convolve1d(a, k, axis=0, mode=mode)
        return convolve1d(out, k, axis=1, mode=mode)
    H, W = a.shape[:2]
    otf = _psf2otf(gaussian_kernel(size, variance), (H, W))
    F = np.fft.rfft2(a, axes=(0, 1))
    return np.fft.irfft2(F * otf[..., None], s=(H, W), axes=(0, 1))


def blur_cube_adjoint(cube: np.ndarray, size: int = 8, variance: float = 3.0
                      ) -> np.ndarray:
    """Exact adjoint B^T of `blur_cube` under circular boundaries."""
    a = np.asarray(cube, dtype=np.float64)
    H, W = a.shape[:2]
    otf = _psf2otf(gaussian_kernel(size, variance), (H, W))
    F = np.fft.rfft2(a, axes=(0, 1))
    return np.fft.irfft2(F * np.conj(otf)[..., None], s=(H, W), axes=(0, 1))


def downsample(cube: np.ndarray, s: int = 8, offset: int = 0) -> np.ndarray:
    """S: keep one pixel in every s x s block."""
    return np.asarray(cube)[offset::s, offset::s, :]


def upsample_bicubic(cube: np.ndarray, s: int = 8) -> np.ndarray:
    """Up_s of equation (24): bicubic upsampling by s."""
    from scipy.ndimage import zoom
    c = np.asarray(cube, dtype=np.float64)
    return zoom(c, (s, s, 1), order=3, mode="grid-wrap")


def apply_BS(cube: np.ndarray, s: int = 8, size: int = 8,
             variance: float = 3.0) -> np.ndarray:
    """X -> X B S : blur then decimate."""
    return downsample(blur_cube(cube, size, variance), s)


def apply_BS_adjoint(lr_cube: np.ndarray, s: int = 8, size: int = 8,
                     variance: float = 3.0, out_hw: tuple | None = None) -> np.ndarray:
    """(BS)^T : zero-fill upsample then blur with the transposed kernel.

    The Gaussian kernel is symmetric, so the transposed blur equals the blur.
    """
    lr = np.asarray(lr_cube, dtype=np.float64)
    h, w, C = lr.shape
    H, W = (out_hw if out_hw is not None else (h * s, w * s))
    up = np.zeros((H, W, C), dtype=np.float64)
    hh = min(h, len(range(0, H, s)))
    ww = min(w, len(range(0, W, s)))
    up[:hh * s:s, :ww * s:s, :] = lr[:hh, :ww, :]
    return blur_cube_adjoint(up, size, variance)


def apply_R(cube: np.ndarray, R: np.ndarray) -> np.ndarray:
    """X -> R X. `cube` is (H, W, C), `R` is (L, C); returns (H, W, L)."""
    c = np.asarray(cube, dtype=np.float64)
    return np.einsum("lc,hwc->hwl", np.asarray(R, dtype=np.float64), c)


def apply_R_adjoint(msi: np.ndarray, R: np.ndarray) -> np.ndarray:
    """Y -> R^T Y. `msi` is (H, W, L); returns (H, W, C)."""
    m = np.asarray(msi, dtype=np.float64)
    return np.einsum("lc,hwl->hwc", np.asarray(R, dtype=np.float64), m)


def add_noise_snr(x: np.ndarray, snr_db: float | None,
                  rng: np.random.Generator | None = None) -> np.ndarray:
    """Additive white Gaussian noise at the given SNR in dB (None = noise-free).

    SNR is defined on the signal power of the whole cube, matching the
    noise study of Table XI.
    """
    if snr_db is None or not np.isfinite(snr_db):
        return np.asarray(x, dtype=np.float64)
    rng = rng or np.random.default_rng(0)
    a = np.asarray(x, dtype=np.float64)
    sig_p = float(np.mean(a ** 2))
    noise_p = sig_p / (10.0 ** (snr_db / 10.0))
    return a + rng.normal(0.0, np.sqrt(noise_p), size=a.shape)


def simulate_pair(hrhsi: np.ndarray, R: np.ndarray, s: int = 8,
                  blur_size: int = 8, blur_var: float = 3.0,
                  snr_db: float | None = None,
                  rng: np.random.Generator | None = None) -> dict:
    """Build (Y_h, Y_m) from a reference HRHSI, equations (1) and (2).

    The cube is expected already normalised to [0, 1] by its maximum, as in
    Section V-A.
    """
    rng = rng or np.random.default_rng(0)
    X = np.asarray(hrhsi, dtype=np.float64)
    Yh = apply_BS(X, s=s, size=blur_size, variance=blur_var)
    Ym = apply_R(X, R)
    if snr_db is not None and np.isfinite(snr_db):
        Yh = add_noise_snr(Yh, snr_db, rng)
        Ym = add_noise_snr(Ym, snr_db, rng)
    return {"Yh": Yh, "Ym": Ym, "X": X, "R": np.asarray(R, dtype=np.float64),
            "s": s, "blur_size": blur_size, "blur_var": blur_var,
            "snr_db": snr_db}
