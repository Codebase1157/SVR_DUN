"""SVR-DUN, implemented from the equations of the paper.

REFERENCE IMPLEMENTATION, written from Sections III-IV of
"Learning Where Rank Matters: Spatially-Varying-Rank Deep Unfolding ...".
It is not the authors' original code and has not been trained to their
schedule, so numbers produced by it are this repository's own, not the
paper's. Equation numbers in the comments refer to the paper.

Stage t maps (Z^t, D^t, rho^t, E^t) -> (Z^t+1, D^t+1, rho^t+1, E^t+1) through
five modules:

    DCM   (14)  one learned gradient step on the data term
    RFE   (15)-(17), optionally (32)  rank field from an explicit criterion
    OAU   (18)  ordered atom update, QR-restored
    RGCP  (19)-(20)  rank-gated, window-masked coefficient update
    IM    (21)-(22)  sparse innovation, gated at rank saturation
    comp  (23)  rebuild Z

Weights are shared across stages (the paper notes SVR-DUN's stages share
weights); only the scalar step sizes alpha_t, soft-threshold theta_t and noise
factors nu_t are per-stage, matching "alpha_t is a step size learned separately
for each stage".

Tensor layout is NCHW:  X (B,C,H,W), A (B,K,H,W), rho (B,1,H,W), D (B,C,K).
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


# ------------------------------------------------------------------- config
@dataclass
class SVRDUNConfig:
    C: int = 31                 # hyperspectral bands
    L: int = 3                  # multispectral bands
    K_max: int = 6              # maximum rank (Section V-C)
    T: int = 5                  # unfolded stages
    w: int = 8                  # window size, equals s
    s: int = 8                  # spatial scale factor
    blur_size: int = 8
    blur_var: float = 3.0
    gamma_mask: float = 0.05    # gamma of (19)
    kappa: float = 1e-3         # soft-argmin temperature of (16)
    tau_start: float = 1.0      # gate temperature schedule (9)
    tau_end: float = 0.05
    mu: float = 1.0             # weight of the HRMSI term in (12)/(14)
    width: int = 32             # channel width of the learned blocks
    film_hidden: int = 32
    noise_aware: bool = False   # enable (32)
    use_innovation: bool = True
    use_dcm: bool = True
    use_tv: bool = True
    lambda_rho_default: float = 1e-3

    def as_dict(self):
        return asdict(self)


# --------------------------------------------------------------- utilities
def film_apply(h: torch.Tensor, gamma: torch.Tensor, beta: torch.Tensor):
    """Equation (25): h <- gamma(lambda_rho) * h + beta(lambda_rho)."""
    return h * gamma.unsqueeze(-1).unsqueeze(-1) + beta.unsqueeze(-1).unsqueeze(-1)


class FiLM(nn.Module):
    """Small perceptron producing (gamma, beta) from log10(lambda_rho)."""

    def __init__(self, n_channels: int, hidden: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(1, hidden), nn.SiLU(), nn.Linear(hidden, 2 * n_channels)
        )
        self.n = n_channels
        nn.init.zeros_(self.net[-1].weight)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, lam: torch.Tensor):
        z = torch.log10(lam.clamp_min(1e-12)).view(-1, 1)
        out = self.net(z)
        gamma, beta = out[:, : self.n], out[:, self.n:]
        return 1.0 + gamma, beta


def box_filter(x: torch.Tensor, w: int) -> torch.Tensor:
    """Sum over a w x w window with replicate padding (the box filter of (5))."""
    if w <= 1:
        return x
    pad = w // 2
    x = F.pad(x, (pad, w - 1 - pad, pad, w - 1 - pad), mode="replicate")
    return F.avg_pool2d(x, kernel_size=w, stride=1) * (w * w)


def window_max(x: torch.Tensor, w: int) -> torch.Tensor:
    """Max over non-overlapping w x w windows, broadcast back (equation 19)."""
    B, Ck, H, W = x.shape
    ph, pw = (-H) % w, (-W) % w
    if ph or pw:
        x = F.pad(x, (0, pw, 0, ph), mode="replicate")
    pooled = F.max_pool2d(x, kernel_size=w, stride=w)
    up = F.interpolate(pooled, scale_factor=w, mode="nearest")
    return up[:, :, :H, :W]


def gaussian_kernel_2d(size: int, variance: float, device, dtype):
    sigma = math.sqrt(variance)
    half = (size - 1) / 2.0
    x = torch.arange(size, device=device, dtype=dtype) - half
    k = torch.exp(-0.5 * (x / sigma) ** 2)
    k = k / k.sum()
    return torch.outer(k, k)


# ----------------------------------------------------------------- modules
class ObservationOperators(nn.Module):
    """B, S and R as network layers (Section IV-D1).

    X -> X B S is a depthwise convolution with stride s; its adjoint is the
    matching transposed convolution. R is a 1x1 convolution from C to L.
    """

    def __init__(self, cfg: SVRDUNConfig):
        super().__init__()
        self.cfg = cfg
        # built at float64 so that a .double() model inherits a full-precision
        # kernel rather than float32-rounded values silently upcast
        k = gaussian_kernel_2d(cfg.blur_size, cfg.blur_var,
                               torch.device("cpu"), torch.float64)
        self.register_buffer("blur", k.view(1, 1, cfg.blur_size, cfg.blur_size))
        self.register_buffer("R", torch.zeros(cfg.L, cfg.C))

    def set_response(self, R: torch.Tensor):
        self.R.copy_(R.to(self.R.device, self.R.dtype))

    def _otf(self, H: int, W: int, device, dtype):
        """Optical transfer function of B on an (H, W) grid.

        The blur is applied as a circular convolution in the Fourier domain so
        that `BS_adj` is its EXACT adjoint. F.conv2d is cross-correlation, and
        for an even-length kernel the two differ by a half-pixel shift, which
        silently breaks the gradient step of (14); the FFT form avoids that
        and matches the numpy operators in svrdun.degradation exactly.
        """
        m = self.cfg.blur_size
        psf = torch.zeros(H, W, device=device, dtype=dtype)
        psf[:m, :m] = self.blur[0, 0].to(device=device, dtype=dtype)
        psf = torch.roll(psf, shifts=(-((m - 1) // 2), -((m - 1) // 2)), dims=(0, 1))
        return torch.fft.rfft2(psf)

    def _blur(self, x: torch.Tensor, conj: bool = False) -> torch.Tensor:
        H, W = x.shape[-2:]
        # work in the input's own precision: hardcoding float32 here would
        # silently downcast a float64 model and defeat `.double()`
        work = x.dtype if x.dtype in (torch.float32, torch.float64) else torch.float32
        otf = self._otf(H, W, x.device, work)
        if conj:
            otf = torch.conj(otf)
        Xf = torch.fft.rfft2(x.to(work))
        out = torch.fft.irfft2(Xf * otf.unsqueeze(0).unsqueeze(0), s=(H, W))
        return out.to(x.dtype)

    def BS(self, x: torch.Tensor) -> torch.Tensor:
        return self._blur(x, conj=False)[:, :, ::self.cfg.s, ::self.cfg.s]

    def BS_adj(self, y: torch.Tensor, out_hw) -> torch.Tensor:
        C = y.shape[1]
        H, W = out_hw
        s = self.cfg.s
        up = y.new_zeros(y.shape[0], C, H, W)
        nh, nw = len(range(0, H, s)), len(range(0, W, s))
        up[:, :, ::s, ::s] = y[:, :, :nh, :nw]
        return self._blur(up, conj=True)

    def Rop(self, x: torch.Tensor) -> torch.Tensor:
        return F.conv2d(x, self.R.to(x.dtype).view(self.cfg.L, self.cfg.C, 1, 1))

    def R_adj(self, y: torch.Tensor) -> torch.Tensor:
        return F.conv2d(y, self.R.to(y.dtype).t().contiguous()
                        .view(self.cfg.C, self.cfg.L, 1, 1))


class TVProx(nn.Module):
    """T_theta of (17): two-layer depthwise convolution predicting a TV correction."""

    def __init__(self, cfg: SVRDUNConfig):
        super().__init__()
        self.c1 = nn.Conv2d(1, cfg.width, 3, padding=1)
        self.c2 = nn.Conv2d(cfg.width, 1, 3, padding=1)
        self.film = FiLM(cfg.width, cfg.film_hidden)
        nn.init.zeros_(self.c2.weight)
        nn.init.zeros_(self.c2.bias)

    def forward(self, rho, lam):
        g, b = self.film(lam)
        h = F.silu(film_apply(self.c1(rho), g, b))
        return self.c2(h)


class AtomMLP(nn.Module):
    """U_psi of (18): a small two-layer perceptron applied to each atom column."""

    def __init__(self, cfg: SVRDUNConfig):
        super().__init__()
        hid = max(2 * cfg.C, 32)
        self.l1 = nn.Linear(cfg.C, hid)
        self.l2 = nn.Linear(hid, cfg.C)
        self.film = FiLM(hid, cfg.film_hidden)
        nn.init.zeros_(self.l2.weight)
        nn.init.zeros_(self.l2.bias)

    def forward(self, cols, lam):          # cols (B, K, C)
        g, b = self.film(lam)
        h = self.l1(cols)
        h = F.silu(h * g.unsqueeze(1) + b.unsqueeze(1))
        return self.l2(h)


class CoeffProx(nn.Module):
    """P_phi of (20): a light convolutional proximal operator on coefficient maps."""

    def __init__(self, cfg: SVRDUNConfig):
        super().__init__()
        K = cfg.K_max
        self.c1 = nn.Conv2d(K, cfg.width, 3, padding=1)
        self.c2 = nn.Conv2d(cfg.width, cfg.width, 3, padding=1)
        self.c3 = nn.Conv2d(cfg.width, K, 3, padding=1)
        self.film = FiLM(cfg.width, cfg.film_hidden)
        nn.init.zeros_(self.c3.weight)
        nn.init.zeros_(self.c3.bias)

    def forward(self, A, lam):
        g, b = self.film(lam)
        h = F.silu(film_apply(self.c1(A), g, b))
        h = F.silu(self.c2(h))
        return A + self.c3(h)


class InnovationBlock(nn.Module):
    """L_omega of (22): spectral self-attention plus a directional scan.

    The paper uses spectral self-attention combined with a selective
    state-space scan, in the style of the LSEA module of [6]. A full selective
    scan is replaced here by a lightweight gated directional accumulation,
    which keeps the same information flow (global along each axis, content
    gated) without a Mamba dependency.
    """

    def __init__(self, cfg: SVRDUNConfig):
        super().__init__()
        C, wdt = cfg.C, cfg.width
        self.norm = nn.GroupNorm(1, C)
        self.qkv = nn.Conv2d(C, 3 * C, 1)
        self.proj = nn.Conv2d(C, C, 1)
        self.scan_in = nn.Conv2d(C, wdt, 1)
        self.scan_gate = nn.Conv2d(wdt, wdt, 1)
        self.scan_out = nn.Conv2d(wdt, C, 1)
        self.film = FiLM(wdt, cfg.film_hidden)
        nn.init.zeros_(self.proj.weight); nn.init.zeros_(self.proj.bias)
        nn.init.zeros_(self.scan_out.weight); nn.init.zeros_(self.scan_out.bias)

    @staticmethod
    def _scan(h, gate, dim):
        """Gated causal accumulation along one spatial axis (both directions)."""
        a = torch.sigmoid(gate)
        fwd = torch.cumsum(h * a, dim=dim) / (torch.cumsum(a, dim=dim) + 1e-6)
        rev = torch.flip(
            torch.cumsum(torch.flip(h * a, [dim]), dim=dim)
            / (torch.cumsum(torch.flip(a, [dim]), dim=dim) + 1e-6), [dim])
        return 0.5 * (fwd + rev)

    def forward(self, q, lam):
        B, C, H, W = q.shape
        x = self.norm(q)
        # spectral self-attention: bands attend to bands
        qkv = self.qkv(x).reshape(B, 3, C, H * W)
        qq, kk, vv = qkv[:, 0], qkv[:, 1], qkv[:, 2]
        qn = F.normalize(qq, dim=-1)
        kn = F.normalize(kk, dim=-1)
        attn = torch.softmax(qn @ kn.transpose(-2, -1) / math.sqrt(C), dim=-1)
        out = (attn @ vv).reshape(B, C, H, W)
        out = self.proj(out)
        # gated directional scan
        g, b = self.film(lam)
        h = film_apply(self.scan_in(x), g, b)
        gate = self.scan_gate(h)
        h = self._scan(h, gate, dim=2) + self._scan(h, gate, dim=3)
        return out + self.scan_out(h)


# ------------------------------------------------------------------- model
class SVRDUN(nn.Module):
    def __init__(self, cfg: SVRDUNConfig | None = None, **kw):
        super().__init__()
        self.cfg = cfg or SVRDUNConfig(**kw)
        c = self.cfg
        self.ops = ObservationOperators(c)
        # shared learned blocks
        self.tv = TVProx(c)
        self.atom = AtomMLP(c)
        self.coeff = CoeffProx(c)
        self.inn = InnovationBlock(c) if c.use_innovation else None
        # per-stage scalars
        self.alpha = nn.Parameter(torch.full((c.T,), 0.1))
        self.log_theta = nn.Parameter(torch.full((c.T,), math.log(1e-3)))
        self.nu = nn.Parameter(torch.zeros(c.T))
        self.register_buffer("tau", torch.tensor(c.tau_end))

    # ------------------------------------------------------- helpers
    def set_tau(self, tau: float):
        self.tau.fill_(float(tau))

    @staticmethod
    def tau_schedule(step: int, total: int, t0: float, t1: float) -> float:
        """Cosine anneal of the gate temperature from t0 to t1 (Section V-C)."""
        if total <= 1:
            return t1
        p = min(max(step / (total - 1), 0.0), 1.0)
        return t1 + 0.5 * (t0 - t1) * (1.0 + math.cos(math.pi * p))

    def gates(self, rho: torch.Tensor) -> torch.Tensor:
        """Equation (9) for k = 1..K_max. rho (B,1,H,W) -> (B,K,H,W)."""
        k = torch.arange(1, self.cfg.K_max + 1, device=rho.device,
                         dtype=rho.dtype).view(1, -1, 1, 1)
        return torch.sigmoid((rho - k + 0.5) / self.tau.clamp_min(1e-6))

    def _eps(self, X, D, sigma2=None):
        """Equations (4)-(5), or (32) when sigma2 is given. Returns (B,K+1,H,W)."""
        B, C, H, W = X.shape
        proj = torch.einsum("bchw,bck->bkhw", X, D)      # d_j^T x_p
        sq = proj ** 2
        energy = (X ** 2).sum(dim=1, keepdim=True)       # ||x_p||^2
        e = energy - torch.cumsum(sq, dim=1)             # k = 1..K
        e = torch.cat([energy, e], dim=1).clamp_min(0.0)
        num = box_filter(e, self.cfg.w)
        den = box_filter(energy, self.cfg.w)
        if sigma2 is not None:
            ks = torch.arange(0, self.cfg.K_max + 1, device=X.device,
                              dtype=X.dtype).view(1, -1, 1, 1)
            floor = (self.cfg.w ** 2) * (C - ks) * sigma2.view(-1, 1, 1, 1)
            num = (num - floor).clamp_min(0.0)
        return num / den.clamp_min(1e-12)

    # ------------------------------------------------------- one stage
    def stage(self, t, Z, D, rho, E, Yh, Ym, lam, sigma2=None):
        c = self.cfg
        B, C, H, W = Z.shape

        # --- DCM, equation (14)
        if c.use_dcm:
            g_h = self.ops.BS_adj(self.ops.BS(Z) - Yh, (H, W))
            g_m = self.ops.R_adj(self.ops.Rop(Z) - Ym)
            X = Z - self.alpha[t] * (g_h + c.mu * g_m)
        else:
            X = Z

        # --- RFE, equations (15)-(17) (or (32) when noise-aware)
        s2 = None
        if c.noise_aware and sigma2 is not None:
            s2 = F.softplus(self.nu[t]) * sigma2
        eps = self._eps(X, D, s2)
        ks = torch.arange(1, c.K_max + 1, device=X.device,
                          dtype=X.dtype).view(1, -1, 1, 1)
        J = eps[:, 1:] + lam.view(-1, 1, 1, 1) * ks          # (15)
        wts = torch.softmax(-J / max(c.kappa, 1e-12), dim=1)  # (16)
        rho_t = (wts * ks).sum(dim=1, keepdim=True)
        if c.use_tv:
            rho_t = rho_t - self.tv(rho_t, lam)               # (17)
        rho = rho_t.clamp(0.0, float(c.K_max))

        # --- OAU, equation (18)
        Xf = X.reshape(B, C, -1)
        Sigma = Xf @ Xf.transpose(1, 2) / Xf.shape[-1]
        SD = torch.einsum("bcd,bdk->bck", Sigma, D)
        upd = self.atom(SD.transpose(1, 2), lam).transpose(1, 2)
        Dn = D + upd
        Q, Rr = torch.linalg.qr(Dn.to(torch.float32))
        sign = torch.sign(torch.diagonal(Rr, dim1=-2, dim2=-1)).unsqueeze(1)
        sign = torch.where(sign == 0, torch.ones_like(sign), sign)
        D = (Q * sign).to(D.dtype)                            # order preserved

        # --- RGCP, equations (19)-(20)
        G = self.gates(rho)
        M = (window_max(G, c.w) > c.gamma_mask).to(X.dtype)    # (19)
        A_ls = torch.einsum("bck,bchw->bkhw", D, X - E)        # least squares
        A = M * self.coeff(A_ls, lam)                          # (20)

        # --- IM, equations (21)-(22)
        low = torch.einsum("bck,bkhw->bchw", D, G * A)
        if c.use_innovation and self.inn is not None:
            Qres = X - low                                      # (21)
            g_inn = torch.sigmoid((rho - c.K_max + 0.5)
                                  / self.tau.clamp_min(1e-6))
            th = torch.exp(self.log_theta[t])
            soft = torch.sign(Qres) * (Qres.abs() - th).clamp_min(0.0)
            E = g_inn * (soft + self.inn(Qres, lam))            # (22)
        else:
            E = torch.zeros_like(X)

        Z = low + E                                             # (23)
        return Z, D, rho, E

    # --------------------------------------------------------- forward
    def forward(self, Yh, Ym, R=None, lambda_rho=None, sigma2=None,
                out_hw=None, return_aux=False):
        """Yh (B,C,h,w), Ym (B,L,H,W) -> fused (B,C,H,W) and the rank field."""
        c = self.cfg
        if R is not None:
            self.ops.set_response(R if R.dim() == 2 else R[0])
        B = Yh.shape[0]
        H, W = out_hw if out_hw is not None else Ym.shape[-2:]
        dev, dt = Yh.device, Yh.dtype
        lam = (torch.as_tensor(lambda_rho, device=dev, dtype=dt)
               if lambda_rho is not None
               else torch.full((B,), c.lambda_rho_default, device=dev, dtype=dt))
        if lam.dim() == 0:
            lam = lam.expand(B).contiguous()

        # --- initialization, equation (24)
        X0 = F.interpolate(Yh, size=(H, W), mode="bicubic", align_corners=False)
        Yf = Yh.reshape(B, c.C, -1)
        U, _, _ = torch.linalg.svd(Yf.to(torch.float32), full_matrices=False)
        D = U[:, :, :c.K_max].to(dt)
        rho = torch.full((B, 1, H, W), float(c.K_max), device=dev, dtype=dt)
        E = torch.zeros(B, c.C, H, W, device=dev, dtype=dt)
        Z = X0

        s2 = None
        if sigma2 is not None:
            s2 = torch.as_tensor(sigma2, device=dev, dtype=dt)
            if s2.dim() == 0:
                s2 = s2.expand(B).contiguous()

        aux = []
        for t in range(c.T):
            Z, D, rho, E = self.stage(t, Z, D, rho, E, Yh, Ym, lam, s2)
            if return_aux:
                aux.append({"rho": rho.detach(),
                            "mean_rank": float(rho.detach().mean())})

        if return_aux:
            return Z, rho, {"stages": aux, "D": D.detach()}
        return Z, rho

    # ------------------------------------------------------------ cost
    def flops_estimate(self, H: int, W: int, mean_rank: float,
                       saturated_fraction: float) -> dict:
        """Equation (28): FLOPs ~ c0 N + c1 sum_p rho_p + c2 w^2 |Omega_inn|.

        The three coefficients are measured once by counting the multiply-adds
        of the rank-independent path, of one active atom in the RGCP, and of
        one pixel of L_omega. They are analytic, not profiled, so they are a
        model of the cost rather than a measurement of it.
        """
        c = self.cfg
        N = H * W
        c0 = (2 * c.C * c.blur_size ** 2            # BS and its adjoint
              + 2 * c.C * c.L                        # R and R^T
              + c.C * c.K_max                        # projections for (4)
              + 6 * c.K_max                          # cumsum, J, softmax
              + 2 * c.width * 9)                     # TV prox
        c1 = (c.C                                    # one atom in D^T(X-E)
              + 2 * c.width * 9 / max(c.K_max, 1))   # share of the coeff prox
        c2 = (4 * c.C * c.width + 2 * c.C * c.C)     # L_omega per pixel
        total = c.T * (c0 * N + c1 * N * mean_rank
                       + c2 * N * saturated_fraction)
        return {"flops": float(total), "gflops": float(total / 1e9),
                "c0": c0, "c1": c1, "c2": c2,
                "mean_rank": mean_rank,
                "saturated_fraction": saturated_fraction}

    def count_parameters(self) -> int:
        return int(sum(p.numel() for p in self.parameters() if p.requires_grad))


# ------------------------------------------------------------------- loss
def nested_truncation_loss(X_gt: torch.Tensor, D: torch.Tensor,
                           k: int | None = None,
                           generator: torch.Generator | None = None
                           ) -> torch.Tensor:
    """Equation (27): expected relative energy outside the first k atoms."""
    B, C, H, W = X_gt.shape
    K = D.shape[-1]
    if k is None:
        k = int(torch.randint(1, K + 1, (1,), generator=generator).item())
    Dk = D[:, :, :k]
    Xf = X_gt.reshape(B, C, -1)
    proj = Dk @ (Dk.transpose(1, 2) @ Xf)
    num = ((Xf - proj) ** 2).sum(dim=(1, 2))
    den = (Xf ** 2).sum(dim=(1, 2)).clamp_min(1e-12)
    return (num / den).mean()


def svrdun_loss(X_hat, X_gt, Yh, Ym, ops: ObservationOperators, D,
                alpha1: float = 0.1, alpha2: float = 0.01,
                generator: torch.Generator | None = None) -> dict:
    """Equation (26): L1 reconstruction + observation terms + nested loss."""
    rec = F.l1_loss(X_hat, X_gt)
    obs = F.l1_loss(ops.Rop(X_hat), Ym) + F.l1_loss(ops.BS(X_hat), Yh)
    nest = nested_truncation_loss(X_gt, D, generator=generator)
    total = rec + alpha1 * obs + alpha2 * nest
    return {"loss": total, "rec": rec.detach(), "obs": obs.detach(),
            "nest": nest.detach()}
