"""Computational cost: parameters, FLOPs, inference time and peak memory.

Section V-F reports these for a 512x512 output on one RTX 4090. Two points
from the paper's own Table V note are enforced here:

  * FLOPs are NOT a proxy for latency. At the default budget SVR-DUN uses
    29.6% fewer FLOPs than RASD-FuNet but only 6.4% less time, and at the
    largest budget it is slower despite needing 12.7% fewer operations,
    because the gather and scatter of active windows is memory-bound.
  * Timing is therefore measured separately, with warm-up and CUDA
    synchronisation, and is reported alongside the hardware it ran on.

Any timing measured on hardware other than the paper's is not comparable with
Table V; `measure_cost` records the device so the comparison cannot be made by
accident.
"""
from __future__ import annotations

import platform
import statistics
import time

__all__ = ["count_parameters", "measure_time", "measure_peak_memory",
           "measure_cost", "flops_from_rank_field"]


def count_parameters(model) -> dict:
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {"total": int(total), "trainable": int(trainable),
            "millions": round(total / 1e6, 4)}


def _sync(device):
    import torch
    if device.type == "cuda":
        torch.cuda.synchronize()


def measure_time(model, Yh, Ym, lambda_rho: float, out_hw, n_warmup: int = 3,
                 n_runs: int = 10) -> dict:
    """Wall-clock inference time with warm-up and synchronisation."""
    import torch
    device = Yh.device
    model.eval()
    with torch.no_grad():
        for _ in range(n_warmup):
            model(Yh, Ym, lambda_rho=lambda_rho, out_hw=out_hw)
        _sync(device)
        times = []
        for _ in range(n_runs):
            t0 = time.perf_counter()
            model(Yh, Ym, lambda_rho=lambda_rho, out_hw=out_hw)
            _sync(device)
            times.append(time.perf_counter() - t0)
    return {"mean_s": float(statistics.mean(times)),
            "median_s": float(statistics.median(times)),
            "std_s": float(statistics.pstdev(times)) if len(times) > 1 else 0.0,
            "min_s": float(min(times)), "n_runs": n_runs,
            "device": str(device),
            "device_name": (torch.cuda.get_device_name(device)
                            if device.type == "cuda" else platform.processor()
                            or platform.machine())}


def measure_peak_memory(model, Yh, Ym, lambda_rho: float, out_hw) -> dict:
    """Peak allocated memory for one forward pass (CUDA only, else None)."""
    import torch
    device = Yh.device
    if device.type != "cuda":
        return {"peak_bytes": None, "peak_gb": None,
                "note": "peak memory is measured only on CUDA"}
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(device)
    model.eval()
    with torch.no_grad():
        model(Yh, Ym, lambda_rho=lambda_rho, out_hw=out_hw)
    torch.cuda.synchronize()
    peak = int(torch.cuda.max_memory_allocated(device))
    return {"peak_bytes": peak, "peak_gb": round(peak / 1024 ** 3, 4)}


def flops_from_rank_field(model, rho, H: int, W: int) -> dict:
    """Equation (28) evaluated on an actual rank field."""
    r = rho.detach().float()
    mean_rank = float(r.mean())
    sat = float((r >= model.cfg.K_max - 0.5).float().mean())
    return model.flops_estimate(H, W, mean_rank, sat)


def measure_cost(model, R, H: int = 512, W: int = 512,
                 lambda_rhos=(1e-4, 1e-3, 1e-2), device: str = "auto",
                 n_runs: int = 10) -> dict:
    """Full cost table for one model across several budgets.

    Returns one row per budget with parameters, analytic FLOPs from the rank
    field actually produced, measured time and peak memory.
    """
    import torch

    from .train import pick_device

    dev = pick_device(device)
    model = model.to(dev).eval()
    dtype = torch.float32
    Rt = torch.as_tensor(R, device=dev, dtype=dtype)
    model.ops.set_response(Rt)

    c = model.cfg
    g = torch.Generator(device="cpu").manual_seed(0)
    gt = torch.rand(1, c.C, H, W, generator=g).to(dev, dtype)
    with torch.no_grad():
        Yh = model.ops.BS(gt)
        Ym = model.ops.Rop(gt)

    rows = []
    for lam in lambda_rhos:
        with torch.no_grad():
            _, rho = model(Yh, Ym, lambda_rho=lam, out_hw=(H, W))
        fl = flops_from_rank_field(model, rho, H, W)
        tm = measure_time(model, Yh, Ym, lam, (H, W), n_runs=n_runs)
        mem = measure_peak_memory(model, Yh, Ym, lam, (H, W))
        rows.append({
            "lambda_rho": lam,
            "params_M": count_parameters(model)["millions"],
            "gflops_analytic": round(fl["gflops"], 4),
            "mean_rank": round(fl["mean_rank"], 3),
            "saturated_fraction": round(fl["saturated_fraction"], 4),
            "time_s": round(tm["mean_s"], 5),
            "time_std_s": round(tm["std_s"], 5),
            "peak_memory_gb": mem["peak_gb"],
            "device": tm["device"], "device_name": tm["device_name"],
        })
    return {
        "rows": rows, "output_size": [H, W], "provenance": "COMPUTED",
        "comparability_note": (
            "Measured on the device named in each row. The paper's Table V was "
            "measured on one NVIDIA RTX 4090; timings from other hardware are "
            "not directly comparable. FLOPs here are analytic (equation 28), "
            "not profiled."),
        "flops_vs_latency_note": (
            "FLOPs are not a proxy for latency: the gather and scatter of "
            "active windows is memory-bound and changes little with the number "
            "of active atoms."),
    }
