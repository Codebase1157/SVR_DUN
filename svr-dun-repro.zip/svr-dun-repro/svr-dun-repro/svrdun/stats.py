"""Paired statistical analysis, as described in Section V-K of the paper.

Primary test   : two-sided Wilcoxon signed-rank, computed exactly when there
                 are no ties (Section V-K, "Tests and intervals").
Secondary test : paired t-test.
Interval       : two-level percentile bootstrap with 10 000 replicates; each
                 replicate resamples the test images with replacement and,
                 independently for each method, the three trained models.
Correction     : Holm-Bonferroni within each dataset over the
                 3 baselines x 4 metrics = 12 comparisons.
Effect size    : rank-biserial correlation r = (W+ - W-) / (W+ + W-).

Everything here is ordinary arithmetic, so it runs identically on reported
per-seed values and on values this repository computes itself. Which of the
two it was given is recorded by the caller through the provenance tag.
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass

import numpy as np

__all__ = ["wilcoxon_exact", "paired_t", "rank_biserial", "holm_bonferroni",
           "two_level_bootstrap_ci", "paired_comparison", "PairedResult",
           "min_achievable_wilcoxon_p"]


# --------------------------------------------------------------- Wilcoxon
def _signed_rank_stats(d: np.ndarray):
    """W+ and W- over non-zero differences, with average ranks for ties."""
    d = np.asarray(d, dtype=np.float64)
    nz = d[d != 0.0]
    n = nz.size
    if n == 0:
        return 0.0, 0.0, 0, False
    order = np.argsort(np.abs(nz), kind="mergesort")
    absd = np.abs(nz)[order]
    ranks = np.empty(n, dtype=np.float64)
    i = 0
    has_ties = False
    while i < n:
        j = i
        while j + 1 < n and absd[j + 1] == absd[i]:
            j += 1
        if j > i:
            has_ties = True
        ranks[i:j + 1] = 0.5 * (i + 1 + j + 1)
        i = j + 1
    signs = np.sign(nz)[order]
    w_plus = float(np.sum(ranks[signs > 0]))
    w_minus = float(np.sum(ranks[signs < 0]))
    return w_plus, w_minus, n, has_ties


#: largest n for which the exact signed-rank distribution is enumerated.
#: The dynamic program costs O(n^3) table updates, so 50 is cheap; counts stay
#: below 2**53 up to n = 53, which keeps them exactly representable in float64.
EXACT_MAX_N = 50


def _exact_two_sided_p(w_plus: float, n: int) -> float:
    """Exact two-sided p of the signed-rank statistic."""
    total = 2.0 ** n
    # exact distribution of W+ : subset sums of the ranks 1..n, each rank
    # independently carrying a + or - sign under the null hypothesis
    counts = np.zeros(n * (n + 1) // 2 + 1, dtype=np.float64)
    counts[0] = 1.0
    for r in range(1, n + 1):
        prev = counts.copy()          # must read the pre-update values
        counts[r:] += prev[:-r]
    # two-sided: probability of a statistic at least as extreme as observed
    mean = n * (n + 1) / 4.0
    dev = abs(w_plus - mean)
    idx = np.arange(counts.size)
    extreme = counts[np.abs(idx - mean) >= dev - 1e-9].sum()
    return float(min(1.0, extreme / total))


def wilcoxon_exact(d: np.ndarray) -> dict:
    """Two-sided Wilcoxon signed-rank test on paired differences `d`.

    Exact when there are no ties among |d| and n <= 25; otherwise falls back to
    the normal approximation with continuity and tie corrections.
    """
    d = np.asarray(d, dtype=np.float64)
    w_plus, w_minus, n, has_ties = _signed_rank_stats(d)
    if n == 0:
        return {"p": 1.0, "W_plus": 0.0, "W_minus": 0.0, "n_nonzero": 0,
                "method": "degenerate", "exact": False}
    if (not has_ties) and n <= EXACT_MAX_N:
        p = _exact_two_sided_p(w_plus, n)
        method, exact = "exact", True
    else:
        mean = n * (n + 1) / 4.0
        var = n * (n + 1) * (2 * n + 1) / 24.0
        z = (abs(w_plus - mean) - 0.5) / math.sqrt(max(var, 1e-12))
        from scipy.stats import norm
        p = float(2.0 * (1.0 - norm.cdf(z)))
        method, exact = "normal-approx", False
    return {"p": float(min(1.0, p)), "W_plus": w_plus, "W_minus": w_minus,
            "n_nonzero": n, "method": method, "exact": exact}


def min_achievable_wilcoxon_p(n: int, n_comparisons: int = 1) -> float:
    """Smallest two-sided p an exact signed-rank test on n pairs can return.

    This is 2 / 2**n, multiplied by `n_comparisons` under Holm for the
    smallest p in the family. Section V-K uses it to show that ten KAIST
    images impose a floor of 12 * 1.95e-3 = 0.023 whatever the margin.
    """
    return float(min(1.0, n_comparisons * 2.0 / (2 ** n)))


# ------------------------------------------------------------------ others
def paired_t(d: np.ndarray) -> dict:
    from scipy.stats import t as student_t
    d = np.asarray(d, dtype=np.float64)
    n = d.size
    if n < 2:
        return {"p": 1.0, "t": 0.0, "df": max(n - 1, 0)}
    mean = float(np.mean(d))
    sd = float(np.std(d, ddof=1))
    if sd <= 0:
        return {"p": 0.0 if mean != 0 else 1.0, "t": float("inf") if mean else 0.0,
                "df": n - 1}
    tstat = mean / (sd / math.sqrt(n))
    p = float(2.0 * student_t.sf(abs(tstat), df=n - 1))
    return {"p": p, "t": float(tstat), "df": n - 1}


def rank_biserial(d: np.ndarray) -> float:
    w_plus, w_minus, n, _ = _signed_rank_stats(d)
    tot = w_plus + w_minus
    if tot <= 0:
        return 0.0
    return float((w_plus - w_minus) / tot)


def holm_bonferroni(pvals, labels=None):
    """Holm-Bonferroni step-down adjustment with monotonicity enforced.

    Returns adjusted p-values in the original order.
    """
    p = np.asarray(list(pvals), dtype=np.float64)
    m = p.size
    order = np.argsort(p, kind="mergesort")
    adj_sorted = np.empty(m, dtype=np.float64)
    running = 0.0
    for i, idx in enumerate(order):
        val = (m - i) * p[idx]
        running = max(running, val)
        adj_sorted[i] = min(1.0, running)
    adj = np.empty(m, dtype=np.float64)
    adj[order] = adj_sorted
    if labels is None:
        return adj
    return dict(zip(labels, adj.tolist()))


def two_level_bootstrap_ci(per_image_per_seed_a: np.ndarray,
                           per_image_per_seed_b: np.ndarray,
                           n_boot: int = 10000,
                           alpha: float = 0.05,
                           higher_is_better: bool = True,
                           seed: int = 0) -> dict:
    """Two-level percentile bootstrap of the mean paired difference.

    Each array is (n_images, n_seeds). A replicate resamples images with
    replacement and, independently for each method, resamples seeds with
    replacement -- the "two-level" scheme of Section V-K.

    The reported difference favours `a` over `b`: for a higher-is-better
    metric it is mean(a) - mean(b), otherwise mean(b) - mean(a).
    """
    A = np.asarray(per_image_per_seed_a, dtype=np.float64)
    B = np.asarray(per_image_per_seed_b, dtype=np.float64)
    if A.shape != B.shape:
        raise ValueError(f"shape mismatch {A.shape} vs {B.shape}")
    n_img, n_seed = A.shape
    rng = np.random.default_rng(seed)

    def stat(a2, b2):
        ma = a2.mean(axis=1)
        mb = b2.mean(axis=1)
        d = (ma - mb) if higher_is_better else (mb - ma)
        return float(np.mean(d))

    point = stat(A, B)
    boots = np.empty(n_boot, dtype=np.float64)
    for i in range(n_boot):
        ii = rng.integers(0, n_img, n_img)
        sa = rng.integers(0, n_seed, n_seed)
        sb = rng.integers(0, n_seed, n_seed)
        boots[i] = stat(A[np.ix_(ii, sa)], B[np.ix_(ii, sb)])
    lo = float(np.percentile(boots, 100 * alpha / 2))
    hi = float(np.percentile(boots, 100 * (1 - alpha / 2)))
    return {"point": point, "lo": lo, "hi": hi, "n_boot": int(n_boot),
            "alpha": alpha, "excludes_zero": bool(lo > 0 or hi < 0)}


# ------------------------------------------------------------------ driver
@dataclass
class PairedResult:
    dataset: str
    baseline: str
    metric: str
    mean_delta: float
    ci_lo: float | None
    ci_hi: float | None
    wins: str
    rank_biserial_r: float
    p_wilcoxon_raw: float
    p_wilcoxon_adj: float | None
    p_t_raw: float
    p_t_adj: float | None
    n: int
    wilcoxon_method: str

    def as_dict(self):
        return asdict(self)


def paired_comparison(per_image_a: np.ndarray, per_image_b: np.ndarray,
                      dataset: str, baseline: str, metric: str,
                      higher_is_better: bool = True,
                      per_image_per_seed_a: np.ndarray | None = None,
                      per_image_per_seed_b: np.ndarray | None = None,
                      n_boot: int = 10000, seed: int = 0) -> PairedResult:
    """One row of Table XIV: delta, interval, wins, effect size and p-values.

    `per_image_a/b` are seed-averaged per-image values for the method and the
    baseline. If the full (images x seeds) arrays are given, the confidence
    interval uses the two-level bootstrap; otherwise it is left as None.
    """
    a = np.asarray(per_image_a, dtype=np.float64)
    b = np.asarray(per_image_b, dtype=np.float64)
    d = (a - b) if higher_is_better else (b - a)   # positive favours method a
    n = d.size
    w = wilcoxon_exact(d)
    t = paired_t(d)
    r = rank_biserial(d)
    wins = int(np.sum(d > 0))
    ci_lo = ci_hi = None
    if per_image_per_seed_a is not None and per_image_per_seed_b is not None:
        ci = two_level_bootstrap_ci(per_image_per_seed_a, per_image_per_seed_b,
                                    n_boot=n_boot, higher_is_better=higher_is_better,
                                    seed=seed)
        ci_lo, ci_hi = ci["lo"], ci["hi"]
    return PairedResult(
        dataset=dataset, baseline=baseline, metric=metric,
        mean_delta=float(np.mean(d)), ci_lo=ci_lo, ci_hi=ci_hi,
        wins=f"{wins}/{n}", rank_biserial_r=r,
        p_wilcoxon_raw=w["p"], p_wilcoxon_adj=None,
        p_t_raw=t["p"], p_t_adj=None, n=n, wilcoxon_method=w["method"],
    )
