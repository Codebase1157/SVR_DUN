"""Values transcribed from the published SVR-DUN tables.

EVERYTHING IN THIS MODULE IS PROVENANCE `REPORTED`.
It is not a reproduction. These are the numbers printed in the paper, kept here
so that figures and tables can be regenerated, and so that anything this
repository computes can be compared against its published target.

`PAPER_CONFIG` holds the hyperparameters stated in Section V-C; those are
inputs to real runs, not results, so code may use them freely.
"""
from __future__ import annotations

PROVENANCE = "REPORTED"
SOURCE = "Learning Where Rank Matters: Spatially-Varying-Rank Deep Unfolding for Budget-Adaptive Hyperspectral and Multispectral Image Fusion"

# ---------------------------------------------------------------- protocol
PAPER_CONFIG = {
    "_source": "Paper Sections III-A, V-A, V-C (hyperparameters, not results)",
    "C_bands": 31,
    "scale_s": 8,
    "blur_kernel_size": 8,
    "blur_variance": 3.0,
    "response_default": "Nikon D700",
    "L_default": 3,
    "T_stages": 5,
    "K_max": 6,
    "window_w": 8,
    "gamma_mask": 0.05,
    "tau_start": 1.0,
    "tau_end": 0.05,
    "tau_schedule": "cosine",
    "kappa": 1e-3,
    "lambda_rho_range": [1e-4, 1e-2],
    "lambda_rho_default": 1e-3,
    "lambda_rho_sampling": "log-uniform",
    "alpha1_obs": 0.1,
    "alpha2_nest": 0.01,
    "optimizer": "Adam",
    "lr_init": 4e-4,
    "lr_schedule": "cosine annealing",
    "batch_size": 16,
    "epochs": {"CAVE": 1000, "ICVL": 120, "KAIST": 300},
    "crop_hr": 64,
    "crop_lr": 8,
    "stride": {"CAVE": 32, "ICVL": 64, "KAIST": 64},
    "seeds": [1, 2, 3],
    "hardware": "1x NVIDIA RTX 4090",
    "timing_output_size": [512, 512],
    "definition1_fig1": {"w": 8, "delta": 2e-3, "K_max": 5},
    "datasets": {
        "CAVE":  {"scenes": 32,  "size": [512, 512],   "bands": 31,
                  "range_nm": [400, 700], "test": "last 12",  "n_test": 12},
        "ICVL":  {"scenes": 200, "size": [1392, 1300], "bands": 31,
                  "range_nm": [400, 700], "test": "40 at random", "n_test": 40},
        "KAIST": {"scenes": 30,  "size": [2704, 3376], "bands": 31,
                  "range_nm": [420, 720], "test": "last 10",  "n_test": 10},
        "GF5-GF1": {"lrhsi": [1100, 1140, 150], "hrmsi": [2200, 2280, 4],
                    "reference": None},
    },
}

# ------------------------------------------------------- Table III (means)
TABLE_III = {
    "_source": "Paper Table III", "_provenance": PROVENANCE,
    "_columns": ["PSNR", "ERGAS", "SAM", "UIQI"],
    "_note": "Nine baseline rows are the measured values reported in [6].",
    "CAVE": {
        "NSSR [46]":            [46.9499, 0.6919, 3.0627, 0.9704],
        "HySure [9]":           [43.3679, 1.0878, 7.9931, 0.9477],
        "SMGU-Net [24]":        [46.0745, 0.7483, 2.6285, 0.9700],
        "CSGAV [47]":           [46.4409, 0.6721, 2.6482, 0.9691],
        "LRTN [19]":            [48.0602, 0.5512, 2.3654, 0.9713],
        "DSPNet [48]":          [47.5056, 0.5953, 2.5916, 0.9720],
        "PSRT [15]":            [46.2974, 0.6794, 2.8642, 0.9672],
        "PanMamba [17]":        [45.9134, 0.7000, 2.7799, 0.9689],
        "RASD-FuNet [6]":       [49.1170, 0.5091, 2.3352, 0.9735],
        "Region-aware MoE [32]":[49.2036, 0.5040, 2.3104, 0.9737],
        "TPTransformer [26]":   [48.9415, 0.5195, 2.3562, 0.9731],
        "SVR-DUN (ours)":       [49.4612, 0.4991, 2.2528, 0.9743],
    },
    "ICVL": {
        "NSSR [46]":            [51.9061, 0.2585, 0.7986, 0.9264],
        "HySure [9]":           [47.0266, 0.6947, 2.4513, 0.9271],
        "SMGU-Net [24]":        [57.3128, 0.1035, 0.3696, 0.9694],
        "CSGAV [47]":           [57.5816, 0.1009, 0.3611, 0.9692],
        "LRTN [19]":            [58.1940, 0.0926, 0.3389, 0.9701],
        "DSPNet [48]":          [58.3014, 0.0913, 0.3361, 0.9701],
        "PSRT [15]":            [55.3873, 0.1360, 0.4453, 0.9659],
        "PanMamba [17]":        [56.9631, 0.1081, 0.3813, 0.9687],
        "RASD-FuNet [6]":       [58.4292, 0.0891, 0.3359, 0.9703],
        "Region-aware MoE [32]":[58.5107, 0.0883, 0.3323, 0.9705],
        "TPTransformer [26]":   [58.3761, 0.0896, 0.3389, 0.9702],
        "SVR-DUN (ours)":       [58.6415, 0.0869, 0.3240, 0.9709],
    },
    "KAIST": {
        "NSSR [46]":            [43.7100, 1.0666, 2.9373, 0.7586],
        "HySure [9]":           [42.6458, 1.1744, 4.4376, 0.7184],
        "SMGU-Net [24]":        [44.3083, 0.9765, 2.5696, 0.7804],
        "CSGAV [47]":           [44.5368, 0.9563, 2.5200, 0.7779],
        "LRTN [19]":            [44.8721, 0.9193, 2.4238, 0.7961],
        "DSPNet [48]":          [44.9415, 0.9132, 2.4104, 0.7997],
        "PSRT [15]":            [43.8322, 1.0297, 2.7157, 0.7595],
        "PanMamba [17]":        [43.8663, 1.0348, 2.6715, 0.7662],
        "RASD-FuNet [6]":       [45.0285, 0.9047, 2.4089, 0.8015],
        "Region-aware MoE [32]":[45.1172, 0.8955, 2.3834, 0.8031],
        "TPTransformer [26]":   [44.9806, 0.9097, 2.4306, 0.8006],
        "SVR-DUN (ours)":       [45.2981, 0.8771, 2.3241, 0.8063],
    },
}

TABLE_IV = {
    "_source": "Paper Table IV", "_provenance": PROVENANCE,
    "_metric": "QNR (higher better), real GF5-GF1",
    "NSSR": 0.9039, "HySure": 0.9662, "SMGU-Net": 0.9808, "CSGAV": 0.9814,
    "LRTN": 0.9810, "DSPNet": 0.9818, "PSRT": 0.9812, "PanMamba": 0.9819,
    "RASD-FuNet": 0.9820, "SVR-DUN": 0.9834,
    "_svrdun_components": {"QNR": [0.9834, 0.0006],
                           "D_lambda": [0.0071, 0.0004],
                           "D_s": [0.0096, 0.0005],
                           "_note": "mean +/- sd over three seeds, Section V-K"},
}

TABLE_V = {
    "_source": "Paper Table V", "_provenance": PROVENANCE,
    "_columns": ["Params_M", "FLOPs_G", "Time_s", "Memory_GB", "mean_rank"],
    "_note": ("Time and memory for a 512x512 output on one RTX 4090. FLOPs are "
              "not a proxy for latency: the gather/scatter of active windows is "
              "memory-bound (see the paper's Table V footnote)."),
    "SMGU-Net [24]":  [0.759, 11.714, 0.412, 4.18, None],
    "CSGAV [47]":     [3.356,  8.915, 0.335, 3.46, None],
    "LRTN [19]":      [3.551,  4.143, 0.198, 2.51, None],
    "DSPNet [48]":    [6.055, 13.194, 0.467, 4.73, None],
    "PSRT [15]":      [0.247,  2.104, 0.146, 2.07, None],
    "PanMamba [17]":  [1.679,  3.597, 0.183, 2.34, None],
    "RASD-FuNet [6]": [0.938,  0.764, 0.094, 1.62, None],
    "SVR-DUN, lambda_rho=1e-4": [0.714, 0.667, 0.102, 1.55, 4.31],
    "SVR-DUN, lambda_rho=1e-3": [0.714, 0.538, 0.088, 1.38, 3.12],
    "SVR-DUN, lambda_rho=1e-2": [0.714, 0.423, 0.079, 1.21, 2.05],
}

TABLE_VI = {
    "_source": "Paper Table VI", "_provenance": PROVENANCE,
    "_columns": ["PSNR", "ERGAS", "SAM", "UIQI", "FLOPs_G"],
    "A1": ["Binary rank: rho_p in {K,K_max}, fixed ratio", 49.13, 0.518, 2.320, 0.9735, 0.84],
    "A2": ["Learned discriminator instead of RFE",         49.28, 0.510, 2.289, 0.9739, 0.56],
    "A3": ["No atom ordering (alpha2=0)",                  49.19, 0.515, 2.308, 0.9737, 0.59],
    "A4": ["No TV step on rho",                            49.34, 0.506, 2.277, 0.9740, 0.55],
    "A5": ["No innovation module (E=0)",                   49.02, 0.525, 2.343, 0.9733, 0.46],
    "A6": ["No data-consistency module",                   48.76, 0.541, 2.397, 0.9727, 0.47],
    "A7": ["Gather-and-reshape instead of in-place gating", 49.09, 0.521, 2.328, 0.9734, 0.56],
    "A8": ["One model per fixed lambda_rho",               49.48, 0.498, 2.249, 0.9743, 0.54],
    "full": ["Full SVR-DUN",                               49.46, 0.499, 2.253, 0.9743, 0.54],
}

TABLE_VII = {
    "_source": "Paper Table VII", "_provenance": PROVENANCE,
    "_columns": ["setting", "value", "PSNR", "SAM", "FLOPs_G", "saturated_windows_pct"],
    "rows": [
        ["K_max", 2, 48.72, 2.406, 0.77, 58],
        ["K_max", 4, 49.31, 2.283, 0.61, 27],
        ["K_max", 6, 49.46, 2.253, 0.54, 14],   # default
        ["K_max", 8, 49.44, 2.257, 0.53, 8],
        ["T", 3, 49.21, 2.303, 0.34, 17],
        ["T", 5, 49.46, 2.253, 0.54, 14],       # default
        ["T", 7, 49.49, 2.247, 0.74, 13],
        ["w", 4, 49.39, 2.267, 0.52, 12],
        ["w", 8, 49.46, 2.253, 0.54, 14],       # default
        ["w", 16, 49.33, 2.279, 0.60, 19],
    ],
    "defaults": {"K_max": 6, "T": 5, "w": 8},
}

TABLE_VIII = {
    "_source": "Paper Table VIII", "_provenance": PROVENANCE,
    "_columns": ["Matched", "Blur var. 2", "Blur var. 4", "Other spectral response"],
    "LRTN [19]":      [48.0602, 46.12, 45.74, 44.86],
    "DSPNet [48]":    [47.5056, 45.83, 45.31, 44.52],
    "RASD-FuNet [6]": [49.1170, 46.97, 46.52, 45.31],
    "SVR-DUN":        [49.4612, 47.88, 47.49, 45.02],
}

TABLE_IX = {
    "_source": "Paper Table IX", "_provenance": PROVENANCE,
    "_columns": ["perturbation", "rel_error_R", "RASD-FuNet", "SVR-DUN",
                 "SVR-DUN +Aug", "SVR-DUN +Joint", "SVR-DUN +Aug+Joint"],
    "rows": [
        ["None (matched)",          0.000, 49.12, 49.46, 49.38, 49.42, 49.35],
        ["Band shift -20 nm",       0.163, 44.68, 44.29, 45.85, 46.65, 47.00],
        ["Band shift -10 nm",       0.082, 46.89, 46.86, 47.78, 48.03, 48.24],
        ["Band shift -5 nm",        0.041, 48.00, 48.16, 48.58, 48.72, 48.80],
        ["Band shift +5 nm",        0.039, 48.06, 48.22, 48.62, 48.76, 48.82],
        ["Band shift +10 nm",       0.077, 47.02, 47.02, 47.88, 48.11, 48.31],
        ["Band shift +20 nm",       0.151, 45.01, 44.67, 46.09, 46.85, 47.16],
        ["Bandwidth x0.8",          0.118, 45.91, 45.72, 47.08, 47.41, 47.76],
        ["Bandwidth x1.25",         0.134, 45.47, 45.21, 46.77, 47.14, 47.54],
        ["Smooth field, delta=0.05", 0.034, 48.19, 48.38, 48.72, 48.84, 48.89],
        ["Smooth field, delta=0.10", 0.068, 47.27, 47.30, 48.05, 48.26, 48.43],
        ["Smooth field, delta=0.20", 0.137, 45.39, 45.12, 46.71, 47.09, 47.50],
    ],
}

TABLE_X = {
    "_source": "Paper Table X", "_provenance": PROVENANCE,
    "_columns": ["Nikon D700 (matched)", "Canon 60D",
                 "Five held-out cameras mean", "Five held-out cameras sd",
                 "Final response error (Canon 60D)"],
    "RASD-FuNet [6]":      [49.12, 45.31, 45.99, 0.72, None],
    "RASD-FuNet [6] +Aug": [49.05, 46.74, 47.15, 0.41, None],
    "SVR-DUN":             [49.46, 45.02, 45.81, 0.84, 0.140],
    "SVR-DUN +Aug":        [49.38, 46.65, 47.14, 0.47, 0.140],
    "SVR-DUN +Joint":      [49.42, 47.04, 47.47, 0.43, 0.075],
    "SVR-DUN +Aug+Joint":  [49.35, 47.46, 47.80, 0.36, 0.060],
}

TABLE_XI = {
    "_source": "Paper Table XI", "_provenance": PROVENANCE,
    "_columns": ["SNR_dB", "RASD-FuNet PSNR", "RFE(15) PSNR", "RFE(15) mean rank",
                 "RFE(15) FLOPs_G", "Noise-aware(32) PSNR",
                 "Noise-aware(32) mean rank", "Noise-aware(32) FLOPs_G"],
    "rows": [
        ["inf", 49.12, 49.46, 3.12, 0.538, 49.45, 3.10, 0.536],
        [40,    48.21, 48.57, 3.48, 0.577, 48.63, 3.19, 0.546],
        [30,    45.86, 46.10, 4.26, 0.661, 46.31, 3.44, 0.573],
        [25,    44.12, 44.27, 4.81, 0.721, 44.58, 3.67, 0.598],
        [20,    42.05, 42.09, 5.34, 0.778, 42.52, 3.95, 0.628],
    ],
}

TABLE_XII = {
    "_source": "Paper Table XII", "_provenance": PROVENANCE,
    "_columns": ["sensor", "L", "k=1", "k=2", "k=3", "k=4", "k=5", "k=6",
                 "recoverable_rank_(30)", "windows_above_pct",
                 "RASD-FuNet PSNR", "SVR-DUN PSNR"],
    "_note": ("k columns are sigma_min(R D_k) / ||R||_2 with the CAVE atoms. "
              "Entries with k > L are zero by Proposition 2(b). epsilon = 0.01."),
    "epsilon": 0.01,
    "rows": [
        ["Nikon D700",              3, 0.612, 0.184, 0.041, 0.000, 0.000, 0.000, 3, 33, 49.12, 49.46],
        ["Canon 60D",               3, 0.587, 0.166, 0.034, 0.000, 0.000, 0.000, 3, 33, 45.31, 45.02],
        ["Gaussian, L = 4",         4, 0.634, 0.238, 0.079, 0.021, 0.000, 0.000, 4, 22, 49.74, 50.05],
        ["Gaussian, L = 6",         6, 0.651, 0.274, 0.118, 0.046, 0.017, 0.006, 5, 14, 50.38, 50.64],
        ["Gaussian, L = 8",         8, 0.663, 0.291, 0.142, 0.063, 0.028, 0.011, 6,  0, 50.81, 51.03],
        ["GF1 (estimated by (33))", 4, 0.598, 0.207, 0.062, 0.014, 0.000, 0.000, 4, 18, None, None],
    ],
}

# ----------------------------------------------------- Table XIII per seed
#: dataset-mean PSNR (dB) and SAM (degrees) for each method and seed.
TABLE_XIII = {
    "_source": "Paper Table XIII", "_provenance": PROVENANCE,
    "_note": ("Dataset means per seed. These are means over the test images, "
              "NOT per-image values; the per-image values behind Table XIV are "
              "not printed in the paper."),
    "seeds": [1, 2, 3],
    "methods": {
        "RASD-FuNet [6] (retrained)": {
            "CAVE_PSNR":  [49.0519, 49.1017, 49.1266],
            "CAVE_SAM":   [2.3542, 2.3393, 2.3318],
            "ICVL_PSNR":  [58.4298, 58.3886, 58.4161],
            "ICVL_SAM":   [0.3352, 0.3386, 0.3363],
            "KAIST_PSNR": [45.0230, 45.0433, 44.9824],
            "KAIST_SAM":  [2.4109, 2.4042, 2.4242],
        },
        "Region-aware MoE [32]": {
            "CAVE_PSNR":  [49.2407, 49.1962, 49.1739],
            "CAVE_SAM":   [2.2992, 2.3126, 2.3194],
            "ICVL_PSNR":  [58.4941, 58.5314, 58.5066],
            "ICVL_SAM":   [0.3337, 0.3306, 0.3326],
            "KAIST_PSNR": [45.0856, 45.1235, 45.1425],
            "KAIST_SAM":  [2.3939, 2.3813, 2.3750],
        },
        "TPTransformer [26]": {
            "CAVE_PSNR":  [48.9773, 48.8968, 48.9504],
            "CAVE_SAM":   [2.3456, 2.3694, 2.3536],
            "ICVL_PSNR":  [58.3811, 58.3962, 58.3510],
            "ICVL_SAM":   [0.3385, 0.3372, 0.3410],
            "KAIST_PSNR": [45.0177, 44.9732, 44.9509],
            "KAIST_SAM":  [2.4186, 2.4330, 2.4402],
        },
        "SVR-DUN (ours)": {
            "CAVE_PSNR":  [49.4341, 49.4950, 49.4544],
            "CAVE_SAM":   [2.2608, 2.2428, 2.2548],
            "ICVL_PSNR":  [58.6219, 58.6454, 58.6572],
            "ICVL_SAM":   [0.3255, 0.3237, 0.3228],
            "KAIST_PSNR": [45.3208, 45.2697, 45.3038],
            "KAIST_SAM":  [2.3167, 2.3334, 2.3222],
        },
    },
    "printed_mean_sd": {
        "RASD-FuNet [6] (retrained)": {
            "CAVE_PSNR": [49.0934, 0.038], "CAVE_SAM": [2.3418, 0.0114],
            "ICVL_PSNR": [58.4115, 0.021], "ICVL_SAM": [0.3367, 0.0017],
            "KAIST_PSNR": [45.0162, 0.031], "KAIST_SAM": [2.4131, 0.0102]},
        "Region-aware MoE [32]": {
            "CAVE_PSNR": [49.2036, 0.034], "CAVE_SAM": [2.3104, 0.0103],
            "ICVL_PSNR": [58.5107, 0.019], "ICVL_SAM": [0.3323, 0.0016],
            "KAIST_PSNR": [45.1172, 0.029], "KAIST_SAM": [2.3834, 0.0096]},
        "TPTransformer [26]": {
            "CAVE_PSNR": [48.9415, 0.041], "CAVE_SAM": [2.3562, 0.0121],
            "ICVL_PSNR": [58.3761, 0.023], "ICVL_SAM": [0.3389, 0.0019],
            "KAIST_PSNR": [44.9806, 0.034], "KAIST_SAM": [2.4306, 0.0110]},
        "SVR-DUN (ours)": {
            "CAVE_PSNR": [49.4612, 0.031], "CAVE_SAM": [2.2528, 0.0092],
            "ICVL_PSNR": [58.6415, 0.018], "ICVL_SAM": [0.3240, 0.0014],
            "KAIST_PSNR": [45.2981, 0.026], "KAIST_SAM": [2.3241, 0.0085]},
    },
}

TABLE_XIV = {
    "_source": "Paper Table XIV", "_provenance": PROVENANCE,
    "_note": ("Holm-adjusted over the 3 baselines x 4 metrics = 12 comparisons "
              "within each dataset; only PSNR and SAM are printed, ERGAS and "
              "UIQI are in the supplementary material."),
    "_columns": ["dataset", "baseline", "metric", "mean_delta", "ci_lo", "ci_hi",
                 "wins", "rank_biserial_r", "p_wilcoxon", "p_paired_t"],
    "n_test": {"CAVE": 12, "ICVL": 40, "KAIST": 10},
    "rows": [
        ["CAVE", "RASD-FuNet (retrained)", "PSNR", 0.3678, 0.190, 0.546, "12/12", 1.00, 5.9e-3, 6.8e-4],
        ["CAVE", "RASD-FuNet (retrained)", "SAM",  0.0890, 0.045, 0.134, "11/12", 0.97, 8.8e-3, 1.2e-3],
        ["CAVE", "Region-aware MoE",       "PSNR", 0.2576, 0.099, 0.415, "11/12", 0.95, 1.0e-2, 3.6e-3],
        ["CAVE", "Region-aware MoE",       "SAM",  0.0576, 0.018, 0.097, "11/12", 0.92, 1.2e-2, 5.3e-3],
        ["CAVE", "TPTransformer",          "PSNR", 0.5197, 0.294, 0.744, "12/12", 1.00, 5.9e-3, 4.3e-4],
        ["CAVE", "TPTransformer",          "SAM",  0.1034, 0.054, 0.154, "11/12", 0.97, 8.8e-3, 7.7e-4],
        ["ICVL", "RASD-FuNet (retrained)", "PSNR", 0.2300, 0.151, 0.309, "39/40", 1.00, 4.4e-11, 4.1e-15],
        ["ICVL", "RASD-FuNet (retrained)", "SAM",  0.0127, 0.006, 0.019, "35/40", 0.94, 1.0e-8, 2.3e-9],
        ["ICVL", "Region-aware MoE",       "PSNR", 0.1308, 0.058, 0.202, "35/40", 0.92, 3.0e-8, 5.9e-9],
        ["ICVL", "Region-aware MoE",       "SAM",  0.0083, 0.002, 0.014, "32/40", 0.83, 1.8e-6, 1.2e-6],
        ["ICVL", "TPTransformer",          "PSNR", 0.2654, 0.171, 0.358, "39/40", 1.00, 6.0e-11, 2.6e-14],
        ["ICVL", "TPTransformer",          "SAM",  0.0149, 0.008, 0.022, "37/40", 0.97, 2.0e-9, 1.7e-10],
        ["KAIST", "RASD-FuNet (retrained)", "PSNR", 0.2819, 0.135, 0.424, "9/10", 0.96, 3.9e-2, 4.6e-3],
        ["KAIST", "RASD-FuNet (retrained)", "SAM",  0.0890, 0.047, 0.131, "10/10", 1.00, 2.3e-2, 2.6e-3],
        ["KAIST", "Region-aware MoE",       "PSNR", 0.1809, 0.038, 0.327, "9/10", 0.89, 4.1e-2, 2.0e-2],
        ["KAIST", "Region-aware MoE",       "SAM",  0.0593, 0.014, 0.104, "9/10", 0.93, 4.1e-2, 2.0e-2],
        ["KAIST", "TPTransformer",          "PSNR", 0.3175, 0.149, 0.485, "9/10", 0.96, 3.9e-2, 4.6e-3],
        ["KAIST", "TPTransformer",          "SAM",  0.1065, 0.056, 0.157, "10/10", 1.00, 2.3e-2, 2.6e-3],
    ],
}

ALL_TABLES = {
    "III": TABLE_III, "IV": TABLE_IV, "V": TABLE_V, "VI": TABLE_VI,
    "VII": TABLE_VII, "VIII": TABLE_VIII, "IX": TABLE_IX, "X": TABLE_X,
    "XI": TABLE_XI, "XII": TABLE_XII, "XIII": TABLE_XIII, "XIV": TABLE_XIV,
}


def baseline_name_map():
    """Table XIV uses short baseline names; Table XIII uses long ones."""
    return {
        "RASD-FuNet (retrained)": "RASD-FuNet [6] (retrained)",
        "Region-aware MoE": "Region-aware MoE [32]",
        "TPTransformer": "TPTransformer [26]",
    }
