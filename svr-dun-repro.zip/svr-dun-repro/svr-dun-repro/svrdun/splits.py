"""Dataset split files: specification, materialisation and verification.

The paper fixes each split by a RULE, not by a list of file names
(Section V-A):

    CAVE     32 scenes; "the last 12 images are used for testing"
    ICVL     200 scenes; "40 are drawn at random for testing"
    KAIST    30 scenes; "its last 10 images form the test set"
    GF5-GF1  one real pair, no reference, zero-shot

Two things follow, and this module refuses to hide either.

1. "The last 12" needs an ORDERING, and the paper does not state one. This
   module assumes alphabetical order by scene name and records that assumption
   in every split file it writes. If the authors ordered by the dataset's own
   numbering instead, the split differs and the test images are not the same.

2. ICVL's "40 at random" needs a SEED, and the paper does not state one. An
   exactly matching ICVL split therefore cannot be reconstructed from the
   paper. The seed used here is recorded in the file.

A split file is therefore in one of two states:

    SPECIFIED      rule, ordering, seed and expected counts are fixed, but the
                   file names are not yet known. Ship this; it is honest.
    MATERIALISED   the rule has been applied to a real directory, so the file
                   names and their SHA-256 are fixed and checkable.

`verify_split` compares a materialised split against a directory and FAILS
LOUDLY on any mismatch rather than silently re-deriving it.
"""
from __future__ import annotations

import json
import os
from typing import Any

from .provenance import sha256_obj
from .reported import PAPER_CONFIG

__all__ = ["CANONICAL_SCENES", "ICVL_SPLIT_SEED", "ORDERING_ASSUMPTION",
           "specified_split", "materialise_split", "verify_split",
           "write_specified_splits", "load_split_file", "split_summary"]

ICVL_SPLIT_SEED = 20240501
ORDERING_ASSUMPTION = "alphabetical by scene file stem (case-insensitive)"

#: Publicly known scene names, offered so a split can be CHECKED rather than
#: taken on trust. `verify_split` fails if a directory does not match, so a
#: wrong list here produces a loud error, never a silent mis-split.
CANONICAL_SCENES: dict[str, dict[str, Any]] = {
    "CAVE": {
        "source": ("The 32 scenes of the Columbia CAVE multispectral database. "
                   "Listed here in alphabetical order so the paper's 'last 12' "
                   "can be made concrete and checked."),
        "confidence": ("The CAVE scene names are standard and widely published. "
                       "Treat this list as a checkable claim, not as ground "
                       "truth: verify_split compares it against your copy."),
        "scenes": [
            "balloons", "beads", "cd", "chart_and_stuffed_toy", "clay", "cloth",
            "egyptian_statue", "face", "fake_and_real_beers",
            "fake_and_real_food", "fake_and_real_lemon_slices",
            "fake_and_real_lemons", "fake_and_real_peppers",
            "fake_and_real_strawberries", "fake_and_real_sushi",
            "fake_and_real_tomatoes", "feathers", "flowers", "glass_tiles",
            "hairs", "jelly_beans", "oil_painting", "paints", "photo_and_face",
            "pompoms", "real_and_fake_apples", "real_and_fake_peppers",
            "sponges", "stuffed_toys", "superballs", "thread_spools",
            "watercolors",
        ],
    },
    "ICVL": {
        "source": "ICVL hyperspectral database (Arad and Ben-Shahar).",
        "confidence": ("The 200 ICVL scene names are NOT listed here: this "
                       "repository cannot assert them reliably, and the "
                       "paper's random 40 has no published seed, so an "
                       "exactly matching split cannot be rebuilt from the "
                       "paper in any case. Materialise from your own copy."),
        "scenes": None,
    },
    "KAIST": {
        "source": "KAIST hyperspectral dataset (Choi et al.).",
        "confidence": ("The 30 KAIST scene names are NOT listed here; this "
                       "repository cannot assert them reliably. Materialise "
                       "from your own copy."),
        "scenes": None,
    },
    "GF5-GF1": {
        "source": "Gaofen-5 / Gaofen-1 real pair.",
        "confidence": ("A single scene pair with no reference image; there is "
                       "no train/test split to reconstruct."),
        "scenes": None,
    },
}


def _rule_for(dataset: str) -> dict:
    info = PAPER_CONFIG["datasets"].get(dataset, {})
    if dataset == "GF5-GF1":
        return {"kind": "zero_shot", "n_test": 0,
                "statement": ("One real pair, no reference. Section V-A uses "
                              "the zero-shot strategy of [38].")}
    rule = "last" if dataset in ("CAVE", "KAIST") else "random"
    return {
        "kind": rule,
        "n_scenes": info.get("scenes"),
        "n_test": info.get("n_test"),
        "statement": {
            "CAVE": "the last 12 images are used for testing",
            "KAIST": "its last 10 images form the test set",
            "ICVL": "40 are drawn at random for testing",
        }[dataset],
        "ordering_assumption": ORDERING_ASSUMPTION if rule == "last" else None,
        "seed": ICVL_SPLIT_SEED if rule == "random" else None,
    }


def specified_split(dataset: str) -> dict:
    """A split file that fixes the rule but not yet the file names."""
    rule = _rule_for(dataset)
    canon = CANONICAL_SCENES.get(dataset, {})
    scenes = canon.get("scenes")
    out: dict[str, Any] = {
        "dataset": dataset,
        "state": "SPECIFIED",
        "provenance": "DERIVED_REPORTED",
        "rule": rule,
        "scene_name_source": canon.get("source"),
        "scene_name_confidence": canon.get("confidence"),
        "scene_names": scenes,
        "materialised_from": None,
        "train": None,
        "test": None,
        "caveats": [],
    }
    if rule.get("ordering_assumption"):
        out["caveats"].append(
            "The paper does not state the ordering behind '%s'. This split "
            "assumes %s. A different ordering gives a different test set."
            % (rule["statement"], rule["ordering_assumption"]))
    if rule.get("seed") is not None:
        out["caveats"].append(
            "The paper does not state the seed behind '%s'. This split uses "
            "seed %d, which is this repository's choice; an exactly matching "
            "ICVL split cannot be rebuilt from the paper."
            % (rule["statement"], rule["seed"]))
    if scenes:
        n_test = rule["n_test"]
        ordered = sorted(scenes, key=str.lower)
        out["train_expected"] = ordered[:-n_test]
        out["test_expected"] = ordered[-n_test:]
        out["caveats"].append(
            "train_expected / test_expected are derived from a scene list this "
            "repository asserts but has not verified. Run verify_split against "
            "your copy before relying on them.")
    out["spec_sha256"] = sha256_obj({k: out[k] for k in
                                     ("dataset", "rule", "scene_names")})
    return out


def _stems(paths: list[str]) -> list[str]:
    return [os.path.splitext(os.path.basename(p))[0] for p in paths]


def materialise_split(dataset: str, files: list[str]) -> dict:
    """Apply the rule to a real list of files, fixing names and hashes."""
    import numpy as np

    spec = specified_split(dataset)
    rule = spec["rule"]
    ordered = sorted(files, key=lambda p: os.path.basename(p).lower())
    n = len(ordered)
    expected = rule.get("n_scenes")

    warnings: list[str] = []
    if expected and n != expected:
        warnings.append(
            f"found {n} scene files but the paper describes {expected} for "
            f"{dataset}; the split will not match the paper's")

    if rule["kind"] == "last":
        n_test = min(rule["n_test"], n)
        test_idx = list(range(n - n_test, n))
    elif rule["kind"] == "random":
        rng = np.random.default_rng(rule["seed"])
        test_idx = sorted(rng.choice(n, size=min(rule["n_test"], n),
                                     replace=False).tolist())
    else:
        test_idx = []
    tset = set(test_idx)
    train_idx = [i for i in range(n) if i not in tset]

    out = dict(spec)
    out.update({
        "state": "MATERIALISED",
        "provenance": "COMPUTED",
        "materialised_from": os.path.commonpath(ordered) if ordered else None,
        "n_files_found": n,
        "train": [os.path.basename(ordered[i]) for i in train_idx],
        "test": [os.path.basename(ordered[i]) for i in test_idx],
        "train_paths": [ordered[i] for i in train_idx],
        "test_paths": [ordered[i] for i in test_idx],
        "warnings": warnings,
    })
    out["split_sha256"] = sha256_obj({"train": out["train"], "test": out["test"],
                                      "rule": rule})
    # does the directory match the scene list this repository asserted?
    if spec.get("scene_names"):
        found = set(s.lower() for s in _stems(ordered))
        claimed = set(s.lower() for s in spec["scene_names"])
        out["scene_list_matches_directory"] = (found == claimed)
        if found != claimed:
            out["warnings"].append(
                "the directory does not match this repository's scene list: "
                f"missing {sorted(claimed - found)[:5]}, "
                f"unexpected {sorted(found - claimed)[:5]}")
    return out


def verify_split(split: dict, files: list[str]) -> dict:
    """Check a materialised split against a directory. Fails loudly."""
    problems: list[str] = []
    if split.get("state") != "MATERIALISED":
        problems.append("split is not materialised; nothing to verify")
        return {"ok": False, "problems": problems}

    have = sorted(os.path.basename(p) for p in files)
    want = sorted(list(split["train"]) + list(split["test"]))
    if have != want:
        missing = sorted(set(want) - set(have))[:8]
        extra = sorted(set(have) - set(want))[:8]
        problems.append(f"file set differs: missing {missing}, extra {extra}")
    if set(split["train"]) & set(split["test"]):
        problems.append("train and test overlap")
    n_test_rule = split["rule"].get("n_test")
    if n_test_rule and len(split["test"]) != n_test_rule:
        problems.append(f"test has {len(split['test'])} scenes, rule says {n_test_rule}")

    recomputed = sha256_obj({"train": split["train"], "test": split["test"],
                             "rule": split["rule"]})
    if recomputed != split.get("split_sha256"):
        problems.append("split_sha256 does not match its own contents "
                        "(the file has been edited)")
    return {"ok": not problems, "problems": problems,
            "split_sha256": split.get("split_sha256"),
            "n_train": len(split.get("train") or []),
            "n_test": len(split.get("test") or [])}


def write_specified_splits(out_dir: str = "splits") -> dict:
    """Write a SPECIFIED split file for every dataset."""
    os.makedirs(out_dir, exist_ok=True)
    written = {}
    for ds in ("CAVE", "ICVL", "KAIST", "GF5-GF1"):
        sp = specified_split(ds)
        path = os.path.join(out_dir, f"{ds}_split.json")
        with open(path, "w") as fh:
            json.dump(sp, fh, indent=2, sort_keys=False)
        written[ds] = path
    readme = os.path.join(out_dir, "README.md")
    with open(readme, "w") as fh:
        fh.write(_SPLITS_README)
    written["README"] = readme
    return written


def load_split_file(path: str) -> dict:
    with open(path) as fh:
        return json.load(fh)


def split_summary(split: dict) -> str:
    lines = [f"{split['dataset']}  [{split['state']}]  provenance={split['provenance']}",
             f"  rule   : {split['rule']['statement']}"]
    if split["rule"].get("ordering_assumption"):
        lines.append(f"  order  : {split['rule']['ordering_assumption']} (ASSUMED)")
    if split["rule"].get("seed") is not None:
        lines.append(f"  seed   : {split['rule']['seed']} (this repository's choice)")
    if split.get("train") is not None:
        lines.append(f"  train  : {len(split['train'])} scenes")
        lines.append(f"  test   : {len(split['test'])} scenes -> {split['test'][:4]}...")
        lines.append(f"  sha256 : {split.get('split_sha256')}")
    elif split.get("test_expected"):
        lines.append(f"  expected test ({len(split['test_expected'])}): "
                     f"{split['test_expected'][:4]}...")
    for c in split.get("caveats", []):
        lines.append(f"  CAVEAT : {c}")
    for w in split.get("warnings", []) or []:
        lines.append(f"  WARNING: {w}")
    return "\n".join(lines)


_SPLITS_README = """# Split files

Each file fixes a train/test split for one dataset. A file is in one of two
states:

* **SPECIFIED** — the rule, the ordering assumption, the seed and the expected
  counts are fixed, but the file names are not yet known. This is what ships,
  because the datasets are gated and cannot be bundled.
* **MATERIALISED** — the rule has been applied to a real directory, so the file
  names and a SHA-256 over them are fixed. Section 7 of the notebook writes
  this once you set `DATA_ROOT`.

## Two gaps the paper leaves, stated rather than hidden

**Ordering.** The paper says "the last 12 images" (CAVE) and "its last 10
images" (KAIST) without stating an order. These files assume alphabetical order
by scene name. If the authors ordered by the dataset's own numbering, the test
sets differ and the numbers are not comparable.

**ICVL's seed.** The paper draws 40 ICVL scenes "at random" and does not state
a seed, so an exactly matching ICVL split cannot be reconstructed from the
paper. These files record the seed this repository used (20240501). If you have
the authors' split file, use it instead — drop it in here and the notebook will
pick it up.

## Verifying

`svrdun.splits.verify_split` compares a materialised split against a directory
and fails on any mismatch: a different file set, an overlap between train and
test, a test count that contradicts the rule, or a SHA-256 that does not match
the file's own contents. It never silently re-derives a split.
"""
