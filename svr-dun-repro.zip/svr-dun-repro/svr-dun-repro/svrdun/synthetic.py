"""The synthetic motivating scene of Fig. 1, rebuilt from its description.

Fig. 1 caption: "a synthetic 31-band scene (400-700 nm, 256x256 pixels) built
from eight synthetic endmember spectra", with four regions whose median
relative residual under ONE global rank-2 subspace is roughly

    sky 6e-4,  canopy 1e-2,  field 3e-2,  building 0.17

and whose local spectral rank (Definition 1, w = 8, delta = 2e-3, K_max = 5)
spans several values across the image.

The authors' exact endmember spectra are not published, so this is a
RECONSTRUCTION built to the stated specification, not the original scene. It is
deterministic given `seed`, which makes it a stable test fixture: the whole
pipeline can be exercised end-to-end with no gated data, and the resulting
numbers are honest outputs of this code on this scene -- they are simply not
the paper's scene.
"""
from __future__ import annotations

import numpy as np

from .responses import wavelengths

__all__ = ["endmembers", "synthetic_scene", "region_labels", "REGION_NAMES"]

REGION_NAMES = ["sky", "building", "field", "canopy"]


def endmembers(n: int = 8, C: int = 31, lo: float = 400.0, hi: float = 700.0,
               seed: int = 0) -> np.ndarray:
    """Eight designed, non-negative endmember spectra on the band grid.

    They are designed rather than drawn at random so that their mutual
    coherence is controlled: the natural materials (0-5) are smooth and
    partly correlated, while the man-made ones (6-7) carry narrow features
    that no low-rank fit to the natural part can represent. That contrast is
    what makes the building block in Fig. 1(b) the worst-fitted region.
    """
    wl = wavelengths(C, lo, hi)
    u = (wl - lo) / max(hi - lo, 1e-9)                 # normalised wavelength

    def g(c, w, a=1.0):
        return a * np.exp(-0.5 * ((wl - c) / w) ** 2)

    E = np.zeros((max(n, 8), C), dtype=np.float64)
    # 0 sky: Rayleigh-like, falling with wavelength
    E[0] = 0.25 + 0.75 * np.exp(-2.6 * u)
    # 1 dry soil: smooth ramp rising to the red
    E[1] = 0.18 + 0.62 * u ** 0.75
    # 2 green vegetation: chlorophyll dip then red edge
    E[2] = 0.08 + g(550, 32, 0.34) - g(672, 24, 0.22) + 0.52 / (1 + np.exp(-(wl - 697) / 7.0))
    # 3 senescent vegetation: broader, shifted
    E[3] = 0.12 + g(575, 46, 0.40) - g(660, 30, 0.12) + 0.34 / (1 + np.exp(-(wl - 690) / 11.0))
    # 4 shadowed foliage: darker, flatter
    E[4] = 0.06 + 0.30 * np.exp(-1.1 * u) + g(545, 40, 0.10)
    # 5 wet ground: dark with a mild blue lift
    E[5] = 0.10 + 0.22 * np.exp(-3.2 * u) + 0.06 * u
    # 6 painted metal: narrow saturated peak in the orange
    E[6] = 0.07 + g(615, 11, 0.86) + g(470, 9, 0.18)
    # 7 glazing / coated surface: twin narrow peaks, blue and green
    E[7] = 0.06 + g(455, 9, 0.70) + g(525, 8, 0.52) + 0.04 * u
    E = E[:n]
    E = np.clip(E, 0.02, None)
    E /= E.max()
    return E


def region_labels(H: int = 256, W: int = 256) -> np.ndarray:
    """Integer map: 0 sky, 1 building, 2 field, 3 canopy (layout of Fig. 1(a))."""
    lab = np.zeros((H, W), dtype=np.int64)
    lab[: H // 3, :] = 0                       # sky across the top
    lab[H // 3:, : W // 2] = 2                 # field, lower left
    lab[H // 3:, W // 2:] = 3                  # canopy, lower right
    b0, b1 = int(H * 0.42), int(H * 0.78)
    c0, c1 = int(W * 0.08), int(W * 0.40)
    lab[b0:b1, c0:c1] = 1                      # building block inside the field
    return lab


def synthetic_scene(H: int = 256, W: int = 256, C: int = 31,
                    lo: float = 400.0, hi: float = 700.0,
                    n_endmembers: int = 8, seed: int = 0) -> dict:
    """Build the scene and return the cube, labels, endmembers and abundances.

    Region design, chosen to span the local ranks the paper describes:
      sky       1 endmember, very smooth gradient            -> rank ~1
      field     2 endmembers, slow spatial mixing            -> rank ~2
      canopy    4-5 endmembers, textured mixing              -> higher rank
      building  3 endmembers in hard vertical stripes        -> highest residual
                under a single global rank-2 subspace
    """
    rng = np.random.default_rng(seed)
    E = endmembers(n_endmembers, C, lo, hi, seed=seed)
    lab = region_labels(H, W)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
    ny, nx = yy / max(H - 1, 1), xx / max(W - 1, 1)

    A = np.zeros((H, W, n_endmembers), dtype=np.float64)

    # --- sky: a single endmember. Brightness varies but the SUBSPACE does not,
    #     so the region is exactly rank one, as "open sky is close to rank one".
    m = lab == 0
    A[m, 0] = 1.0

    # --- field: exactly two endmembers mixing slowly -> rank two
    m = lab == 2
    t = 0.5 + 0.5 * np.sin(2 * np.pi * (0.9 * nx[m] + 0.4 * ny[m]))
    A[m, 1] = 0.70 + 0.25 * t
    A[m, 2] = 0.30 + 0.25 * (1.0 - t)

    # --- canopy: four endmembers with fine texture -> intermediate rank
    m = lab == 3
    tex = (np.sin(14 * np.pi * nx) * np.cos(17 * np.pi * ny)
           + 0.6 * np.sin(31 * np.pi * (nx + ny)))
    tex = (tex - tex.min()) / (tex.max() - tex.min() + 1e-12)
    A[m, 2] = 0.40 + 0.28 * tex[m]
    A[m, 3] = 0.28 + 0.26 * (1.0 - tex[m])
    A[m, 4] = 0.20 + 0.22 * np.abs(np.sin(9 * np.pi * nx[m]))
    A[m, 5] = 0.12 + 0.18 * rng.random(int(m.sum()))

    # --- building: hard vertical stripes of three further endmembers, which no
    #     low-rank subspace fitted to the rest of the scene can represent
    m = lab == 1
    stripe = ((xx // 5).astype(int) % 3)
    for j, e in enumerate((5, 6, 7)):
        sel = m & (stripe == j)
        A[sel, e] = 1.0
        A[sel, (e + 1) % n_endmembers] = 0.25

    A = np.clip(A, 0.0, None)
    tot = A.sum(axis=2, keepdims=True)
    A = A / np.maximum(tot, 1e-12)

    # per-pixel illumination, which scales spectra without changing the local
    # spectral subspace (so it does not raise any region's rank)
    shade = (0.78 + 0.22 * (1.0 - ny)) * (1.0 + 0.04 * np.sin(6 * np.pi * nx))
    shade = np.where(lab == 3, shade * (0.85 + 0.15 * tex), shade)

    cube = np.einsum("hwe,ec->hwc", A, E) * shade[..., None]
    cube = np.clip(cube, 0.0, None)
    cube = cube / cube.max()                       # normalise by max, Section V-A
    return {"cube": cube, "labels": lab, "endmembers": E, "abundances": A,
            "region_names": REGION_NAMES, "wavelengths": wavelengths(C, lo, hi),
            "seed": seed,
            "_provenance_note": ("Reconstruction of the Fig. 1 scene from its "
                                 "published description; not the authors' "
                                 "original endmember spectra.")}
