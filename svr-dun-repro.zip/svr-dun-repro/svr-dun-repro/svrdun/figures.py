"""Qualitative figures.

Every figure is written with an explicit provenance tag in its caption file so
that a plot of REPORTED numbers can never be mistaken for a plot of results
this repository computed.

  fig1_motivation        Fig. 1  pseudo-colour, global rank-2 residual,
                                 binary split, local spectral rank
  fig4_rfe               Fig. 4  windowed residual curves and the gates
  fig5_comparison        Fig. 5/7 pseudo-colour and absolute error maps
  fig9_budget            Fig. 9  PSNR against FLOPs across budgets
  fig10_rank_stages      Fig. 10 rank field after each stage
  fig_recoverability     Table XII as a plot: sigma_min(R D_k)/||R||
"""
from __future__ import annotations

import json
import os

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, LogNorm

__all__ = ["pseudo_colour", "fig1_motivation", "fig4_rfe", "fig5_comparison",
           "fig9_budget", "fig10_rank_stages", "fig_recoverability",
           "save_figure"]

_RANK_CMAP = "viridis"


def save_figure(fig, path: str, provenance: str, caption: str = "",
                dpi: int = 200) -> str:
    """Save a figure and a sidecar .json recording its provenance."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    with open(os.path.splitext(path)[0] + ".caption.json", "w") as fh:
        json.dump({"figure": os.path.basename(path), "provenance": provenance,
                   "caption": caption}, fh, indent=2)
    return path


def pseudo_colour(cube: np.ndarray, bands=(26, 16, 6), gamma: float = 0.85,
                  percentile: float = 99.0) -> np.ndarray:
    """Pseudo-colour composite, using the bands of the Fig. 1 caption."""
    a = np.asarray(cube, dtype=np.float64)
    C = a.shape[2]
    idx = [min(max(b, 0), C - 1) for b in bands]
    rgb = a[:, :, idx]
    hi = np.percentile(rgb, percentile)
    rgb = np.clip(rgb / max(hi, 1e-12), 0, 1) ** gamma
    return rgb


# ------------------------------------------------------------------ Fig. 1
def fig1_motivation(scene: dict, D2: np.ndarray, rho: np.ndarray,
                    r_split: float = 0.5, out: str = "fig1_motivation.png",
                    provenance: str = "COMPUTED") -> str:
    """Four panels: composite, global rank-2 residual, binary split, local rank."""
    from .rank import residual_curve
    cube = scene["cube"]
    e, energy = residual_curve(cube, D2)
    rel = e[..., 2] / np.maximum(energy, 1e-12)

    thr = np.quantile(rel, r_split)
    split = (rel > thr)

    fig, ax = plt.subplots(1, 4, figsize=(15, 3.6))
    ax[0].imshow(pseudo_colour(cube))
    ax[0].set_title("(a) pseudo-colour composite")

    vmin = max(rel[rel > 0].min(), 1e-8) if np.any(rel > 0) else 1e-8
    im = ax[1].imshow(np.maximum(rel, vmin), norm=LogNorm(vmin=vmin, vmax=rel.max()),
                      cmap="magma")
    ax[1].set_title("(b) residual, one global rank-2 subspace")
    fig.colorbar(im, ax=ax[1], fraction=0.046)

    ax[2].imshow(split, cmap="gray_r")
    ax[2].set_title(f"(c) binary split at r = {r_split}")

    kmax = int(np.nanmax(rho))
    levels = np.arange(-0.5, kmax + 1.5, 1.0)
    norm = BoundaryNorm(levels, ncolors=256)
    im = ax[3].imshow(rho, cmap=_RANK_CMAP, norm=norm)
    ax[3].set_title("(d) local spectral rank")
    fig.colorbar(im, ax=ax[3], fraction=0.046,
                 ticks=np.arange(0, kmax + 1))

    for a in ax:
        a.set_xticks([]); a.set_yticks([])
    fig.tight_layout()
    return save_figure(fig, out, provenance,
                       "Motivation: one global rank is a compromise; the local "
                       "spectral rank varies across the scene.")


# ------------------------------------------------------------------ Fig. 4
def fig4_rfe(cube: np.ndarray, D: np.ndarray, points: list[tuple[int, int]],
             labels: list[str], delta: float = 2e-3, w: int = 8,
             taus=(0.15, 0.01), out: str = "fig4_rfe.png",
             provenance: str = "COMPUTED") -> str:
    """Residual curves at a few locations, and the gates of equation (9)."""
    from .rank import gate, windowed_relative_residual
    eps = windowed_relative_residual(cube, D, w)
    K = eps.shape[2] - 1

    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ks = np.arange(0, K + 1)
    for (y, x), lab in zip(points, labels):
        curve = eps[y, x, :]
        ax[0].semilogy(ks, np.maximum(curve, 1e-10), marker="o", label=lab)
        below = np.where(curve <= delta)[0]
        if below.size:
            k0 = int(below[0])
            ax[0].semilogy([k0], [max(curve[k0], 1e-10)], marker="o",
                           mfc="none", mec="k", ms=12)
    ax[0].axhline(delta, ls="--", c="k", lw=1)
    ax[0].set_xlabel("number of atoms k")
    ax[0].set_ylabel(r"windowed relative residual $\varepsilon_k(p)$")
    ax[0].set_title("(a) residual curves")
    ax[0].legend(fontsize=8)

    rr = np.linspace(0, K, 400)
    for tau, ls in zip(taus, ("-", ":")):
        for k in range(1, K + 1):
            ax[1].plot(rr, gate(rr, k, tau), ls=ls, lw=1.2,
                       color=plt.cm.viridis((k - 1) / max(K - 1, 1)))
    ax[1].set_xlabel(r"rank $\rho_p$")
    ax[1].set_ylabel(r"gate $g_k(\rho_p)$")
    ax[1].set_title(f"(b) gates, tau = {taus[0]} (solid) and {taus[1]} (dotted)")
    fig.tight_layout()
    return save_figure(fig, out, provenance,
                       "Behaviour of the rank field estimator.")


# ---------------------------------------------------------------- Fig. 5/7
def fig5_comparison(ref: np.ndarray, estimates: dict, out: str = "fig5.png",
                    provenance: str = "COMPUTED", err_vmax: float | None = None,
                    boxes: list | None = None) -> str:
    """Top row pseudo-colour, bottom row absolute error on a common scale."""
    names = ["Reference"] + list(estimates.keys())
    cubes = [ref] + [estimates[k] for k in estimates]
    errs = [None] + [np.abs(estimates[k] - ref).mean(axis=2) for k in estimates]
    finite = [e for e in errs if e is not None]
    vmax = err_vmax if err_vmax is not None else (
        float(np.percentile(np.concatenate([e.ravel() for e in finite]), 99))
        if finite else 1.0)

    n = len(names)
    fig, ax = plt.subplots(2, n, figsize=(2.6 * n, 5.4))
    if n == 1:
        ax = ax.reshape(2, 1)
    for i, (nm, cb) in enumerate(zip(names, cubes)):
        ax[0, i].imshow(pseudo_colour(cb))
        ax[0, i].set_title(nm, fontsize=9)
        ax[0, i].set_xticks([]); ax[0, i].set_yticks([])
        if errs[i] is None:
            ax[1, i].axis("off")
        else:
            im = ax[1, i].imshow(errs[i], cmap="inferno", vmin=0, vmax=vmax)
            ax[1, i].set_xticks([]); ax[1, i].set_yticks([])
            if i == n - 1:
                fig.colorbar(im, ax=ax[1, :].tolist(), fraction=0.02)
    if boxes:
        for (y, x, h, wd) in boxes:
            for i in range(n):
                ax[0, i].add_patch(plt.Rectangle((x, y), wd, h, ec="red",
                                                 fc="none", lw=1.2))
    return save_figure(fig, out, provenance,
                       "Visual comparison with absolute error maps on a common "
                       "colour scale.")


# ------------------------------------------------------------------ Fig. 9
def fig9_budget(curves: dict, out: str = "fig9_budget.png",
                provenance: str = "COMPUTED", xlabel: str = "FLOPs (G)",
                ylabel: str = "PSNR (dB)") -> str:
    """PSNR against FLOPs. `curves` maps a label to (flops, psnr) sequences."""
    fig, ax = plt.subplots(figsize=(5.4, 4.0))
    for label, data in curves.items():
        x, y = np.asarray(data[0], float), np.asarray(data[1], float)
        style = dict(marker="o", lw=1.6)
        if len(x) == 1:
            ax.scatter(x, y, label=label, zorder=3)
        else:
            order = np.argsort(x)
            ax.plot(x[order], y[order], label=label, **style)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    return save_figure(fig, out, provenance,
                       "Accuracy against computational budget.")


# ----------------------------------------------------------------- Fig. 10
def fig10_rank_stages(rhos: list[np.ndarray], K_max: int,
                      out: str = "fig10_rank_stages.png",
                      provenance: str = "COMPUTED",
                      confidence: np.ndarray | None = None) -> str:
    """Rank field after each stage, optionally beside a binary confidence map."""
    n = len(rhos) + (1 if confidence is not None else 0)
    fig, ax = plt.subplots(1, n, figsize=(2.6 * n, 3.0))
    if n == 1:
        ax = [ax]
    levels = np.arange(-0.5, K_max + 1.5, 1.0)
    norm = BoundaryNorm(levels, ncolors=256)
    for t, r in enumerate(rhos):
        im = ax[t].imshow(r, cmap=_RANK_CMAP, norm=norm)
        ax[t].set_title(f"stage {t + 1}", fontsize=9)
        ax[t].set_xticks([]); ax[t].set_yticks([])
    if confidence is not None:
        ax[-1].imshow(confidence, cmap="gray_r")
        ax[-1].set_title("binary confidence", fontsize=9)
        ax[-1].set_xticks([]); ax[-1].set_yticks([])
    fig.colorbar(im, ax=ax, fraction=0.02, ticks=np.arange(0, K_max + 1))
    return save_figure(fig, out, provenance,
                       "Rank field after each unfolded stage.")


# ------------------------------------------------------- recoverability
def fig_recoverability(table: list[dict], out: str = "fig_recoverability.png",
                       provenance: str = "COMPUTED", epsilon: float = 0.01) -> str:
    """sigma_min(R D_k)/||R||_2 against k, one line per sensor (Table XII)."""
    fig, ax = plt.subplots(figsize=(5.6, 4.0))
    for row in table:
        ks = np.arange(1, len(row["sigma"]) + 1)
        ax.semilogy(ks, np.maximum(np.asarray(row["sigma"], float), 1e-6),
                    marker="o", label=f"{row['sensor']} (L={row['L']})")
    ax.axhline(epsilon, ls="--", c="k", lw=1, label=f"epsilon = {epsilon}")
    ax.set_xlabel("number of atoms k")
    ax.set_ylabel(r"$\sigma_{\min}(\mathbf{R}\mathbf{D}_k)/\|\mathbf{R}\|_2$")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    return save_figure(fig, out, provenance,
                       "Recoverability across sensor configurations "
                       "(Proposition 2).")
