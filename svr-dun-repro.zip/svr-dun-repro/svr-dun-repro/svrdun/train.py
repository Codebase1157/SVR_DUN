"""Training and evaluation loops with checkpointing, resume and seeding.

Schedule of Section V-C: Adam, initial learning rate 4e-4 with cosine
annealing, batch size 16, and 1000 / 120 / 300 epochs on CAVE / ICVL / KAIST.
lambda_rho is drawn per mini-batch from a log-uniform distribution on
[1e-4, 1e-2]; the gate temperature tau is annealed from 1 to 0.05 on a cosine
schedule across training.

QUICK mode shrinks epochs, patch count and image size so that the whole
pipeline executes end to end in minutes. It proves the code path; it does not
reproduce the paper's numbers, and every artifact it writes says so.
"""
from __future__ import annotations

import json
import math
import os
import random
import time
from dataclasses import asdict, dataclass

import numpy as np

__all__ = ["TrainConfig", "set_seed", "sample_lambda_rho", "train_model",
           "evaluate_model", "save_checkpoint", "load_checkpoint"]


@dataclass
class TrainConfig:
    mode: str = "QUICK"              # QUICK or FULL
    dataset: str = "SYNTHETIC"
    epochs: int = 6
    batch_size: int = 4
    lr: float = 4e-4
    lr_schedule: str = "cosine"
    lambda_min: float = 1e-4
    lambda_max: float = 1e-2
    tau_start: float = 1.0
    tau_end: float = 0.05
    alpha1: float = 0.1
    alpha2: float = 0.01
    seed: int = 1
    patch: int = 64
    scale: int = 8
    grad_clip: float = 1.0
    log_every: int = 1
    ckpt_every: int = 1
    amp: bool = False
    device: str = "auto"

    def as_dict(self):
        return asdict(self)

    @staticmethod
    def full_for(dataset: str, seed: int = 1) -> TrainConfig:
        from .reported import PAPER_CONFIG
        ep = PAPER_CONFIG["epochs"].get(dataset, 1000)
        return TrainConfig(mode="FULL", dataset=dataset, epochs=ep,
                           batch_size=PAPER_CONFIG["batch_size"],
                           lr=PAPER_CONFIG["lr_init"], seed=seed,
                           patch=PAPER_CONFIG["crop_hr"],
                           scale=PAPER_CONFIG["scale_s"])


def set_seed(seed: int, deterministic: bool = True):
    """Seed every generator the run touches and record what was set."""
    import torch
    random.seed(seed)
    np.random.seed(seed % (2 ** 32))
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    info = {"python_random": seed, "numpy": seed, "torch": seed}
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        info["cudnn_deterministic"] = True
    return info


def sample_lambda_rho(n: int, lo: float, hi: float,
                      generator=None) -> np.ndarray:
    """Log-uniform draw on [lo, hi] (Section IV-F)."""
    import torch
    u = torch.rand(n, generator=generator)
    return torch.exp(math.log(lo) + u * (math.log(hi) - math.log(lo)))


def pick_device(spec: str = "auto"):
    import torch
    if spec != "auto":
        return torch.device(spec)
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def save_checkpoint(path: str, model, optim, epoch: int, cfg: TrainConfig,
                    history: list, extra: dict | None = None):
    import torch
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    torch.save({
        "model": model.state_dict(),
        "optim": optim.state_dict() if optim is not None else None,
        "epoch": epoch,
        "train_config": cfg.as_dict(),
        "model_config": model.cfg.as_dict(),
        "history": history,
        "extra": extra or {},
    }, path)
    return path


def load_checkpoint(path: str, model=None, optim=None, map_location="cpu"):
    import torch
    ck = torch.load(path, map_location=map_location, weights_only=False)
    if model is not None:
        model.load_state_dict(ck["model"])
    if optim is not None and ck.get("optim"):
        optim.load_state_dict(ck["optim"])
    return ck


def _to_nchw(batch_hwc, device, dtype):
    import torch
    a = np.ascontiguousarray(np.transpose(batch_hwc, (0, 3, 1, 2)))
    return torch.as_tensor(a, device=device, dtype=dtype)


def train_model(model, train_patches: np.ndarray, R: np.ndarray,
                cfg: TrainConfig, out_dir: str,
                val_patches: np.ndarray | None = None,
                resume: bool = True, log_fn=print) -> dict:
    """Train on (N, H, W, C) patches. Returns the training history."""
    import torch

    from .model import svrdun_loss

    os.makedirs(out_dir, exist_ok=True)
    dev = pick_device(cfg.device)
    model = model.to(dev)
    dtype = torch.float32
    seed_info = set_seed(cfg.seed)

    Rt = torch.as_tensor(R, device=dev, dtype=dtype)
    model.ops.set_response(Rt)

    optim = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    total_epochs = max(int(cfg.epochs), 1)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=total_epochs)

    ck_path = os.path.join(out_dir, "checkpoint_last.pt")
    start_epoch, history = 0, []
    if resume and os.path.exists(ck_path):
        ck = load_checkpoint(ck_path, model, optim, map_location=dev)
        start_epoch = int(ck["epoch"]) + 1
        history = list(ck.get("history", []))
        for _ in range(start_epoch):
            sched.step()
        log_fn(f"resumed from {ck_path} at epoch {start_epoch}")

    N = len(train_patches)
    if N == 0:
        raise ValueError("no training patches")
    bs = max(1, min(cfg.batch_size, N))
    steps = max(1, N // bs)
    gen = torch.Generator().manual_seed(cfg.seed)

    t_start = time.time()
    for epoch in range(start_epoch, total_epochs):
        model.train()
        tau = model.tau_schedule(epoch, total_epochs, cfg.tau_start, cfg.tau_end)
        model.set_tau(tau)
        perm = torch.randperm(N, generator=gen).numpy()
        running = {"loss": 0.0, "rec": 0.0, "obs": 0.0, "nest": 0.0}

        for it in range(steps):
            idx = perm[it * bs:(it + 1) * bs]
            gt = _to_nchw(train_patches[idx], dev, dtype)
            with torch.no_grad():
                Yh = model.ops.BS(gt)
                Ym = model.ops.Rop(gt)
            lam = sample_lambda_rho(len(idx), cfg.lambda_min, cfg.lambda_max,
                                    gen).to(dev, dtype)
            X_hat, rho, aux = model(Yh, Ym, lambda_rho=lam,
                                    out_hw=gt.shape[-2:], return_aux=True)
            parts = svrdun_loss(X_hat, gt, Yh, Ym, model.ops, aux["D"],
                                alpha1=cfg.alpha1, alpha2=cfg.alpha2,
                                generator=gen)
            optim.zero_grad(set_to_none=True)
            parts["loss"].backward()
            if cfg.grad_clip:
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            optim.step()
            for k in running:
                v = parts[k]
                running[k] += float(v.detach() if hasattr(v, "detach") else v)

        sched.step()
        rec = {k: v / steps for k, v in running.items()}
        rec.update({"epoch": epoch, "tau": tau, "lr": sched.get_last_lr()[0],
                    "mean_rank": float(rho.detach().mean()),
                    "seconds": time.time() - t_start})
        history.append(rec)
        if epoch % max(cfg.log_every, 1) == 0:
            log_fn(f"epoch {epoch:4d}/{total_epochs}  loss {rec['loss']:.5f}  "
                   f"rec {rec['rec']:.5f}  tau {tau:.3f}  "
                   f"mean_rank {rec['mean_rank']:.2f}")
        if (epoch + 1) % max(cfg.ckpt_every, 1) == 0 or epoch == total_epochs - 1:
            save_checkpoint(ck_path, model, optim, epoch, cfg, history,
                            {"seed_info": seed_info, "tau": tau})

    hist_path = os.path.join(out_dir, "training_log.json")
    with open(hist_path, "w") as fh:
        json.dump({"config": cfg.as_dict(), "model_config": model.cfg.as_dict(),
                   "seed_info": seed_info, "history": history,
                   "provenance": "COMPUTED"}, fh, indent=2)
    return {"history": history, "checkpoint": ck_path, "log": hist_path,
            "epochs_run": total_epochs - start_epoch}


def evaluate_model(model, test_patches: np.ndarray, R: np.ndarray,
                   lambda_rho: float = 1e-3, scale: int = 8,
                   device: str = "auto", batch: int = 1) -> dict:
    """Per-image metrics on (N, H, W, C) test cubes. Provenance: COMPUTED."""
    import torch

    from .metrics import all_reference_metrics

    dev = pick_device(device)
    model = model.to(dev).eval()
    dtype = torch.float32
    model.ops.set_response(torch.as_tensor(R, device=dev, dtype=dtype))

    rows = []
    with torch.no_grad():
        for i in range(0, len(test_patches), batch):
            chunk = test_patches[i:i + batch]
            gt = _to_nchw(chunk, dev, dtype)
            Yh = model.ops.BS(gt)
            Ym = model.ops.Rop(gt)
            X_hat, rho = model(Yh, Ym, lambda_rho=lambda_rho,
                               out_hw=gt.shape[-2:])
            for j in range(len(chunk)):
                est = X_hat[j].permute(1, 2, 0).cpu().numpy()
                ref = chunk[j]
                m = all_reference_metrics(ref, np.clip(est, 0, None), scale=scale)
                m["image"] = i + j
                m["mean_rank"] = float(rho[j].mean())
                rows.append(m)
    agg = {k: float(np.mean([r[k] for r in rows]))
           for k in ("PSNR", "ERGAS", "SAM", "UIQI", "mean_rank")}
    return {"per_image": rows, "mean": agg, "lambda_rho": lambda_rho,
            "n_images": len(rows), "provenance": "COMPUTED"}
