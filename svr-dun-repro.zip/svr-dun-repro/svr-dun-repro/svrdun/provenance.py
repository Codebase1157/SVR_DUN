"""Provenance tracking and SHA-256 manifest for every artifact this repo writes.

The central rule of this repository
-----------------------------------
Some numbers in the SVR-DUN paper can be recomputed here from raw data; others
are transcribed from the published tables because the underlying runs need
GPU-hours and gated datasets. Those two classes must never be confused, so
every artifact carries an explicit provenance tag:

    COMPUTED          produced by running code in this repository on real
                      inputs during this session.
    REPORTED          transcribed verbatim from a table in the paper. NOT a
                      reproduction. Use only as a reference target.
    DERIVED_REPORTED  recomputed by this repository, but from REPORTED inputs
                      rather than from raw data (e.g. the paired statistics of
                      Table XIV, which are recomputed from the per-seed values
                      of Table XIII). The arithmetic is genuine; the inputs are
                      transcribed.

Anything written through `Manifest.record` is hashed and tagged, and
`Manifest.write` emits a single JSON manifest plus a human-readable report.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from typing import Any

COMPUTED = "COMPUTED"
REPORTED = "REPORTED"
DERIVED_REPORTED = "DERIVED_REPORTED"

_VALID = {COMPUTED, REPORTED, DERIVED_REPORTED}

_EXPLAIN = {
    COMPUTED: "Produced by running this repository's code on real inputs.",
    REPORTED: "Transcribed from the paper. NOT a reproduction.",
    DERIVED_REPORTED: "Recomputed by this code from REPORTED inputs.",
}


def sha256_file(path: str, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_obj(obj: Any) -> str:
    """Stable hash of a JSON-serializable object."""
    return sha256_bytes(
        json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()
    )


@dataclass
class Entry:
    path: str
    sha256: str
    bytes: int
    provenance: str
    description: str = ""
    produced_by: str = ""
    source: str = ""          # for REPORTED: which table/section of the paper
    extra: dict = field(default_factory=dict)


class Manifest:
    """Collects artifacts with provenance and writes a signed inventory."""

    def __init__(self, root: str, run_id: str | None = None):
        self.root = os.path.abspath(root)
        os.makedirs(self.root, exist_ok=True)
        self.run_id = run_id or time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        self.entries: list[Entry] = []
        self.env: dict = {}

    # ---------------------------------------------------------------- env
    def capture_environment(self) -> dict:
        """Record everything the paper's reproducibility statement promises."""
        env: dict[str, Any] = {
            "run_id": self.run_id,
            "utc_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "platform": platform.platform(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python": sys.version.replace("\n", " "),
            "python_executable": sys.executable,
        }
        try:
            import numpy
            env["numpy"] = numpy.__version__
        except Exception:
            env["numpy"] = None
        try:
            import scipy
            env["scipy"] = scipy.__version__
        except Exception:
            env["scipy"] = None
        try:
            import torch
            env["torch"] = torch.__version__
            env["torch_cuda_available"] = bool(torch.cuda.is_available())
            env["torch_cuda_version"] = getattr(torch.version, "cuda", None)
            env["cudnn"] = (
                torch.backends.cudnn.version() if torch.backends.cudnn.is_available() else None
            )
            if torch.cuda.is_available():
                env["gpus"] = [
                    {
                        "name": torch.cuda.get_device_name(i),
                        "capability": list(torch.cuda.get_device_capability(i)),
                        "total_memory_bytes": torch.cuda.get_device_properties(i).total_memory,
                    }
                    for i in range(torch.cuda.device_count())
                ]
            else:
                env["gpus"] = []
        except Exception:
            env["torch"] = None
            env["gpus"] = []
        try:
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,driver_version,memory.total",
                 "--format=csv,noheader"],
                capture_output=True, text=True, timeout=20,
            )
            env["nvidia_smi"] = out.stdout.strip() or None
        except Exception:
            env["nvidia_smi"] = None
        try:
            freeze = subprocess.run(
                [sys.executable, "-m", "pip", "freeze"],
                capture_output=True, text=True, timeout=120,
            )
            env["pip_freeze"] = freeze.stdout.strip().splitlines()
        except Exception:
            env["pip_freeze"] = []
        self.env = env
        return env

    # ------------------------------------------------------------ record
    def record(self, path: str, provenance: str, description: str = "",
               produced_by: str = "", source: str = "", **extra) -> Entry:
        if provenance not in _VALID:
            raise ValueError(f"provenance must be one of {sorted(_VALID)}, got {provenance!r}")
        if provenance == REPORTED and not source:
            raise ValueError(
                "REPORTED artifacts must name their source (e.g. 'Paper Table XIII')"
            )
        ap = os.path.abspath(path)
        if not os.path.exists(ap):
            raise FileNotFoundError(ap)
        rel = os.path.relpath(ap, self.root) if ap.startswith(self.root) else ap
        # recording the same path twice (e.g. once explicitly and once through
        # record_tree) must not duplicate it; the later call wins, so a
        # re-recorded file picks up its current hash
        for i, prev in enumerate(self.entries):
            if prev.path == rel:
                del self.entries[i]
                break
        e = Entry(
            path=rel,
            sha256=sha256_file(ap),
            bytes=os.path.getsize(ap),
            provenance=provenance,
            description=description,
            produced_by=produced_by,
            source=source,
            extra=extra,
        )
        self.entries.append(e)
        return e

    def record_tree(self, directory: str, provenance: str, description: str = "",
                    produced_by: str = "", source: str = "", skip_hidden: bool = True):
        out = []
        for dirpath, dirnames, filenames in os.walk(directory):
            if skip_hidden:
                dirnames[:] = [d for d in dirnames if not d.startswith(".")
                               and d != "__pycache__"]
            for fn in sorted(filenames):
                if skip_hidden and fn.startswith("."):
                    continue
                if fn.endswith(".pyc"):
                    continue
                out.append(self.record(os.path.join(dirpath, fn), provenance,
                                       description, produced_by, source))
        return out

    # ------------------------------------------------------------- write
    def summary(self) -> dict:
        counts: dict[str, int] = {}
        for e in self.entries:
            counts[e.provenance] = counts.get(e.provenance, 0) + 1
        return counts

    def write(self, name: str = "MANIFEST") -> tuple[str, str]:
        payload = {
            "run_id": self.run_id,
            "environment": self.env,
            "provenance_legend": _EXPLAIN,
            "summary": self.summary(),
            "artifacts": [asdict(e) for e in self.entries],
        }
        # the manifest hashes itself (minus the self-hash field)
        payload["manifest_sha256"] = sha256_obj(payload)

        jpath = os.path.join(self.root, f"{name}.json")
        with open(jpath, "w") as fh:
            json.dump(payload, fh, indent=2, sort_keys=True, default=str)

        lines = [
            "SVR-DUN reproducibility manifest",
            f"run_id            : {self.run_id}",
            f"manifest_sha256   : {payload['manifest_sha256']}",
            f"artifacts         : {len(self.entries)}",
            "",
            "Provenance legend",
        ]
        for k, v in _EXPLAIN.items():
            lines.append(f"  {k:<17}  {v}")
        lines += ["", "Counts by provenance"]
        for k, v in sorted(self.summary().items()):
            lines.append(f"  {k:<17}  {v}")
        lines += ["", f"{'SHA-256':<64}  {'PROV':<17}  PATH"]
        lines.append("-" * 110)
        for e in sorted(self.entries, key=lambda x: (x.provenance, x.path)):
            lines.append(f"{e.sha256}  {e.provenance:<17}  {e.path}")
        tpath = os.path.join(self.root, f"{name}.txt")
        with open(tpath, "w") as fh:
            fh.write("\n".join(lines) + "\n")
        return jpath, tpath


def save_json(obj: Any, path: str) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=2, sort_keys=True, default=str)
    return path
