"""Experiment configurations: schema, loader, validator and generators.

One YAML file fully determines a run. Every field that the paper states is
taken from `svrdun.reported.PAPER_CONFIG`, so the configs cannot drift from the
transcribed protocol; fields the paper does not state are marked in the file
itself with a `_note`.

The shipped `configs/` directory covers every experiment table:

    base.yaml                 the protocol of Section V-C
    quick.yaml                the fast end-to-end smoke run
    cave.yaml / icvl.yaml / kaist.yaml / gf5_gf1.yaml
    ablation_A1..A8.yaml      Table VI
    sensitivity_*.yaml        Table VII (K_max, T, w)
    robustness_*.yaml         Tables VIII-X (blur mismatch, perturbed R, unseen R)
    noise_*.yaml              Table XI (SNR sweep, noise-aware RFE)

`validate` rejects a config that contradicts the paper's stated protocol
unless it carries an explicit `deviates_from_paper` note, so an accidental
change cannot be mistaken for the published setting.
"""
from __future__ import annotations

import os
from typing import Any

from .reported import PAPER_CONFIG

__all__ = ["load_config", "save_config", "validate", "to_model_config",
           "to_train_config", "PAPER_FIXED",
           "base_config", "quick_config", "dataset_config", "ablation_configs",
           "sensitivity_configs", "robustness_configs", "noise_configs",
           "all_configs", "write_all_configs", "CONFIG_VERSION"]

CONFIG_VERSION = 1


# --------------------------------------------------------------- yaml i/o
def _yaml():
    try:
        import yaml
        return yaml
    except ImportError as exc:                       # pragma: no cover
        raise ImportError("PyYAML is required for config files: pip install pyyaml") from exc


def save_config(cfg: dict, path: str) -> str:
    yaml = _yaml()
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as fh:
        yaml.safe_dump(cfg, fh, sort_keys=False, default_flow_style=False,
                       width=88, allow_unicode=True)
    return path


def load_config(path: str, validate_it: bool = True) -> dict:
    yaml = _yaml()
    with open(path) as fh:
        cfg = yaml.safe_load(fh)
    if validate_it:
        problems = validate(cfg)
        if problems:
            raise ValueError("invalid config %s:\n  %s" % (path, "\n  ".join(problems)))
    return cfg


# ----------------------------------------------------------------- schema
REQUIRED_SECTIONS = ("meta", "model", "data", "train", "eval")

#: fields whose value the paper fixes; a config may only differ from these
#: when it declares the difference in `meta.deviates_from_paper`.
PAPER_FIXED = {
    "model.C": PAPER_CONFIG["C_bands"],
    "model.K_max": PAPER_CONFIG["K_max"],
    "model.T": PAPER_CONFIG["T_stages"],
    "model.w": PAPER_CONFIG["window_w"],
    "model.s": PAPER_CONFIG["scale_s"],
    "model.gamma_mask": PAPER_CONFIG["gamma_mask"],
    "model.kappa": PAPER_CONFIG["kappa"],
    "model.tau_start": PAPER_CONFIG["tau_start"],
    "model.tau_end": PAPER_CONFIG["tau_end"],
    "model.blur_size": PAPER_CONFIG["blur_kernel_size"],
    "model.blur_var": PAPER_CONFIG["blur_variance"],
    "train.lr": PAPER_CONFIG["lr_init"],
    "train.batch_size": PAPER_CONFIG["batch_size"],
    "train.alpha1": PAPER_CONFIG["alpha1_obs"],
    "train.alpha2": PAPER_CONFIG["alpha2_nest"],
    "train.lambda_min": PAPER_CONFIG["lambda_rho_range"][0],
    "train.lambda_max": PAPER_CONFIG["lambda_rho_range"][1],
    "eval.lambda_rho": PAPER_CONFIG["lambda_rho_default"],
}


def _get(cfg: dict, dotted: str, default=None):
    cur: Any = cfg
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def validate(cfg: dict) -> list[str]:
    """Return a list of problems; empty means the config is usable."""
    problems: list[str] = []
    if not isinstance(cfg, dict):
        return ["config is not a mapping"]
    for sec in REQUIRED_SECTIONS:
        if sec not in cfg:
            problems.append(f"missing section '{sec}'")
    if problems:
        return problems

    if cfg.get("config_version") != CONFIG_VERSION:
        problems.append(f"config_version must be {CONFIG_VERSION}")

    declared = set(_get(cfg, "meta.deviates_from_paper", []) or [])
    for dotted, expected in PAPER_FIXED.items():
        got = _get(cfg, dotted, "__missing__")
        if got == "__missing__":
            problems.append(f"missing field '{dotted}'")
            continue
        same = (abs(got - expected) < 1e-12
                if isinstance(expected, (int, float)) and isinstance(got, (int, float))
                else got == expected)
        if not same and dotted not in declared:
            problems.append(
                f"'{dotted}' is {got!r} but the paper states {expected!r}; "
                f"add '{dotted}' to meta.deviates_from_paper to allow it")

    ds = _get(cfg, "data.dataset")
    if ds in PAPER_CONFIG["epochs"]:
        ep = _get(cfg, "train.epochs")
        want = PAPER_CONFIG["epochs"][ds]
        if ep != want and "train.epochs" not in declared:
            problems.append(f"train.epochs is {ep} but the paper uses {want} on {ds}; "
                            "declare it in meta.deviates_from_paper")
    if _get(cfg, "model.L") is None:
        problems.append("missing field 'model.L'")
    return problems


# ------------------------------------------------------------- generators
def base_config() -> dict:
    """The protocol of Section V-C, with nothing dataset-specific filled in."""
    return {
        "config_version": CONFIG_VERSION,
        "meta": {
            "name": "base",
            "description": "SVR-DUN protocol as stated in Section V-C of the paper.",
            "provenance_of_values": "Paper Sections III-A, V-A, V-C",
            "deviates_from_paper": [],
            "_note": ("Fields the paper does not state are marked with _note. "
                      "The learned-block widths are among them."),
        },
        "model": {
            "C": PAPER_CONFIG["C_bands"],
            "L": PAPER_CONFIG["L_default"],
            "K_max": PAPER_CONFIG["K_max"],
            "T": PAPER_CONFIG["T_stages"],
            "w": PAPER_CONFIG["window_w"],
            "s": PAPER_CONFIG["scale_s"],
            "blur_size": PAPER_CONFIG["blur_kernel_size"],
            "blur_var": PAPER_CONFIG["blur_variance"],
            "gamma_mask": PAPER_CONFIG["gamma_mask"],
            "kappa": PAPER_CONFIG["kappa"],
            "tau_start": PAPER_CONFIG["tau_start"],
            "tau_end": PAPER_CONFIG["tau_end"],
            "mu": 1.0,
            "width": 32,
            "film_hidden": 32,
            "use_dcm": True,
            "use_tv": True,
            "use_innovation": True,
            "noise_aware": False,
            "_note_width": ("The paper does not publish the channel widths of "
                            "the learned blocks; 32 is this repository's choice "
                            "and is why its parameter count differs from the "
                            "0.714 M of Table V."),
            "_note_mu": "The weight mu of the HRMSI term in (12) is not stated.",
        },
        "data": {
            "dataset": None,
            "root": None,
            "split_file": None,
            "normalise": "max",
            "crop_hr": PAPER_CONFIG["crop_hr"],
            "crop_lr": PAPER_CONFIG["crop_lr"],
            "stride": None,
            "response": "Nikon D700",
            "response_file": None,
            "_note_response": ("The Nikon D700 response is measured data and is "
                               "not shipped. Set response_file, or use a "
                               "gaussian_L* response, which the paper specifies "
                               "completely."),
        },
        "train": {
            "mode": "FULL",
            "epochs": None,
            "batch_size": PAPER_CONFIG["batch_size"],
            "lr": PAPER_CONFIG["lr_init"],
            "lr_schedule": "cosine",
            "optimizer": PAPER_CONFIG["optimizer"],
            "lambda_min": PAPER_CONFIG["lambda_rho_range"][0],
            "lambda_max": PAPER_CONFIG["lambda_rho_range"][1],
            "lambda_sampling": PAPER_CONFIG["lambda_rho_sampling"],
            "tau_start": PAPER_CONFIG["tau_start"],
            "tau_end": PAPER_CONFIG["tau_end"],
            "alpha1": PAPER_CONFIG["alpha1_obs"],
            "alpha2": PAPER_CONFIG["alpha2_nest"],
            "seeds": list(PAPER_CONFIG["seeds"]),
            "grad_clip": 1.0,
            "ckpt_every": 1,
            "_note_grad_clip": "Gradient clipping is not mentioned in the paper.",
        },
        "eval": {
            "lambda_rho": PAPER_CONFIG["lambda_rho_default"],
            "budgets": [1e-4, 1e-3, 1e-2],
            "metrics": ["PSNR", "ERGAS", "SAM", "UIQI"],
            "scale": PAPER_CONFIG["scale_s"],
            "uiqi_window": 32,
            "timing_output_size": list(PAPER_CONFIG["timing_output_size"]),
            "_note_uiqi_window": "The UIQI sliding-window size is not stated.",
        },
    }


def quick_config() -> dict:
    cfg = base_config()
    cfg["meta"].update({
        "name": "quick",
        "description": ("Fast end-to-end smoke run on the reconstructed Fig. 1 "
                        "scene. Proves every code path executes. Does NOT "
                        "reproduce the paper's numbers."),
        "deviates_from_paper": ["train.epochs", "train.batch_size", "eval.scale"],
    })
    cfg["data"].update({"dataset": "SYNTHETIC", "stride": 32,
                        "response": "approx_rgb_stand_in"})
    cfg["train"].update({"mode": "QUICK", "epochs": 6, "batch_size": 4,
                         "seeds": [1]})
    cfg["eval"]["timing_output_size"] = [128, 128]
    return cfg


def dataset_config(dataset: str) -> dict:
    cfg = base_config()
    spec_epochs = PAPER_CONFIG["epochs"].get(dataset)
    stride = PAPER_CONFIG["stride"].get(dataset)
    ds_info = PAPER_CONFIG["datasets"].get(dataset, {})
    cfg["meta"].update({
        "name": dataset.lower(),
        "description": f"SVR-DUN on {dataset}, paper protocol.",
    })
    cfg["data"].update({
        "dataset": dataset,
        "root": f"/content/drive/MyDrive/datasets/{dataset}",
        "split_file": f"splits/{dataset}_split.json",
        "stride": stride,
        "wavelength_range_nm": ds_info.get("range_nm"),
        "n_scenes": ds_info.get("scenes"),
        "n_test": ds_info.get("n_test"),
        "test_rule": ds_info.get("test"),
    })
    cfg["train"]["epochs"] = spec_epochs
    if dataset == "GF5-GF1":
        cfg["model"].update({"C": 150, "L": 4})
        cfg["meta"]["deviates_from_paper"] = ["model.C"]
        cfg["data"].update({
            "split_file": "splits/GF5-GF1_split.json",
            "zero_shot": True,
            "_note": ("Real pair with no reference. Section V-A uses the "
                      "zero-shot strategy of [38]: estimate the spatial "
                      "degradation as in [37], degrade the observed pair once "
                      "more to form inputs, and use the original LRHSI as the "
                      "training target."),
        })
        cfg["eval"]["metrics"] = ["QNR", "D_lambda", "D_s"]
    return cfg


def ablation_configs() -> dict:
    """Table VI: nine variants on CAVE, one component changed at a time."""
    from .reported import TABLE_VI
    out = {}
    switches = {
        "A1": {"variant": "binary_rank", "_sets": {}},
        "A2": {"variant": "learned_discriminator", "_sets": {}},
        "A3": {"variant": "no_atom_ordering", "_sets": {"train.alpha2": 0.0}},
        "A4": {"variant": "no_tv", "_sets": {"model.use_tv": False}},
        "A5": {"variant": "no_innovation", "_sets": {"model.use_innovation": False}},
        "A6": {"variant": "no_dcm", "_sets": {"model.use_dcm": False}},
        "A7": {"variant": "gather_and_reshape", "_sets": {}},
        "A8": {"variant": "one_model_per_budget", "_sets": {}},
    }
    for aid, sw in switches.items():
        cfg = dataset_config("CAVE")
        reported = TABLE_VI[aid]
        cfg["meta"].update({
            "name": f"ablation_{aid}",
            "description": f"Table VI {aid}: {reported[0]}",
            "ablation_id": aid,
            "variant": sw["variant"],
            "reported_result": {
                "PSNR": reported[1], "ERGAS": reported[2], "SAM": reported[3],
                "UIQI": reported[4], "FLOPs_G": reported[5],
                "_provenance": "REPORTED - the paper's value, the target to hit",
            },
            "deviates_from_paper": list(sw["_sets"].keys()),
        })
        for dotted, val in sw["_sets"].items():
            sec, key = dotted.split(".")
            cfg[sec][key] = val
        if aid == "A1":
            cfg["model"]["binary_rank_values"] = [2, PAPER_CONFIG["K_max"]]
            cfg["model"]["_note_A1"] = ("rho_p restricted to {K, K_max} with a "
                                        "fixed ratio, which reproduces binary "
                                        "routing inside the SVR framework "
                                        "(Proposition 1).")
        if aid == "A8":
            cfg["train"]["lambda_min"] = cfg["train"]["lambda_max"] = \
                PAPER_CONFIG["lambda_rho_default"]
            cfg["meta"]["deviates_from_paper"] += ["train.lambda_min",
                                                   "train.lambda_max"]
        out[f"ablation_{aid}"] = cfg
    full = dataset_config("CAVE")
    full["meta"].update({"name": "ablation_full", "ablation_id": "full",
                         "description": "Table VI full model (reproduces the CAVE row of Table III)",
                         "reported_result": {"PSNR": TABLE_VI["full"][1],
                                             "FLOPs_G": TABLE_VI["full"][5],
                                             "_provenance": "REPORTED"}})
    out["ablation_full"] = full
    return out


def sensitivity_configs() -> dict:
    """Table VII: K_max, T and w varied one at a time."""
    from .reported import TABLE_VII
    out = {}
    for setting, value, psnr, sam, flops, sat in TABLE_VII["rows"]:
        key = {"K_max": "K_max", "T": "T", "w": "w"}[setting]
        if value == TABLE_VII["defaults"][setting]:
            continue                                   # the default is base
        cfg = dataset_config("CAVE")
        cfg["model"][key] = value
        if key == "w":
            cfg["data"]["_note_w"] = ("w is decoupled from s here; at w = s = 8 "
                                      "each window covers exactly one LRHSI pixel.")
        cfg["meta"].update({
            "name": f"sensitivity_{setting}_{value}",
            "description": f"Table VII: {setting} = {value} on CAVE",
            "deviates_from_paper": [f"model.{key}"],
            "reported_result": {"PSNR": psnr, "SAM": sam, "FLOPs_G": flops,
                                "saturated_windows_pct": sat,
                                "_provenance": "REPORTED"},
        })
        out[f"sensitivity_{setting}_{value}"] = cfg
    return out


def robustness_configs() -> dict:
    """Tables VIII-X: degradation mismatch, perturbed and unseen responses."""
    from .reported import TABLE_IX, TABLE_VIII, TABLE_X
    out = {}

    for var in (2.0, 4.0):
        cfg = dataset_config("CAVE")
        cfg["meta"].update({
            "name": f"robustness_blur_var{int(var)}",
            "description": f"Table VIII: test-time blur variance {var} "
                           "(trained at variance 3)",
            "deviates_from_paper": ["model.blur_var"],
            "test_time_only": True,
            "reported_result": {"SVR-DUN_PSNR":
                                TABLE_VIII["SVR-DUN"][1 if var == 2.0 else 2],
                                "_provenance": "REPORTED"},
        })
        cfg["data"]["test_blur_var"] = var
        cfg["data"]["_note"] = ("Train with blur_var 3 as usual; override only "
                                "the test-time simulation.")
        out[f"robustness_blur_var{int(var)}"] = cfg

    for name, aug, joint in (("plain", False, False), ("aug", True, False),
                             ("joint", False, True), ("aug_joint", True, True)):
        cfg = dataset_config("CAVE")
        cfg["meta"].update({
            "name": f"robustness_response_{name}",
            "description": ("Tables IX and X: spectral-response robustness, "
                            f"augmentation={aug}, joint estimation={joint}"),
            "deviates_from_paper": [],
            "reported_result": {
                "Table_IX_rows": "see reported.TABLE_IX",
                "Table_X_row": TABLE_X.get(
                    {"plain": "SVR-DUN", "aug": "SVR-DUN +Aug",
                     "joint": "SVR-DUN +Joint",
                     "aug_joint": "SVR-DUN +Aug+Joint"}[name]),
                "_provenance": "REPORTED"},
        })
        cfg["train"]["response_augmentation"] = {
            "enabled": aug, "probability": 0.5,
            "band_shift_nm": [-15, 15], "width_scale": [0.8, 1.25],
            "camera_database": "Jiang et al. [56]",
            "_note": ("Section IV-I-3. The Canon 60D and five further cameras "
                      "are held out for testing."),
        }
        cfg["model"]["joint_response_estimation"] = {
            "enabled": joint, "lambda_s": 1e-2, "lambda_R": 1e-2,
            "_note": ("Equations (33)-(34). lambda_s and lambda_R are not "
                      "stated in the paper; these are this repository's values."),
        }
        cfg["eval"]["perturbations"] = [r[0] for r in TABLE_IX["rows"]]
        out[f"robustness_response_{name}"] = cfg

    for L in (4, 6, 8):
        cfg = dataset_config("CAVE")
        cfg["model"]["L"] = L
        cfg["data"]["response"] = f"gaussian_L{L}"
        cfg["meta"].update({
            "name": f"sensor_gaussian_L{L}",
            "description": (f"Table XII: Gaussian sensor with L = {L}, centres "
                            "equally spaced over 400-700 nm, FWHM equal to the "
                            "centre spacing (Section V-J)."),
            "deviates_from_paper": ["model.L"],
            "fully_specified_by_paper": True,
            "_note": ("The Gaussian responses ARE completely specified in the "
                      "paper, so this row of Table XII is genuinely reproducible."),
        })
        out[f"sensor_gaussian_L{L}"] = cfg
    return out


def noise_configs() -> dict:
    """Table XI: SNR sweep with and without the noise-aware RFE of (32)."""
    from .reported import TABLE_XI
    out = {}
    for row in TABLE_XI["rows"]:
        snr = row[0]
        tag = "noisefree" if snr == "inf" else f"snr{snr}"
        for aware in (False, True):
            cfg = dataset_config("CAVE")
            cfg["model"]["noise_aware"] = aware
            cfg["meta"].update({
                "name": f"noise_{tag}_{'aware' if aware else 'plain'}",
                "description": (f"Table XI: SNR {snr} dB, "
                                f"{'noise-aware (32)' if aware else 'plain RFE (15)'}"),
                "deviates_from_paper": [],
                "reported_result": {
                    "PSNR": row[5] if aware else row[2],
                    "mean_rank": row[6] if aware else row[3],
                    "FLOPs_G": row[7] if aware else row[4],
                    "_provenance": "REPORTED"},
            })
            cfg["data"]["snr_db"] = None if snr == "inf" else snr
            cfg["data"]["noise_estimator"] = "HySime [55]" if aware else None
            out[f"noise_{tag}_{'aware' if aware else 'plain'}"] = cfg
    return out


def all_configs() -> dict:
    cfgs = {"base": base_config(), "quick": quick_config()}
    for ds in ("CAVE", "ICVL", "KAIST", "GF5-GF1"):
        cfgs[ds.lower().replace("-", "_")] = dataset_config(ds)
    cfgs.update(ablation_configs())
    cfgs.update(sensitivity_configs())
    cfgs.update(robustness_configs())
    cfgs.update(noise_configs())
    return cfgs


def write_all_configs(out_dir: str = "configs") -> dict:
    """Write every config to `out_dir`. Returns {name: path}."""
    written = {}
    for name, cfg in all_configs().items():
        if name == "base":
            problems: list[str] = []          # base has no dataset or epochs yet
        else:
            problems = validate(cfg)
        if problems:
            raise ValueError(f"generated config '{name}' is invalid:\n  "
                             + "\n  ".join(problems))
        written[name] = save_config(cfg, os.path.join(out_dir, f"{name}.yaml"))
    return written


def to_model_config(cfg: dict):
    """Build an `SVRDUNConfig` from a loaded experiment config."""
    from .model import SVRDUNConfig
    m = cfg["model"]
    allowed = set(SVRDUNConfig.__dataclass_fields__)
    kw = {k: v for k, v in m.items() if k in allowed}
    kw["lambda_rho_default"] = cfg["eval"]["lambda_rho"]
    return SVRDUNConfig(**kw)


def to_train_config(cfg: dict, seed: int | None = None):
    """Build a `TrainConfig` from a loaded experiment config."""
    from .train import TrainConfig
    t, d = cfg["train"], cfg["data"]
    return TrainConfig(
        mode=t.get("mode", "FULL"), dataset=d.get("dataset") or "SYNTHETIC",
        epochs=int(t.get("epochs") or 1), batch_size=int(t["batch_size"]),
        lr=float(t["lr"]), lambda_min=float(t["lambda_min"]),
        lambda_max=float(t["lambda_max"]), tau_start=float(t["tau_start"]),
        tau_end=float(t["tau_end"]), alpha1=float(t["alpha1"]),
        alpha2=float(t["alpha2"]),
        seed=int(seed if seed is not None else t["seeds"][0]),
        patch=int(d["crop_hr"]), scale=int(cfg["model"]["s"]),
        grad_clip=float(t.get("grad_clip") or 0.0),
        ckpt_every=int(t.get("ckpt_every", 1)),
    )
