"""Datasets, deterministic splits and patch extraction.

Protocol (Section V-A):
  CAVE   32 scenes, 512x512, 31 bands 400-700 nm; the LAST 12 are the test set.
  ICVL   200 scenes, 1392x1300, 31 bands; 40 drawn AT RANDOM for testing.
  KAIST  30 scenes, 2704x3376, 31 bands 420-720 nm; the LAST 10 are the test set.
  Every image is normalised to [0, 1] by its maximum before simulation.
  Training pairs: 64x64 HR crops (8x8 in the LRHSI), stride 32 on CAVE and 64
  on ICVL and KAIST.

The raw datasets are gated and are NOT downloaded by this code. Point
`root` at your own copy; `prepare_dataset` verifies and normalises it and
writes a split file whose SHA-256 goes into the manifest, so a split can be
checked by anyone who repeats the run.

ICVL's "40 at random" needs a seed to be reproducible. The paper does not
state one, so `ICVL_SPLIT_SEED` is this repository's choice and is recorded in
the split file. Anyone comparing against the paper's ICVL numbers should use
the authors' own split file if they have it.
"""
from __future__ import annotations

import glob
import json
import os
from dataclasses import asdict, dataclass

import numpy as np

from .provenance import sha256_obj

__all__ = ["DatasetSpec", "DATASETS", "ICVL_SPLIT_SEED", "list_scene_files",
           "load_cube", "normalise_cube", "build_split", "save_split",
           "load_split", "extract_patches", "SyntheticDataset"]

ICVL_SPLIT_SEED = 20240501          # this repository's choice; see module docstring


@dataclass
class DatasetSpec:
    name: str
    bands: int
    wl_lo: float
    wl_hi: float
    n_scenes: int | None
    n_test: int
    test_rule: str
    crop_hr: int = 64
    stride: int = 32
    epochs: int = 1000

    def as_dict(self):
        return asdict(self)


DATASETS = {
    "CAVE":  DatasetSpec("CAVE", 31, 400, 700, 32, 12, "last", 64, 32, 1000),
    "ICVL":  DatasetSpec("ICVL", 31, 400, 700, 200, 40, "random", 64, 64, 120),
    "KAIST": DatasetSpec("KAIST", 31, 420, 720, 30, 10, "last", 64, 64, 300),
}

_EXTS = (".mat", ".npy", ".npz", ".tif", ".tiff", ".h5", ".hdf5")


def list_scene_files(root: str) -> list[str]:
    out: list[str] = []
    for ext in _EXTS:
        out += glob.glob(os.path.join(root, "**", "*" + ext), recursive=True)
    return sorted(out)


def load_cube(path: str, key: str | None = None) -> np.ndarray:
    """Load one scene as (H, W, C) float64."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".npy":
        arr = np.load(path)
    elif ext == ".npz":
        z = np.load(path)
        arr = z[key] if key else z[list(z.keys())[0]]
    elif ext == ".mat":
        try:
            from scipy.io import loadmat
            d = loadmat(path)
            cands = {k: v for k, v in d.items() if not k.startswith("__")}
            cands = {k: v for k, v in cands.items()
                     if hasattr(v, "ndim") and v.ndim == 3}
            if not cands:
                raise KeyError(f"no 3-D array in {path}")
            arr = cands[key] if key and key in cands else list(cands.values())[0]
        except NotImplementedError:
            import h5py
            with h5py.File(path, "r") as f:
                k = key or [k for k in f.keys() if getattr(f[k], "ndim", 0) == 3][0]
                arr = np.array(f[k])
                if arr.shape[0] < arr.shape[-1]:
                    arr = np.transpose(arr, (2, 1, 0))
    elif ext in (".h5", ".hdf5"):
        import h5py
        with h5py.File(path, "r") as f:
            k = key or [k for k in f.keys() if getattr(f[k], "ndim", 0) == 3][0]
            arr = np.array(f[k])
    elif ext in (".tif", ".tiff"):
        import tifffile
        arr = tifffile.imread(path)
    else:
        raise ValueError(f"unsupported scene file: {path}")
    arr = np.asarray(arr, dtype=np.float64)
    if arr.ndim != 3:
        raise ValueError(f"expected 3-D cube in {path}, got {arr.shape}")
    if arr.shape[0] < arr.shape[2] and arr.shape[0] < arr.shape[1]:
        arr = np.transpose(arr, (1, 2, 0))     # (C,H,W) -> (H,W,C)
    return arr


def normalise_cube(cube: np.ndarray) -> np.ndarray:
    """Normalise to [0, 1] by the maximum, as Section V-A specifies."""
    a = np.asarray(cube, dtype=np.float64)
    m = float(a.max())
    return a / m if m > 0 else a


def build_split(files: list[str], spec: DatasetSpec,
                seed: int = ICVL_SPLIT_SEED) -> dict:
    """Train/test split following the paper's rule for this dataset."""
    files = list(files)
    n = len(files)
    if spec.test_rule == "last":
        test_idx = list(range(max(n - spec.n_test, 0), n))
    elif spec.test_rule == "random":
        rng = np.random.default_rng(seed)
        test_idx = sorted(rng.choice(n, size=min(spec.n_test, n),
                                     replace=False).tolist())
    else:
        raise ValueError(spec.test_rule)
    test_set = set(test_idx)
    train_idx = [i for i in range(n) if i not in test_set]
    split = {
        "dataset": spec.name,
        "rule": spec.test_rule,
        "seed": seed if spec.test_rule == "random" else None,
        "seed_note": ("The paper does not state the seed for ICVL's random 40; "
                      "this is this repository's choice."
                      if spec.test_rule == "random" else None),
        "n_files": n,
        "n_expected": spec.n_scenes,
        "n_test": len(test_idx),
        "train": [os.path.basename(files[i]) for i in train_idx],
        "test": [os.path.basename(files[i]) for i in test_idx],
        "train_paths": [files[i] for i in train_idx],
        "test_paths": [files[i] for i in test_idx],
    }
    split["split_sha256"] = sha256_obj(
        {"train": split["train"], "test": split["test"], "rule": spec.test_rule,
         "seed": split["seed"]})
    return split


def save_split(split: dict, path: str) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(split, fh, indent=2, sort_keys=True)
    return path


def load_split(path: str) -> dict:
    with open(path) as fh:
        return json.load(fh)


def extract_patches(cube: np.ndarray, size: int = 64, stride: int = 32,
                    limit: int | None = None) -> np.ndarray:
    """Non-random grid crops, so patch extraction is deterministic."""
    H, W, C = cube.shape
    ys = list(range(0, max(H - size + 1, 1), stride))
    xs = list(range(0, max(W - size + 1, 1), stride))
    out = []
    for y in ys:
        for x in xs:
            p = cube[y:y + size, x:x + size, :]
            if p.shape[:2] == (size, size):
                out.append(p)
                if limit and len(out) >= limit:
                    return np.stack(out)
    return np.stack(out) if out else np.empty((0, size, size, C))


class SyntheticDataset:
    """Deterministic patches cut from the reconstructed Fig. 1 scene.

    Lets the entire pipeline run with no gated data. Results are honest
    outputs of this code on this scene; they are not the paper's datasets.
    """

    def __init__(self, n_train: int = 64, n_test: int = 8, size: int = 64,
                 C: int = 31, seed: int = 0, scene_hw: tuple = (384, 384)):
        from .synthetic import synthetic_scene
        sc = synthetic_scene(scene_hw[0], scene_hw[1], C, seed=seed)
        self.scene = sc
        cube = sc["cube"]
        patches = extract_patches(cube, size=size, stride=max(size // 2, 1))
        if len(patches) < n_train + n_test:
            raise ValueError(
                f"scene {scene_hw} at patch size {size} yields only "
                f"{len(patches)} patches, fewer than n_train + n_test = "
                f"{n_train + n_test}; enlarge scene_hw or lower the counts")
        rng = np.random.default_rng(seed)
        idx = rng.permutation(len(patches))
        self.train = patches[idx[:n_train]]
        self.test = patches[idx[n_train:n_train + n_test]]
        self.size = size
        self.C = C
        self.provenance_note = sc["_provenance_note"]

    def __repr__(self):
        return (f"SyntheticDataset(train={len(self.train)}, "
                f"test={len(self.test)}, size={self.size}, C={self.C})")
