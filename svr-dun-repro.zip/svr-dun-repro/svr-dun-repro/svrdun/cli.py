"""Command-line interface.

    svrdun verify-tables                 check the published tables for self-consistency
    svrdun make-configs [-o configs]     regenerate every experiment config
    svrdun make-splits  [-o splits]      regenerate the SPECIFIED split files
    svrdun materialise-split CAVE ROOT   apply the split rule to a real directory
    svrdun verify-split splits/CAVE_split.json ROOT
    svrdun run -c configs/quick.yaml     train and evaluate one configuration
    svrdun cost -c configs/cave.yaml     parameters, FLOPs, time, peak memory
    svrdun recoverability                sigma_min(R D_k) for the Gaussian sensors
    svrdun figures -o outputs/figs       the motivation figures, no dataset needed
    svrdun manifest DIR                  hash a directory into a provenance manifest

Every command that writes files also records them in a manifest, so an output
without a provenance tag should never appear.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

__all__ = ["main", "build_parser"]

_BANNER = """SVR-DUN reproducibility CLI
Provenance tags: COMPUTED (run here) | REPORTED (from the paper, not a
reproduction) | DERIVED_REPORTED (computed here from transcribed inputs)."""


# ------------------------------------------------------------------ helpers
def _out(path: str) -> str:
    os.makedirs(os.path.abspath(path), exist_ok=True)
    return path


def _print_table(rows, cols, title=None):
    if title:
        print(title)
    if not rows:
        print("  (nothing)")
        return
    widths = [max(len(str(c)), max(len(str(r.get(c, ""))) for r in rows)) for c in cols]
    print("  " + "  ".join(str(c).ljust(w) for c, w in zip(cols, widths)))
    print("  " + "  ".join("-" * w for w in widths))
    for r in rows:
        print("  " + "  ".join(str(r.get(c, "")).ljust(w) for c, w in zip(cols, widths)))


# ----------------------------------------------------------------- commands
def cmd_verify_tables(args) -> int:
    from .provenance import save_json
    from .verify import format_report, run_all_checks

    res = run_all_checks()
    print(format_report(res))
    if args.output:
        p = save_json(res, os.path.join(_out(args.output), "table_consistency.json"))
        print(f"\nwrote {p}")
    return 0 if res["n_mismatch"] == 0 else 1


def cmd_make_configs(args) -> int:
    from .configs import write_all_configs

    written = write_all_configs(_out(args.output))
    print(f"wrote {len(written)} configs to {args.output}/")
    for name in sorted(written):
        print(f"  {name}.yaml")
    return 0


def cmd_make_splits(args) -> int:
    from .splits import load_split_file, split_summary, write_specified_splits

    written = write_specified_splits(_out(args.output))
    print(f"wrote {len(written)} files to {args.output}/\n")
    for ds in ("CAVE", "ICVL", "KAIST", "GF5-GF1"):
        print(split_summary(load_split_file(written[ds])))
        print()
    return 0


def cmd_materialise_split(args) -> int:
    from .data import list_scene_files
    from .splits import materialise_split, split_summary, verify_split

    files = list_scene_files(args.root)
    if not files:
        print(f"no scene files found under {args.root}", file=sys.stderr)
        return 2
    split = materialise_split(args.dataset, files)
    print(split_summary(split))
    check = verify_split(split, files)
    print("\nverification:", "PASSED" if check["ok"] else "FAILED")
    for p in check["problems"]:
        print("  ", p)
    if not check["ok"]:
        return 1
    path = args.output or os.path.join("splits", f"{args.dataset}_split.json")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(split, fh, indent=2)
    print(f"\nwrote {path}")
    return 0


def cmd_verify_split(args) -> int:
    from .data import list_scene_files
    from .splits import load_split_file, split_summary, verify_split

    split = load_split_file(args.split_file)
    files = list_scene_files(args.root)
    print(split_summary(split))
    check = verify_split(split, files)
    print("\nverification:", "PASSED" if check["ok"] else "FAILED")
    for p in check["problems"]:
        print("  ", p)
    return 0 if check["ok"] else 1


def cmd_run(args) -> int:
    import numpy as np

    from .configs import load_config, to_model_config, to_train_config
    from .data import SyntheticDataset, extract_patches, list_scene_files, load_cube, normalise_cube
    from .model import SVRDUN
    from .provenance import COMPUTED, Manifest, save_json
    from .responses import approximate_rgb_response, gaussian_response, load_response
    from .splits import materialise_split, verify_split
    from .train import evaluate_model, train_model

    cfg = load_config(args.config)
    seed = args.seed if args.seed is not None else cfg["train"]["seeds"][0]
    name = cfg["meta"]["name"]
    out_dir = _out(args.output or os.path.join("outputs", f"{name}_seed{seed}"))

    print(_BANNER, "\n")
    print(f"config    : {args.config} -> {name}")
    print(f"            {cfg['meta']['description']}")
    dev = cfg["meta"].get("deviates_from_paper") or []
    print(f"deviates  : {dev if dev else 'nothing'}")
    print(f"seed      : {seed}")
    print(f"output    : {out_dir}\n")

    mcfg = to_model_config(cfg)
    tcfg = to_train_config(cfg, seed=seed)
    if args.epochs is not None:
        tcfg.epochs = args.epochs
        print(f"NOTE: epochs overridden on the command line -> {args.epochs}\n")

    # ---- spectral response
    rspec = cfg["data"].get("response") or "approx_rgb_stand_in"
    rfile = cfg["data"].get("response_file")
    if rfile:
        R = load_response(rfile, C=mcfg.C)
        print(f"response  : loaded from {rfile}  shape {R.shape}")
    elif rspec.startswith("gaussian_L"):
        R = gaussian_response(int(rspec.split("L")[-1]), mcfg.C)
        print(f"response  : {rspec} (fully specified by the paper)")
    else:
        R = approximate_rgb_response(mcfg.C)
        print("response  : approximate RGB STAND-IN (not the Nikon D700); "
              "results are not comparable with the paper")
    mcfg.L = R.shape[0]

    # ---- data
    dataset = cfg["data"]["dataset"] or "SYNTHETIC"
    if dataset == "SYNTHETIC" or not (args.data_root or cfg["data"].get("root")):
        ds = SyntheticDataset(n_train=args.n_train, n_test=args.n_test,
                              size=cfg["data"]["crop_hr"], C=mcfg.C, seed=seed)
        train_patches, test_patches = ds.train, ds.test
        print(f"data      : synthetic ({ds})")
        print(f"            {ds.provenance_note}")
    else:
        root = args.data_root or cfg["data"]["root"]
        files = list_scene_files(root)
        split = materialise_split(dataset, files)
        check = verify_split(split, files)
        if not check["ok"]:
            print("split verification FAILED:", check["problems"], file=sys.stderr)
            return 1
        crop, stride = cfg["data"]["crop_hr"], cfg["data"]["stride"]
        tr = [extract_patches(normalise_cube(load_cube(p)), crop, stride,
                              limit=args.max_patches)
              for p in split["train_paths"][:args.max_scenes]]
        train_patches = np.concatenate(tr) if tr else None
        te = []
        for p in split["test_paths"]:
            c = normalise_cube(load_cube(p))
            s = mcfg.s
            te.append(c[:(c.shape[0] // s) * s, :(c.shape[1] // s) * s, :])
        test_patches = np.stack(te) if te and len({t.shape for t in te}) == 1 else te
        print(f"data      : {dataset} from {root}, "
              f"{len(split['train'])} train / {len(split['test'])} test scenes")

    model = SVRDUN(mcfg)
    print(f"model     : {sum(p.numel() for p in model.parameters()):,} parameters\n")

    man = Manifest(os.path.dirname(os.path.abspath(out_dir)) or ".")
    env = man.capture_environment()
    save_json(env, os.path.join(out_dir, "environment.json"))

    res = train_model(model, train_patches, R, tcfg, out_dir, resume=not args.no_resume)
    h = res["history"]
    print(f"\ntrained {res['epochs_run']} epochs  "
          f"loss {h[0]['loss']:.5f} -> {h[-1]['loss']:.5f}")

    if test_patches is not None and len(test_patches):
        ev = evaluate_model(model, test_patches, R,
                            lambda_rho=cfg["eval"]["lambda_rho"],
                            scale=mcfg.s)
        save_json(ev, os.path.join(out_dir, "evaluation_per_image.json"))
        print("\nevaluation (mean over %d images):" % ev["n_images"])
        for k, v in ev["mean"].items():
            print(f"   {k:10} {v:.4f}")

        sweep = []
        for lam in cfg["eval"]["budgets"]:
            e = evaluate_model(model, test_patches, R, lambda_rho=lam, scale=mcfg.s)
            sweep.append({"lambda_rho": lam, **e["mean"]})
        save_json(sweep, os.path.join(out_dir, "budget_sweep.json"))
        _print_table([{k: (round(v, 4) if isinstance(v, float) else v)
                       for k, v in s.items()} for s in sweep],
                     ["lambda_rho", "PSNR", "SAM", "mean_rank"],
                     "\nbudget sweep:")

    man.record_tree(out_dir, COMPUTED, f"run {name} seed {seed}")
    jp, tp = man.write(name=f"MANIFEST_{name}_seed{seed}")
    print(f"\nmanifest  : {tp}")
    return 0


def cmd_cost(args) -> int:
    from .configs import load_config, to_model_config
    from .cost import measure_cost
    from .model import SVRDUN
    from .provenance import save_json
    from .responses import approximate_rgb_response, gaussian_response

    cfg = load_config(args.config)
    mcfg = to_model_config(cfg)
    rspec = cfg["data"].get("response") or ""
    R = (gaussian_response(int(rspec.split("L")[-1]), mcfg.C)
         if rspec.startswith("gaussian_L") else approximate_rgb_response(mcfg.C))
    mcfg.L = R.shape[0]
    model = SVRDUN(mcfg)
    if args.checkpoint:
        from .train import load_checkpoint
        load_checkpoint(args.checkpoint, model)
        print(f"loaded weights from {args.checkpoint}")

    res = measure_cost(model, R, H=args.size, W=args.size,
                       lambda_rhos=tuple(cfg["eval"]["budgets"]), n_runs=args.runs)
    _print_table([{k: v for k, v in r.items()
                   if k in ("lambda_rho", "params_M", "gflops_analytic",
                            "mean_rank", "time_s", "peak_memory_gb", "device_name")}
                  for r in res["rows"]],
                 ["lambda_rho", "params_M", "gflops_analytic", "mean_rank",
                  "time_s", "peak_memory_gb", "device_name"],
                 f"cost at {args.size}x{args.size}:")
    print("\n" + res["comparability_note"])
    print(res["flops_vs_latency_note"])
    if args.output:
        p = save_json(res, os.path.join(_out(args.output), "cost.json"))
        print(f"\nwrote {p}")
    return 0


def cmd_recoverability(args) -> int:
    from .provenance import save_json
    from .rank import ordered_atoms_from_cube
    from .recover import recoverability_table
    from .responses import approximate_rgb_response, gaussian_response
    from .synthetic import synthetic_scene

    scene = synthetic_scene(args.size, args.size, args.bands, seed=0)
    D = ordered_atoms_from_cube(scene["cube"], args.k_max)
    responses = {f"Gaussian, L = {L}": gaussian_response(L, args.bands)
                 for L in (4, 6, 8)}
    responses["approx RGB (stand-in)"] = approximate_rgb_response(args.bands)
    res = recoverability_table(responses, D, K_max=args.k_max,
                               epsilon=args.epsilon,
                               atoms_description="synthetic-scene atoms")
    rows = [{"sensor": r["sensor"], "L": r["L"],
             **{f"k={i+1}": f"{s:.3f}" for i, s in enumerate(r["sigma"])},
             "rank(30)": r["recoverable_rank"]} for r in res["rows"]]
    _print_table(rows, ["sensor", "L"] + [f"k={i}" for i in range(1, args.k_max + 1)]
                 + ["rank(30)"], f"recoverability (epsilon = {args.epsilon}):")
    print("\n" + res["note"])
    print("Proposition 2(b) zeros beyond k=L :",
          all(r["zeros_beyond_L"] for r in res["rows"]))
    print("Proposition 2(c) non-increasing   :",
          all(r["non_increasing"] for r in res["rows"]))
    if args.output:
        p = save_json(res, os.path.join(_out(args.output), "recoverability.json"))
        print(f"\nwrote {p}")
    return 0


def cmd_figures(args) -> int:
    from .figures import fig1_motivation, fig4_rfe, fig_recoverability
    from .provenance import COMPUTED
    from .rank import local_spectral_rank, ordered_atoms_from_cube
    from .recover import recoverability_table
    from .responses import approximate_rgb_response, gaussian_response
    from .synthetic import synthetic_scene

    out = _out(args.output)
    scene = synthetic_scene(args.size, args.size, args.bands, seed=0)
    cube = scene["cube"]
    D2 = ordered_atoms_from_cube(cube, 2)
    D = ordered_atoms_from_cube(cube, args.k_max)
    rho = local_spectral_rank(cube, D, delta=2e-3, w=8, K_max=args.k_max)

    made = [fig1_motivation(scene, D2, rho, out=os.path.join(out, "fig1_motivation.png"),
                            provenance=COMPUTED)]
    H, W = cube.shape[:2]
    pts = [(H // 6, W // 2), (int(H * .6), int(W * .2)),
           (int(H * .6), int(W * .75)), (int(H * .55), int(W * .2))]
    made.append(fig4_rfe(cube, D, pts, ["sky", "building", "field", "canopy"],
                         out=os.path.join(out, "fig4_rfe.png"), provenance=COMPUTED))
    rec = recoverability_table(
        {f"Gaussian, L = {L}": gaussian_response(L, args.bands) for L in (4, 6, 8)}
        | {"approx RGB (stand-in)": approximate_rgb_response(args.bands)},
        D, K_max=args.k_max, atoms_description="synthetic-scene atoms")
    made.append(fig_recoverability(rec["rows"],
                                   os.path.join(out, "fig_recoverability.png"),
                                   provenance=COMPUTED))
    for p in made:
        print("wrote", p)
    return 0


def cmd_manifest(args) -> int:
    from .provenance import COMPUTED, Manifest

    man = Manifest(args.directory)
    man.capture_environment()
    man.record_tree(args.directory, COMPUTED, "directory snapshot")
    jp, tp = man.write(name=args.name)
    print(open(tp).read())
    return 0


# ------------------------------------------------------------------ parser
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="svrdun", description=_BANNER,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("verify-tables", help="check the published tables for self-consistency")
    s.add_argument("-o", "--output", help="also write table_consistency.json here")
    s.set_defaults(func=cmd_verify_tables)

    s = sub.add_parser("make-configs", help="regenerate every experiment config")
    s.add_argument("-o", "--output", default="configs")
    s.set_defaults(func=cmd_make_configs)

    s = sub.add_parser("make-splits", help="regenerate the SPECIFIED split files")
    s.add_argument("-o", "--output", default="splits")
    s.set_defaults(func=cmd_make_splits)

    s = sub.add_parser("materialise-split", help="apply a split rule to a real directory")
    s.add_argument("dataset", choices=["CAVE", "ICVL", "KAIST", "GF5-GF1"])
    s.add_argument("root", help="directory holding the scene files")
    s.add_argument("-o", "--output")
    s.set_defaults(func=cmd_materialise_split)

    s = sub.add_parser("verify-split", help="check a split file against a directory")
    s.add_argument("split_file")
    s.add_argument("root")
    s.set_defaults(func=cmd_verify_split)

    s = sub.add_parser("run", help="train and evaluate one configuration")
    s.add_argument("-c", "--config", required=True)
    s.add_argument("-o", "--output")
    s.add_argument("--seed", type=int)
    s.add_argument("--epochs", type=int, help="override the config's epoch count")
    s.add_argument("--data-root")
    s.add_argument("--no-resume", action="store_true")
    s.add_argument("--n-train", type=int, default=48, help="synthetic training patches")
    s.add_argument("--n-test", type=int, default=8, help="synthetic test patches")
    s.add_argument("--max-scenes", type=int, default=4, help="real scenes to load")
    s.add_argument("--max-patches", type=int, default=64, help="patches per real scene")
    s.set_defaults(func=cmd_run)

    s = sub.add_parser("cost", help="parameters, FLOPs, inference time, peak memory")
    s.add_argument("-c", "--config", required=True)
    s.add_argument("-o", "--output")
    s.add_argument("--checkpoint")
    s.add_argument("--size", type=int, default=512)
    s.add_argument("--runs", type=int, default=10)
    s.set_defaults(func=cmd_cost)

    s = sub.add_parser("recoverability", help="sigma_min(R D_k) per sensor (Proposition 2)")
    s.add_argument("-o", "--output")
    s.add_argument("--size", type=int, default=256)
    s.add_argument("--bands", type=int, default=31)
    s.add_argument("--k-max", type=int, default=6)
    s.add_argument("--epsilon", type=float, default=0.01)
    s.set_defaults(func=cmd_recoverability)

    s = sub.add_parser("figures", help="motivation figures, no dataset needed")
    s.add_argument("-o", "--output", default="outputs/figures")
    s.add_argument("--size", type=int, default=256)
    s.add_argument("--bands", type=int, default=31)
    s.add_argument("--k-max", type=int, default=6)
    s.set_defaults(func=cmd_figures)

    s = sub.add_parser("manifest", help="hash a directory into a provenance manifest")
    s.add_argument("directory")
    s.add_argument("-n", "--name", default="MANIFEST")
    s.set_defaults(func=cmd_manifest)

    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args) or 0)
    except KeyboardInterrupt:
        print("\ninterrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
