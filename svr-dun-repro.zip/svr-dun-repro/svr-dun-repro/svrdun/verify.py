"""Internal-consistency checks on the published tables.

These checks are DERIVED_REPORTED: the arithmetic is genuine, the inputs are
transcribed from the paper. They answer "are the printed tables consistent with
each other?", not "do the experiments reproduce?".

What can be checked from the paper alone
----------------------------------------
  * Table XIII mean +/- sd recomputed from the per-seed values.
  * Table XIV mean delta recomputed as the difference of Table XIII means.
  * Table XIV confidence intervals contain their point estimate and exclude 0.
  * Table XIV Wilcoxon p-values respect the exact floor that the test-set size
    imposes after Holm correction over 12 comparisons.
  * Table IV: QNR = (1 - D_lambda)(1 - D_s) for SVR-DUN.
  * Table XII: entries with k > L are zero (Proposition 2(b)), and
    sigma_min(R D_k) is non-increasing in k (Proposition 2(c)).

What CANNOT be checked without the original runs
------------------------------------------------
  * The Wilcoxon and paired-t p-values themselves, and the bootstrap intervals.
    Those need the PER-IMAGE values; the paper prints only dataset means per
    seed (Table XIII). `recompute_table_xiv_from_reported` therefore returns
    the delta column only, and marks p-values and CIs as NOT RECOMPUTABLE.
"""
from __future__ import annotations

import statistics as st

from . import reported as R
from .stats import min_achievable_wilcoxon_p

__all__ = ["check_table_xiii", "check_table_xiv_deltas", "check_table_xiv_ci",
           "check_wilcoxon_floors", "check_qnr_components", "check_table_xii",
           "run_all_checks", "format_report"]

_DATASET_OF = {"CAVE": "CAVE", "ICVL": "ICVL", "KAIST": "KAIST"}


def _ok(cond: bool) -> str:
    return "OK" if cond else "MISMATCH"


def check_table_xiii(tol_mean: float = 5e-5, tol_sd: float = 5e-4) -> list[dict]:
    """Recompute every mean +/- sd of Table XIII from its per-seed values."""
    out = []
    methods = R.TABLE_XIII["methods"]
    printed = R.TABLE_XIII["printed_mean_sd"]
    for m, cols in methods.items():
        for key, vals in cols.items():
            mu = st.mean(vals)
            sd = st.stdev(vals)              # sample sd, n-1
            pm, psd = printed[m][key]
            tsd = tol_sd if psd >= 0.01 else 5e-5
            out.append({
                "check": "Table XIII mean/sd",
                "item": f"{m} / {key}",
                "computed": f"{mu:.4f} +/- {sd:.4f}",
                "printed": f"{pm} +/- {psd}",
                "status": _ok(abs(mu - pm) <= tol_mean and abs(sd - psd) <= tsd),
            })
    return out


def check_table_xiv_deltas(tol: float = 5e-5) -> list[dict]:
    """Table XIV mean delta should equal the difference of Table XIII means."""
    name_map = R.baseline_name_map()
    methods = R.TABLE_XIII["methods"]
    svr = methods["SVR-DUN (ours)"]
    out = []
    for row in R.TABLE_XIV["rows"]:
        ds, base_short, metric, delta = row[0], row[1], row[2], row[3]
        base = name_map[base_short]
        key = f"{ds}_{metric}"
        b = st.mean(methods[base][key])
        s = st.mean(svr[key])
        # PSNR higher is better; SAM lower is better
        exp = (s - b) if metric == "PSNR" else (b - s)
        out.append({
            "check": "Table XIV mean delta",
            "item": f"{ds} / {base_short} / {metric}",
            "computed": f"{exp:.4f}",
            "printed": f"{delta:.4f}",
            "status": _ok(abs(exp - delta) <= tol),
        })
    return out


def check_table_xiv_ci() -> list[dict]:
    """Each interval must contain its point estimate and exclude zero."""
    out = []
    for row in R.TABLE_XIV["rows"]:
        ds, base, metric, delta, lo, hi = row[0], row[1], row[2], row[3], row[4], row[5]
        contains = lo <= delta <= hi
        excludes = lo > 0
        out.append({
            "check": "Table XIV interval",
            "item": f"{ds} / {base} / {metric}",
            "computed": f"delta={delta:.4f} in [{lo}, {hi}]",
            "printed": "contains point and excludes 0",
            "status": _ok(contains and excludes),
        })
    return out


def check_wilcoxon_floors(sig: int = 2) -> list[dict]:
    """No adjusted Wilcoxon p may fall below the exact floor for its n.

    The floor is n_comparisons * 2 / 2**n. Printed values are rounded to two
    significant figures, so the comparison is made at that precision.
    """
    out = []
    n_by_ds = R.TABLE_XIV["n_test"]
    for ds, n in n_by_ds.items():
        floor = min_achievable_wilcoxon_p(n, 12)
        floor_r = float(f"{floor:.{sig - 1}e}")
        ps = [r[8] for r in R.TABLE_XIV["rows"] if r[0] == ds]
        worst = min(ps)
        out.append({
            "check": "Wilcoxon exact floor",
            "item": f"{ds} (n={n}, Holm over 12)",
            "computed": f"floor={floor:.4e} (rounds to {floor_r:.1e})",
            "printed": f"smallest printed p={worst:.1e}",
            "status": _ok(worst >= floor_r - 1e-12),
        })
    return out


def check_qnr_components(tol: float = 5e-4) -> list[dict]:
    """QNR = (1 - D_lambda)^a (1 - D_s)^b with a = b = 1, equation (39)."""
    comp = R.TABLE_IV["_svrdun_components"]
    q, dl, ds = comp["QNR"][0], comp["D_lambda"][0], comp["D_s"][0]
    recomputed = (1.0 - dl) * (1.0 - ds)
    return [{
        "check": "QNR = (1-Dl)(1-Ds)",
        "item": "SVR-DUN on GF5-GF1",
        "computed": f"{recomputed:.6f}",
        "printed": f"{q:.4f}",
        "status": _ok(abs(recomputed - q) <= tol),
    }]


def check_table_xii() -> list[dict]:
    """Proposition 2(b): k > L gives zero. 2(c): sigma_min non-increasing in k."""
    out = []
    for row in R.TABLE_XII["rows"]:
        sensor, L = row[0], row[1]
        sig = row[2:8]                       # k = 1..6
        zeros_ok = all(abs(sig[k]) < 1e-12 for k in range(len(sig)) if (k + 1) > L)
        nonincreasing = all(sig[i] >= sig[i + 1] - 1e-12 for i in range(len(sig) - 1))
        out.append({
            "check": "Table XII Prop. 2(b)/(c)",
            "item": f"{sensor} (L={L})",
            "computed": f"zeros beyond k=L: {zeros_ok}; non-increasing: {nonincreasing}",
            "printed": "required by Proposition 2",
            "status": _ok(zeros_ok and nonincreasing),
        })
    return out


NOT_RECOMPUTABLE = [
    {
        "quantity": "Table XIV p (Wilcoxon) and p (paired t)",
        "reason": ("needs the per-image metric values; the paper prints only "
                   "dataset means per seed (Table XIII)"),
        "available_if": "the per-image evaluation CSVs from the original runs are supplied",
    },
    {
        "quantity": "Table XIV 95% bootstrap confidence intervals",
        "reason": "same - the two-level bootstrap resamples test images",
        "available_if": "per-image, per-seed values are supplied",
    },
    {
        "quantity": "Table XIV rank-biserial r",
        "reason": "derived from per-image signed ranks",
        "available_if": "per-image values are supplied",
    },
]


def run_all_checks() -> dict:
    checks = []
    checks += check_table_xiii()
    checks += check_table_xiv_deltas()
    checks += check_table_xiv_ci()
    checks += check_wilcoxon_floors()
    checks += check_qnr_components()
    checks += check_table_xii()
    n_ok = sum(1 for c in checks if c["status"] == "OK")
    return {
        "provenance": "DERIVED_REPORTED",
        "note": ("Internal consistency of the published tables. Genuine "
                 "arithmetic on transcribed inputs; not a reproduction."),
        "n_checks": len(checks),
        "n_ok": n_ok,
        "n_mismatch": len(checks) - n_ok,
        "checks": checks,
        "not_recomputable": NOT_RECOMPUTABLE,
    }


def format_report(result: dict) -> str:
    lines = ["Internal consistency of the published tables",
             f"provenance : {result['provenance']}",
             f"checks     : {result['n_ok']}/{result['n_checks']} OK"
             + (f"   ({result['n_mismatch']} MISMATCH)" if result["n_mismatch"] else ""),
             ""]
    by_check: dict[str, list] = {}
    for c in result["checks"]:
        by_check.setdefault(c["check"], []).append(c)
    for name, items in by_check.items():
        ok = sum(1 for i in items if i["status"] == "OK")
        lines.append(f"  {name}: {ok}/{len(items)} OK")
        for i in items:
            if i["status"] != "OK":
                lines.append(f"      MISMATCH  {i['item']}: "
                             f"computed {i['computed']} vs printed {i['printed']}")
    lines += ["", "Cannot be recomputed from the paper alone:"]
    for nr in result["not_recomputable"]:
        lines.append(f"  - {nr['quantity']}")
        lines.append(f"      why: {nr['reason']}")
        lines.append(f"      needs: {nr['available_if']}")
    return "\n".join(lines)
