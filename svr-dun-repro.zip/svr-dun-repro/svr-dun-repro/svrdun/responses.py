"""Spectral response functions R (L x C).

Three kinds are used in the paper:

  1. Real camera responses (Nikon D700, Canon 60D, and five held-out cameras
     from the database of Jiang et al. [56]). These are MEASURED data and are
     NOT shipped here. `load_response` reads them from a file you supply.

  2. Gaussian sensors, which the paper specifies completely: "MSIs with L bands
     whose responses are Gaussians with equally spaced centres over 400-700 nm
     and a full width at half maximum equal to the centre spacing"
     (Section V-J). `gaussian_response` reproduces these exactly, so the
     Gaussian rows of Table XII are genuinely recomputable.

  3. The GF1 response, estimated from the observations by equation (33).
     `estimate_response_hysure` implements that estimator.

`approximate_rgb_response` builds a plausible broad RGB response. It is a
STAND-IN for plotting and for the QUICK demo path only. It is not the Nikon
D700 and must never be labelled as such; anything computed from it is tagged
accordingly by the caller.
"""
from __future__ import annotations

import numpy as np

__all__ = ["wavelengths", "gaussian_centres", "gaussian_response", "approximate_rgb_response",
           "load_response", "estimate_response_hysure", "shift_response",
           "scale_bandwidth", "normalise_rows", "RESPONSE_REGISTRY"]


def wavelengths(C: int = 31, lo: float = 400.0, hi: float = 700.0) -> np.ndarray:
    """Band centres in nm. CAVE/ICVL use 400-700 nm; KAIST uses 420-720 nm."""
    return np.linspace(lo, hi, C)


def normalise_rows(R: np.ndarray) -> np.ndarray:
    """Scale each band response to unit area, as the paper does for perturbations."""
    R = np.asarray(R, dtype=np.float64)
    s = R.sum(axis=1, keepdims=True)
    s[s == 0] = 1.0
    return R / s


def gaussian_centres(L: int, lo: float = 400.0, hi: float = 700.0
                     ) -> tuple[np.ndarray, float, float]:
    """Design centres, spacing and sigma of the Gaussian sensors of Section V-J.

    Returns (centres, spacing, sigma). The FWHM equals the centre spacing, so
    sigma = spacing / (2*sqrt(2*ln 2)).

    Note that the MEASURED centroid of the first and last band is pulled
    inward because the Gaussian is truncated at the ends of the band grid;
    the design centres below are the ones the paper specifies.
    """
    if L < 1:
        raise ValueError("L must be >= 1")
    if L == 1:
        return np.array([(lo + hi) / 2]), (hi - lo) / 2.0, \
            ((hi - lo) / 2.0) / (2.0 * np.sqrt(2.0 * np.log(2.0)))
    centres = np.linspace(lo, hi, L + 2)[1:-1]
    spacing = float(centres[1] - centres[0])
    sigma = spacing / (2.0 * np.sqrt(2.0 * np.log(2.0)))     # FWHM = spacing
    return centres, spacing, sigma


def gaussian_response(L: int, C: int = 31, lo: float = 400.0, hi: float = 700.0,
                      normalise: bool = True) -> np.ndarray:
    """Exactly the Gaussian sensors of Section V-J.

    "MSIs with L bands whose responses are Gaussians with equally spaced
    centres over 400-700 nm and a full width at half maximum equal to the
    centre spacing."
    """
    wl = wavelengths(C, lo, hi)
    centres, _, sigma = gaussian_centres(L, lo, hi)
    R = np.exp(-0.5 * ((wl[None, :] - centres[:, None]) / sigma) ** 2)
    return normalise_rows(R) if normalise else R


def approximate_rgb_response(C: int = 31, lo: float = 400.0, hi: float = 700.0,
                             normalise: bool = True) -> np.ndarray:
    """A broad 3-band RGB-like response. STAND-IN ONLY - not a real camera.

    Used for the QUICK demo and for plots when no measured response file is
    available. Results obtained with it must not be compared with the paper's
    Nikon D700 numbers.
    """
    wl = wavelengths(C, lo, hi)
    centres = np.array([600.0, 540.0, 460.0])     # R, G, B
    widths = np.array([60.0, 55.0, 50.0])
    R = np.exp(-0.5 * ((wl[None, :] - centres[:, None]) / widths[:, None]) ** 2)
    R += 0.08 * np.exp(-0.5 * ((wl[None, :] - (centres[:, None] - 90)) / 35.0) ** 2)
    R = np.clip(R, 0.0, None)
    return normalise_rows(R) if normalise else R


def load_response(path: str, key: str | None = None, C: int | None = None) -> np.ndarray:
    """Load a measured response from .npy, .npz, .mat or .csv.

    The array must be (L, C) or (C, L); it is returned as (L, C).
    """
    import os
    ext = os.path.splitext(path)[1].lower()
    if ext == ".npy":
        arr = np.load(path)
    elif ext == ".npz":
        z = np.load(path)
        arr = z[key] if key else z[list(z.keys())[0]]
    elif ext == ".mat":
        try:
            from scipy.io import loadmat
            d = loadmat(path)
            cands = {k: v for k, v in d.items() if not k.startswith("__")}
            arr = cands[key] if key else list(cands.values())[0]
        except NotImplementedError:          # MATLAB v7.3 -> HDF5
            import h5py
            with h5py.File(path, "r") as f:
                k = key or list(f.keys())[0]
                arr = np.array(f[k]).T
    elif ext in (".csv", ".txt"):
        arr = np.loadtxt(path, delimiter="," if ext == ".csv" else None)
    else:
        raise ValueError(f"unsupported response file type: {ext}")
    arr = np.asarray(arr, dtype=np.float64)
    if C is not None and arr.shape[0] == C and arr.shape[1] != C:
        arr = arr.T
    elif arr.shape[0] > arr.shape[1]:
        arr = arr.T                          # assume (C, L) given
    return arr


# ------------------------------------------------- perturbations (Table IX)
def shift_response(R: np.ndarray, delta_nm: float, C: int | None = None,
                   lo: float = 400.0, hi: float = 700.0) -> np.ndarray:
    """Shift every band of R by delta_nm, by interpolation on the band grid."""
    R = np.asarray(R, dtype=np.float64)
    C = C or R.shape[1]
    wl = wavelengths(C, lo, hi)
    out = np.empty_like(R)
    for b in range(R.shape[0]):
        out[b] = np.interp(wl, wl + delta_nm, R[b], left=0.0, right=0.0)
    return normalise_rows(out)


def scale_bandwidth(R: np.ndarray, factor: float, C: int | None = None,
                    lo: float = 400.0, hi: float = 700.0) -> np.ndarray:
    """Scale each band's width about its centroid by `factor`."""
    R = np.asarray(R, dtype=np.float64)
    C = C or R.shape[1]
    wl = wavelengths(C, lo, hi)
    out = np.empty_like(R)
    for b in range(R.shape[0]):
        w = R[b]
        tot = w.sum()
        centre = float((wl * w).sum() / tot) if tot > 0 else float(wl.mean())
        src = centre + (wl - centre) / max(factor, 1e-6)
        out[b] = np.interp(src, wl, w, left=0.0, right=0.0)
    return normalise_rows(out)


def estimate_response_hysure(Ym_bs: np.ndarray, Yh: np.ndarray,
                             lambda_s: float = 1e-2) -> np.ndarray:
    """Equation (33): R0 = argmin_{R>=0} ||Ym BS - R Yh||_F^2 + lambda_s ||R D^T||_F^2.

    `Ym_bs` is (L, n) -- the HRMSI degraded to the LRHSI grid.
    `Yh`    is (C, n) -- the LRHSI.
    D is the first-order difference operator along wavelength, which makes each
    band response smooth. Solved as a ridge regression followed by projection
    onto the non-negative orthant (a few projected-gradient passes).
    """
    Ym_bs = np.asarray(Ym_bs, dtype=np.float64)
    Yh = np.asarray(Yh, dtype=np.float64)
    C = Yh.shape[0]
    D = np.zeros((C - 1, C))
    for i in range(C - 1):
        D[i, i], D[i, i + 1] = -1.0, 1.0
    G = Yh @ Yh.T + lambda_s * (D.T @ D)
    Rhat = np.linalg.solve(G.T, (Ym_bs @ Yh.T).T).T
    Rhat = np.maximum(Rhat, 0.0)
    # a few projected gradient steps to respect the non-negativity constraint
    step = 1.0 / (np.linalg.norm(G, 2) + 1e-12)
    for _ in range(200):
        grad = Rhat @ G - Ym_bs @ Yh.T
        Rhat = np.maximum(Rhat - step * grad, 0.0)
    return Rhat


RESPONSE_REGISTRY = {
    "gaussian_L4": lambda C=31: gaussian_response(4, C),
    "gaussian_L6": lambda C=31: gaussian_response(6, C),
    "gaussian_L8": lambda C=31: gaussian_response(8, C),
    "approx_rgb":  lambda C=31: approximate_rgb_response(C),
}
