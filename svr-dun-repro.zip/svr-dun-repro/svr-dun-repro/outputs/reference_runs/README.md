# Reference runs

Committed on purpose, so a fresh clone has something to diff a new run
against. Everything else under `outputs/` is gitignored.

## `quick_seed1_colab_cpu/`

A `QUICK` run of `configs/quick.yaml`, seed 1, executed on Google Colab CPU.

| | |
|---|---|
| provenance | `COMPUTED` — a real run of this code |
| what it is | the smoke path: 6 epochs on the reconstructed Fig. 1 scene |
| what it is **not** | any kind of reproduction of the paper's numbers |
| platform | Linux, Python 3.13, torch 2.14.1+cpu, no GPU |
| run id | `20261109T124219Z` |

Results, for comparison only:

```
training    6 epochs, loss 0.19366 -> 0.04988
evaluation  PSNR 20.08 dB, SAM 10.18, ERGAS 2.85, UIQI 0.560  (8 test images)
budget      lambda_rho 1e-4 -> PSNR 18.92, mean rank 6.00
            lambda_rho 1e-3 -> PSNR 20.08, mean rank 5.97
            lambda_rho 1e-2 -> PSNR 18.59, mean rank 3.97
```

The paper reports 49.46 dB on CAVE. The gap is expected and is not a defect:
this is six epochs of a reference implementation on a synthetic scene. See
[../../docs/GAPS.md](../../docs/GAPS.md).

## Diffing a new run against it

```bash
svrdun run -c configs/quick.yaml --seed 1 -o outputs/my_quick
svrdun manifest outputs/my_quick -n MANIFEST_mine
diff outputs/reference_runs/quick_seed1_colab_cpu/MANIFEST.txt \
     outputs/my_quick/MANIFEST_mine.txt
```

Identical SHA-256 means bit-identical output. What that is worth varies by
artifact type, measured rather than assumed:

| Artifact | Reproduces byte-for-byte? |
|---|---|
| JSON data (`reported_tables.json`, `table_consistency.json`, …) | **yes**, across machines and matplotlib versions |
| `.png` figures | **no** — matplotlib embeds version metadata and renders fonts differently, so two machines produce different bytes from the same data |
| metrics (`evaluation_per_image.json`) | same platform and seed: yes. Across platforms: small floating-point differences are normal |
| `environment.json`, timings | no, by design — they record the machine |

So diff the JSON, and compare figures by eye rather than by hash. A figure
whose underlying data hashes the same is the same figure, whatever the PNG
bytes say.
