"""Paired statistics of Section V-K.

The exact Wilcoxon implementation is checked against SciPy, and the
Holm-adjusted floors are checked against the three the paper states:
5.9e-3 on CAVE (n=12), 2.3e-2 on KAIST (n=10) and 1.8e-12 on ICVL (n=40).
"""
from __future__ import annotations

import numpy as np
import pytest

from svrdun.stats import (
    EXACT_MAX_N,
    holm_bonferroni,
    min_achievable_wilcoxon_p,
    paired_comparison,
    rank_biserial,
    two_level_bootstrap_ci,
    wilcoxon_exact,
)


@pytest.mark.parametrize("n", [6, 8, 10, 12, 15, 20])
def test_exact_wilcoxon_matches_scipy(n):
    scipy_stats = pytest.importorskip("scipy.stats")
    rng = np.random.default_rng(n)
    for _ in range(5):
        d = rng.normal(0.3, 1.0, size=n)
        d = d[d != 0]
        mine = wilcoxon_exact(d)
        assert mine["exact"], "should take the exact path"
        try:
            theirs = float(scipy_stats.wilcoxon(d, alternative="two-sided",
                                                mode="exact").pvalue)
        except TypeError:                       # SciPy >= 1.12 renamed the kwarg
            theirs = float(scipy_stats.wilcoxon(d, alternative="two-sided",
                                                method="exact").pvalue)
        assert mine["p"] == pytest.approx(theirs, abs=1e-12)


@pytest.mark.parametrize("n", [10, 12, 20])
def test_all_positive_gives_the_floor(n):
    """With every difference positive the p-value is exactly 2 / 2**n."""
    d = np.arange(1, n + 1, dtype=float)
    assert wilcoxon_exact(d)["p"] == pytest.approx(2.0 / 2 ** n, rel=1e-12)


def test_paper_floors():
    """The three floors the paper states, recomputed."""
    assert min_achievable_wilcoxon_p(12, 12) == pytest.approx(5.859e-3, rel=1e-3)
    assert min_achievable_wilcoxon_p(10, 12) == pytest.approx(2.344e-2, rel=1e-3)
    assert min_achievable_wilcoxon_p(40, 1) == pytest.approx(1.819e-12, rel=1e-3)
    # the paper prints these rounded to two significant figures
    assert float(f"{min_achievable_wilcoxon_p(12, 12):.1e}") == 5.9e-3
    assert float(f"{min_achievable_wilcoxon_p(10, 12):.1e}") == 2.3e-2


def test_three_seeds_cannot_reach_significance():
    """Section V-K: with three seeds the smallest exact p is 2/2^3 = 0.25."""
    assert wilcoxon_exact(np.array([1.0, 2.0, 3.0]))["p"] == pytest.approx(0.25)


def test_ties_fall_back_to_approximation():
    d = np.array([1.0, 1.0, 1.0, -1.0, 2.0, 2.0])
    assert wilcoxon_exact(d)["method"] == "normal-approx"


def test_degenerate_all_zero():
    assert wilcoxon_exact(np.zeros(5))["p"] == 1.0


def test_large_n_still_exact_up_to_limit():
    d = np.arange(1, EXACT_MAX_N + 1, dtype=float)
    assert wilcoxon_exact(d)["exact"]


def test_rank_biserial_bounds():
    assert rank_biserial(np.array([1.0, 2.0, 3.0])) == pytest.approx(1.0)
    assert rank_biserial(np.array([-1.0, -2.0, -3.0])) == pytest.approx(-1.0)
    assert abs(rank_biserial(np.array([1.0, -1.5, 2.0, -0.5]))) <= 1.0


def test_holm_is_monotone_and_bounded():
    p = [0.001, 0.02, 0.03, 0.04]
    adj = holm_bonferroni(p)
    assert np.all(np.diff(adj[np.argsort(p)]) >= -1e-12), "must be non-decreasing"
    assert np.all(adj <= 1.0)
    assert adj[0] == pytest.approx(4 * 0.001)


def test_holm_single_comparison_is_identity():
    assert holm_bonferroni([0.03])[0] == pytest.approx(0.03)


def test_holm_with_labels():
    out = holm_bonferroni([0.01, 0.2], labels=["a", "b"])
    assert set(out) == {"a", "b"}


def test_bootstrap_interval_contains_point_and_is_ordered():
    rng = np.random.default_rng(0)
    a = rng.normal(1.0, 0.1, size=(12, 3))
    b = rng.normal(0.5, 0.1, size=(12, 3))
    ci = two_level_bootstrap_ci(a, b, n_boot=400, seed=0)
    assert ci["lo"] <= ci["point"] <= ci["hi"]
    assert ci["excludes_zero"]


def test_bootstrap_is_deterministic_for_a_seed():
    rng = np.random.default_rng(1)
    a = rng.normal(1.0, 0.2, size=(8, 3))
    b = rng.normal(0.8, 0.2, size=(8, 3))
    one = two_level_bootstrap_ci(a, b, n_boot=200, seed=42)
    two = two_level_bootstrap_ci(a, b, n_boot=200, seed=42)
    assert one == two


def test_bootstrap_rejects_shape_mismatch():
    with pytest.raises(ValueError):
        two_level_bootstrap_ci(np.zeros((4, 3)), np.zeros((5, 3)), n_boot=10)


def test_paired_comparison_sign_convention():
    """Positive delta must favour the method for both metric directions."""
    better = np.array([2.0, 2.0, 2.0])
    worse = np.array([1.0, 1.0, 1.0])
    hi = paired_comparison(better, worse, "D", "B", "PSNR", higher_is_better=True)
    assert hi.mean_delta > 0 and hi.wins == "3/3"
    lo = paired_comparison(worse, better, "D", "B", "SAM", higher_is_better=False)
    assert lo.mean_delta > 0 and lo.wins == "3/3"
