"""The provenance machinery itself.

If this is wrong, every other guarantee in the repository is only a claim.
"""
from __future__ import annotations

import json
import os

import pytest

from svrdun.provenance import (
    COMPUTED,
    DERIVED_REPORTED,
    REPORTED,
    Manifest,
    save_json,
    sha256_bytes,
    sha256_file,
    sha256_obj,
)


def test_hashes_are_stable_and_order_independent():
    assert sha256_bytes(b"abc") == sha256_bytes(b"abc")
    assert sha256_obj({"a": 1, "b": 2}) == sha256_obj({"b": 2, "a": 1})
    assert sha256_obj({"a": 1}) != sha256_obj({"a": 2})


def test_file_hash_tracks_content(tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("one")
    first = sha256_file(str(p))
    p.write_text("two")
    assert sha256_file(str(p)) != first


def test_record_rejects_an_unknown_tag(tmp_path):
    p = tmp_path / "f.txt"; p.write_text("x")
    with pytest.raises(ValueError):
        Manifest(str(tmp_path)).record(str(p), "MADE_UP")


def test_reported_must_name_its_source(tmp_path):
    p = tmp_path / "f.txt"; p.write_text("x")
    man = Manifest(str(tmp_path))
    with pytest.raises(ValueError):
        man.record(str(p), REPORTED)                       # no source
    man.record(str(p), REPORTED, source="Paper Table III")  # fine


def test_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        Manifest(str(tmp_path)).record(str(tmp_path / "nope"), COMPUTED)


def test_recording_twice_does_not_duplicate(tmp_path):
    p = tmp_path / "f.txt"; p.write_text("x")
    man = Manifest(str(tmp_path))
    man.record(str(p), COMPUTED, "first")
    man.record(str(p), COMPUTED, "second")
    man.record_tree(str(tmp_path), COMPUTED, "tree")
    assert len(man.entries) == 1
    assert man.entries[0].description == "tree", "the later record should win"


def test_paths_are_relative_to_the_root(tmp_path):
    sub = tmp_path / "outputs"; sub.mkdir()
    p = sub / "a.json"; p.write_text("{}")
    man = Manifest(str(tmp_path))
    e = man.record(str(p), COMPUTED)
    assert e.path == os.path.join("outputs", "a.json")
    assert not os.path.isabs(e.path)


def test_manifest_hashes_itself_and_counts_provenance(tmp_path):
    for n, tag, src in (("a.txt", COMPUTED, ""), ("b.txt", REPORTED, "Paper Table V"),
                        ("c.txt", DERIVED_REPORTED, "")):
        (tmp_path / n).write_text(n)
    man = Manifest(str(tmp_path))
    man.capture_environment()
    man.record(str(tmp_path / "a.txt"), COMPUTED)
    man.record(str(tmp_path / "b.txt"), REPORTED, source="Paper Table V")
    man.record(str(tmp_path / "c.txt"), DERIVED_REPORTED)
    jp, tp = man.write()

    payload = json.load(open(jp))
    assert payload["summary"] == {COMPUTED: 1, REPORTED: 1, DERIVED_REPORTED: 1}
    assert len(payload["manifest_sha256"]) == 64
    body = {k: v for k, v in payload.items() if k != "manifest_sha256"}
    assert sha256_obj(body) == payload["manifest_sha256"], "manifest must hash itself"
    text = open(tp).read()
    for tag in (COMPUTED, REPORTED, DERIVED_REPORTED):
        assert tag in text


def test_environment_capture_records_what_reproduction_needs(tmp_path):
    env = Manifest(str(tmp_path)).capture_environment()
    for key in ("platform", "python", "numpy", "scipy", "torch", "gpus",
                "pip_freeze", "utc_time", "run_id"):
        assert key in env, key


def test_save_json_creates_parents(tmp_path):
    p = save_json({"x": 1}, str(tmp_path / "deep" / "nested" / "f.json"))
    assert os.path.exists(p)
    assert json.load(open(p)) == {"x": 1}
