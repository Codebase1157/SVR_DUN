"""Shared pytest configuration."""
import matplotlib

matplotlib.use("Agg")       # never try to open a window in CI
