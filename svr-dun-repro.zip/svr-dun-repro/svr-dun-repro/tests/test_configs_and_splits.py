"""Config validation and split verification.

Both exist to make a silent mistake impossible: a config that quietly
contradicts the paper, or a split that quietly differs from the one a
number was produced with.
"""
from __future__ import annotations

import json
import os

import pytest

from svrdun.configs import (
    CONFIG_VERSION,
    all_configs,
    base_config,
    dataset_config,
    load_config,
    quick_config,
    save_config,
    to_model_config,
    to_train_config,
    validate,
    write_all_configs,
)
from svrdun.splits import (
    CANONICAL_SCENES,
    materialise_split,
    specified_split,
    split_summary,
    verify_split,
    write_specified_splits,
)


# ------------------------------------------------------------------ configs
def test_every_generated_config_is_valid():
    for name, cfg in all_configs().items():
        if name == "base":
            continue                      # base has no dataset or epochs yet
        assert validate(cfg) == [], f"{name}: {validate(cfg)}"


def test_config_count_covers_every_table():
    names = set(all_configs())
    assert {"cave", "icvl", "kaist", "gf5_gf1", "quick", "base"} <= names
    assert sum(n.startswith("ablation_") for n in names) == 9       # A1-A8 + full
    assert sum(n.startswith("sensitivity_") for n in names) == 7    # Table VII
    assert sum(n.startswith("noise_") for n in names) == 10         # Table XI
    assert sum(n.startswith("sensor_gaussian_") for n in names) == 3


def test_validator_rejects_silent_drift():
    cfg = dataset_config("CAVE")
    cfg["model"]["K_max"] = 4
    problems = validate(cfg)
    assert problems and "K_max" in problems[0]


def test_validator_accepts_declared_deviation():
    cfg = dataset_config("CAVE")
    cfg["model"]["K_max"] = 4
    cfg["meta"]["deviates_from_paper"] = ["model.K_max"]
    assert validate(cfg) == []


def test_validator_rejects_wrong_epochs():
    cfg = dataset_config("CAVE")
    cfg["train"]["epochs"] = 10
    assert any("epochs" in p for p in validate(cfg))


@pytest.mark.parametrize("section", ["meta", "model", "data", "train", "eval"])
def test_validator_requires_every_section(section):
    cfg = dataset_config("CAVE")
    del cfg[section]
    assert any(section in p for p in validate(cfg))


def test_validator_rejects_wrong_version():
    cfg = dataset_config("CAVE")
    cfg["config_version"] = CONFIG_VERSION + 1
    assert any("config_version" in p for p in validate(cfg))


def test_round_trip_through_yaml(tmp_path):
    cfg = dataset_config("CAVE")
    p = save_config(cfg, str(tmp_path / "cave.yaml"))
    assert load_config(p) == cfg


def test_load_raises_on_invalid(tmp_path):
    cfg = dataset_config("CAVE")
    cfg["model"]["T"] = 99
    p = save_config(cfg, str(tmp_path / "bad.yaml"))
    with pytest.raises(ValueError):
        load_config(p)


def test_configs_convert_to_runtime_objects():
    for name, cfg in all_configs().items():
        if name in ("base", "gf5_gf1"):
            continue
        m = to_model_config(cfg)
        t = to_train_config(cfg, seed=2)
        assert m.C > 0 and m.K_max > 0 and t.seed == 2


def test_paper_targets_are_tagged_reported():
    for name, cfg in all_configs().items():
        rr = cfg["meta"].get("reported_result")
        if rr and "_provenance" in rr:
            assert rr["_provenance"].startswith("REPORTED")


def test_unstated_fields_carry_a_note():
    cfg = base_config()
    assert any(k.startswith("_note") for k in cfg["model"]), "width/mu must be flagged"
    assert any(k.startswith("_note") for k in cfg["eval"]), "UIQI window must be flagged"


def test_quick_declares_its_deviations():
    q = quick_config()
    assert q["train"]["mode"] == "QUICK"
    assert "train.epochs" in q["meta"]["deviates_from_paper"]
    assert "does not" in q["meta"]["description"].lower() or \
           "not" in q["meta"]["description"].lower()


def test_write_all_configs(tmp_path):
    written = write_all_configs(str(tmp_path))
    assert len(written) >= 40
    assert all(os.path.exists(p) for p in written.values())


# ------------------------------------------------------------------- splits
@pytest.mark.parametrize("ds", ["CAVE", "ICVL", "KAIST", "GF5-GF1"])
def test_specified_split_states_its_rule(ds):
    sp = specified_split(ds)
    assert sp["state"] == "SPECIFIED"
    assert sp["provenance"] == "DERIVED_REPORTED"
    assert sp["rule"]["statement"]
    assert sp["train"] is None and sp["test"] is None


def test_ordering_and_seed_gaps_are_declared():
    cave = specified_split("CAVE")
    assert cave["rule"]["ordering_assumption"]
    assert any("ordering" in c.lower() for c in cave["caveats"])
    icvl = specified_split("ICVL")
    assert icvl["rule"]["seed"] is not None
    assert any("seed" in c.lower() for c in icvl["caveats"])


def test_cave_scene_list_has_32_unique_names():
    scenes = CANONICAL_SCENES["CAVE"]["scenes"]
    assert len(scenes) == 32
    assert len(set(scenes)) == 32


def test_gated_datasets_do_not_assert_scene_names():
    """We must not invent ICVL or KAIST file names."""
    for ds in ("ICVL", "KAIST"):
        assert CANONICAL_SCENES[ds]["scenes"] is None
        assert "NOT listed" in CANONICAL_SCENES[ds]["confidence"]


def _fake_dir(tmp_path, names):
    for n in names:
        (tmp_path / f"{n}.mat").write_text("")
    return [str(tmp_path / f"{n}.mat") for n in names]


def test_materialise_and_verify_cave(tmp_path):
    files = _fake_dir(tmp_path, CANONICAL_SCENES["CAVE"]["scenes"])
    sp = materialise_split("CAVE", files)
    assert sp["state"] == "MATERIALISED"
    assert len(sp["test"]) == 12 and len(sp["train"]) == 20
    assert sp["scene_list_matches_directory"]
    assert verify_split(sp, files)["ok"]
    assert "MATERIALISED" in split_summary(sp)


def test_train_and_test_never_overlap(tmp_path):
    files = _fake_dir(tmp_path, [f"s{i:03d}" for i in range(30)])
    sp = materialise_split("KAIST", files)
    assert not (set(sp["train"]) & set(sp["test"]))
    assert len(sp["test"]) == 10


def test_icvl_random_split_is_seed_deterministic(tmp_path):
    files = _fake_dir(tmp_path, [f"icvl{i:03d}" for i in range(200)])
    a = materialise_split("ICVL", files)
    b = materialise_split("ICVL", files)
    assert a["test"] == b["test"]
    assert len(a["test"]) == 40


def test_verifier_catches_a_tampered_split(tmp_path):
    files = _fake_dir(tmp_path, CANONICAL_SCENES["CAVE"]["scenes"])
    sp = materialise_split("CAVE", files)
    tampered = json.loads(json.dumps(sp))
    tampered["test"] = tampered["test"][:-1]
    out = verify_split(tampered, files)
    assert not out["ok"]
    assert any("sha256" in p for p in out["problems"])


def test_verifier_catches_a_wrong_directory(tmp_path):
    files = _fake_dir(tmp_path, CANONICAL_SCENES["CAVE"]["scenes"])
    sp = materialise_split("CAVE", files)
    other = tmp_path / "other"
    other.mkdir()
    wrong = _fake_dir(other, [f"x{i:02d}" for i in range(32)])
    assert not verify_split(sp, wrong)["ok"]


def test_mismatched_directory_warns(tmp_path):
    files = _fake_dir(tmp_path, [f"scene{i:02d}" for i in range(32)])
    sp = materialise_split("CAVE", files)
    assert sp["scene_list_matches_directory"] is False
    assert sp["warnings"]


def test_wrong_scene_count_warns(tmp_path):
    files = _fake_dir(tmp_path, [f"s{i}" for i in range(5)])
    sp = materialise_split("CAVE", files)
    assert any("32" in w for w in sp["warnings"])


def test_unmaterialised_split_cannot_be_verified():
    out = verify_split(specified_split("CAVE"), [])
    assert not out["ok"]


def test_write_specified_splits(tmp_path):
    written = write_specified_splits(str(tmp_path))
    assert {"CAVE", "ICVL", "KAIST", "GF5-GF1", "README"} <= set(written)
    for k, p in written.items():
        assert os.path.exists(p)
