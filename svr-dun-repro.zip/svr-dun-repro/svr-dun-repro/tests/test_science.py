"""Metrics, rank estimation, recoverability, synthetic scene and the model.

These check the mathematical properties the paper's equations assert, not
accuracy against the published numbers.
"""
from __future__ import annotations

import numpy as np
import pytest

from svrdun.metrics import all_reference_metrics, ergas, psnr, qnr, sam, uiqi
from svrdun.rank import (
    gate,
    local_spectral_rank,
    mean_rank,
    noise_aware_residual,
    ordered_atoms_from_cube,
    rank_cost,
    residual_curve,
    soft_argmin_rank,
    windowed_relative_residual,
)
from svrdun.recover import (
    corollary1_bound,
    recoverability_table,
    recoverable_rank,
    sigma_min_ratio,
    windows_above_rank,
)
from svrdun.responses import (
    approximate_rgb_response,
    estimate_response_hysure,
    gaussian_centres,
    gaussian_response,
    normalise_rows,
    scale_bandwidth,
    shift_response,
    wavelengths,
)
from svrdun.synthetic import endmembers, region_labels, synthetic_scene


# ------------------------------------------------------------------ metrics
def test_identical_cubes_are_perfect():
    rng = np.random.default_rng(0)
    x = rng.random((32, 32, 8)) + 0.1
    assert np.isinf(psnr(x, x))
    assert sam(x, x) == pytest.approx(0.0, abs=1e-5)
    assert ergas(x, x) == pytest.approx(0.0, abs=1e-9)
    assert uiqi(x, x, win=16) == pytest.approx(1.0, abs=1e-6)


def test_psnr_decreases_with_noise():
    rng = np.random.default_rng(1)
    x = rng.random((32, 32, 5)) + 0.1
    vals = [psnr(x, np.clip(x + rng.normal(0, s, x.shape), 0, None))
            for s in (0.005, 0.02, 0.08)]
    assert vals[0] > vals[1] > vals[2]


def test_sam_is_scale_invariant():
    """SAM reports spectral shape only, so a brightness change must not move it."""
    rng = np.random.default_rng(2)
    x = rng.random((16, 16, 10)) + 0.2
    assert sam(x, 2.5 * x) == pytest.approx(0.0, abs=1e-6)


def test_sam_knows_a_right_angle():
    a = np.zeros((1, 1, 2)); a[0, 0, 0] = 1.0
    b = np.zeros((1, 1, 2)); b[0, 0, 1] = 1.0
    assert sam(a, b) == pytest.approx(90.0, abs=1e-6)


def test_ergas_scales_with_the_factor():
    rng = np.random.default_rng(3)
    x = rng.random((16, 16, 4)) + 0.5
    y = x + 0.01
    assert ergas(x, y, scale=4) == pytest.approx(2 * ergas(x, y, scale=8), rel=1e-9)


def test_qnr_matches_the_papers_components():
    assert qnr(0.0071, 0.0096) == pytest.approx(0.9834, abs=5e-5)
    assert qnr(0.0, 0.0) == 1.0


def test_all_reference_metrics_keys():
    rng = np.random.default_rng(4)
    x = rng.random((16, 16, 6)) + 0.1
    assert set(all_reference_metrics(x, x)) == {"PSNR", "ERGAS", "SAM", "UIQI"}


# --------------------------------------------------------------------- rank
def test_atoms_are_orthonormal_and_ordered():
    sc = synthetic_scene(64, 64, 31, seed=0)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    assert D.shape == (31, 6)
    assert D.T @ D == pytest.approx(np.eye(6), abs=1e-9)


def test_residual_identity_of_equation_4():
    """e_k(p) = ||x||^2 - sum_j (d_j^T x)^2, checked against a direct projection."""
    sc = synthetic_scene(32, 32, 31, seed=1)
    cube = sc["cube"]
    D = ordered_atoms_from_cube(cube, 5)
    e, energy = residual_curve(cube, D)
    for k in (1, 3, 5):
        Dk = D[:, :k]
        direct = np.sum((cube - np.einsum("ck,hwk->hwc", Dk,
                                          np.einsum("ck,hwc->hwk", Dk, cube))) ** 2,
                        axis=2)
        assert np.abs(e[..., k] - direct).max() < 1e-8


def test_eps_starts_at_one_and_never_increases():
    sc = synthetic_scene(64, 64, 31, seed=2)
    eps = windowed_relative_residual(sc["cube"], ordered_atoms_from_cube(sc["cube"], 6), w=8)
    assert eps[..., 0] == pytest.approx(1.0, abs=1e-9)
    assert np.all(np.diff(eps, axis=2) <= 1e-9)


def test_local_rank_is_in_range_and_falls_with_tolerance():
    sc = synthetic_scene(64, 64, 31, seed=3)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    strict = local_spectral_rank(sc["cube"], D, delta=1e-4, w=8, K_max=6)
    loose = local_spectral_rank(sc["cube"], D, delta=1e-1, w=8, K_max=6)
    assert strict.min() >= 0 and strict.max() <= 6
    assert loose.mean() <= strict.mean()


def test_noise_aware_residual_is_never_larger():
    """Equation (32) subtracts a floor, so it cannot exceed equation (5)."""
    sc = synthetic_scene(32, 32, 31, seed=4)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    plain = windowed_relative_residual(sc["cube"], D, w=8)
    aware = noise_aware_residual(sc["cube"], D, sigma2=1e-4, w=8)
    assert np.all(aware <= plain + 1e-12)


def test_higher_price_buys_fewer_atoms():
    """The budget knob of equation (15) must be monotone."""
    sc = synthetic_scene(64, 64, 31, seed=5)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    eps = windowed_relative_residual(sc["cube"], D, w=8)
    ranks = [mean_rank(soft_argmin_rank(rank_cost(eps, lam), kappa=1e-3))
             for lam in (1e-4, 1e-3, 1e-2, 1e-1)]
    assert all(a >= b - 1e-9 for a, b in zip(ranks, ranks[1:])), ranks


def test_gate_is_a_soft_step():
    assert gate(np.array([5.0]), 1, tau=0.05)[0] > 0.99
    assert gate(np.array([0.0]), 5, tau=0.05)[0] < 0.01
    assert gate(np.array([2.5]), 3, tau=0.05)[0] == pytest.approx(0.5, abs=1e-6)


# ------------------------------------------------------------- recoverability
def test_proposition_2b_zero_beyond_L():
    sc = synthetic_scene(64, 64, 31, seed=6)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    R3 = gaussian_response(3, 31)
    for k in (4, 5, 6):
        assert sigma_min_ratio(R3, D, k) == 0.0


def test_proposition_2c_non_increasing():
    sc = synthetic_scene(64, 64, 31, seed=7)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    for L in (4, 6, 8):
        sig = [sigma_min_ratio(gaussian_response(L, 31), D, k) for k in range(1, 7)]
        assert all(sig[i] >= sig[i + 1] - 1e-12 for i in range(len(sig) - 1)), (L, sig)


def test_more_bands_never_lowers_the_recoverable_rank():
    sc = synthetic_scene(64, 64, 31, seed=8)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    ranks = [recoverable_rank(gaussian_response(L, 31), D, 0.01, 6) for L in (3, 4, 6, 8)]
    assert all(a <= b for a, b in zip(ranks, ranks[1:])), ranks


def test_recoverability_table_flags_hold():
    sc = synthetic_scene(64, 64, 31, seed=9)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    tbl = recoverability_table({f"G{L}": gaussian_response(L, 31) for L in (4, 6, 8)},
                               D, K_max=6, epsilon=0.01, atoms_description="test")
    assert all(r["zeros_beyond_L"] and r["non_increasing"] for r in tbl["rows"])
    assert tbl["provenance"] == "COMPUTED"


def test_corollary1_diverges_at_near_deficiency():
    sc = synthetic_scene(32, 32, 31, seed=10)
    D = ordered_atoms_from_cube(sc["cube"], 6)
    R4 = gaussian_response(4, 31)
    small = corollary1_bound(R4, D, 3, 0.01, 1.0, 0.01)
    assert np.isfinite(small) and small > 0
    assert np.isinf(corollary1_bound(R4, D, 3, 1e6, 1.0, 0.01))


def test_windows_above_rank():
    rho = np.array([[1.0, 2.0], [5.0, 6.0]])
    assert windows_above_rank(rho, 3) == pytest.approx(50.0)


# ---------------------------------------------------------------- responses
@pytest.mark.parametrize("L", [1, 3, 4, 6, 8])
def test_gaussian_responses_are_normalised_and_shaped(L):
    R = gaussian_response(L, 31)
    assert R.shape == (L, 31)
    assert R.sum(axis=1) == pytest.approx(np.ones(L))
    assert np.all(R >= 0)


@pytest.mark.parametrize("L", [2, 4, 6, 8])
def test_gaussian_design_matches_section_V_J(L):
    """Equally spaced centres over 400-700 nm, FWHM equal to the spacing."""
    centres, spacing, sigma = gaussian_centres(L, 400.0, 700.0)
    assert len(centres) == L
    gaps = np.diff(centres)
    assert gaps == pytest.approx(np.full_like(gaps, spacing), rel=1e-12)
    fwhm = 2.0 * np.sqrt(2.0 * np.log(2.0)) * sigma
    assert fwhm == pytest.approx(spacing, rel=1e-12)
    assert 400.0 < centres[0] and centres[-1] < 700.0


def test_gaussian_peaks_sit_at_their_design_centres():
    """Interior bands peak at the design centre on the sampled grid."""
    L, C = 6, 31
    R = gaussian_response(L, C)
    wl = wavelengths(C)
    centres, _, _ = gaussian_centres(L)
    for b in range(1, L - 1):            # ends are truncated by the grid
        assert abs(wl[int(np.argmax(R[b]))] - centres[b]) <= (wl[1] - wl[0])


def test_shift_and_width_keep_normalisation():
    R = approximate_rgb_response(31)
    assert shift_response(R, 10.0).sum(axis=1) == pytest.approx(np.ones(3))
    assert scale_bandwidth(R, 1.25).sum(axis=1) == pytest.approx(np.ones(3))


def test_hysure_recovers_a_known_response():
    """Equation (33) on noise-free data should recover R closely."""
    rng = np.random.default_rng(11)
    R_true = gaussian_response(3, 31)
    Yh = rng.random((31, 400)) + 0.1
    Ym_bs = R_true @ Yh
    R_hat = estimate_response_hysure(Ym_bs, Yh, lambda_s=1e-6)
    assert np.abs(R_hat - R_true).max() < 5e-2


def test_normalise_rows_handles_zero_rows():
    R = np.zeros((2, 5)); R[0, 0] = 1.0
    assert np.all(np.isfinite(normalise_rows(R)))


# ----------------------------------------------------------------- synthetic
def test_scene_is_deterministic_and_in_range():
    a = synthetic_scene(64, 64, 31, seed=0)["cube"]
    b = synthetic_scene(64, 64, 31, seed=0)["cube"]
    assert np.array_equal(a, b)
    assert a.min() >= 0.0 and a.max() == pytest.approx(1.0)


def test_scene_declares_it_is_a_reconstruction():
    note = synthetic_scene(32, 32, 31)["_provenance_note"].lower()
    assert "reconstruction" in note and "not the authors" in note


def test_endmembers_are_independent():
    E = endmembers(8, 31)
    assert E.shape == (8, 31)
    assert np.linalg.matrix_rank(E) == 8
    assert np.all(E > 0)


def test_regions_separate_under_one_global_rank_2_subspace():
    """The point of Fig. 1: sky fits, the building does not."""
    sc = synthetic_scene(128, 128, 31, seed=0)
    cube, lab = sc["cube"], sc["labels"]
    D2 = ordered_atoms_from_cube(cube, 2)
    e, energy = residual_curve(cube, D2)
    rel = e[..., 2] / np.maximum(energy, 1e-12)
    sky = np.median(rel[lab == 0])
    building = np.median(rel[lab == 1])
    assert sky < building
    assert building / sky > 100, "regions should separate by orders of magnitude"


def test_region_labels_cover_four_regions():
    lab = region_labels(64, 64)
    assert set(np.unique(lab)) == {0, 1, 2, 3}


# --------------------------------------------------------------------- model
@pytest.mark.slow
def test_model_forward_backward_and_budget_monotonicity():
    torch = pytest.importorskip("torch")
    from svrdun.model import SVRDUN, SVRDUNConfig, svrdun_loss

    torch.manual_seed(0)
    cfg = SVRDUNConfig(C=31, L=3, K_max=6, T=3, w=8, s=8, width=16)
    m = SVRDUN(cfg)
    m.ops.set_response(torch.as_tensor(approximate_rgb_response(31), dtype=torch.float32))

    cube = synthetic_scene(64, 64, 31, seed=0)["cube"]
    gt = torch.as_tensor(cube.transpose(2, 0, 1)[None], dtype=torch.float32)
    with torch.no_grad():
        Yh, Ym = m.ops.BS(gt), m.ops.Rop(gt)

    X, rho, aux = m(Yh, Ym, lambda_rho=1e-3, out_hw=(64, 64), return_aux=True)
    assert X.shape == gt.shape
    assert torch.isfinite(X).all()
    assert 0.0 <= float(rho.min()) and float(rho.max()) <= cfg.K_max

    D = aux["D"]
    assert torch.allclose(D.transpose(1, 2) @ D,
                          torch.eye(cfg.K_max).expand(1, -1, -1), atol=1e-4)

    ranks = []
    with torch.no_grad():
        for lam in (1e-4, 1e-3, 1e-2, 1e-1):
            ranks.append(float(m(Yh, Ym, lambda_rho=lam, out_hw=(64, 64))[1].mean()))
    assert all(a >= b - 1e-6 for a, b in zip(ranks, ranks[1:])), ranks

    parts = svrdun_loss(X, gt, Yh, Ym, m.ops, D, 0.1, 0.01)
    parts["loss"].backward()
    grads = [p.grad for p in m.parameters() if p.grad is not None]
    assert grads and all(torch.isfinite(g).all() for g in grads)


@pytest.mark.slow
def test_training_reduces_loss_and_resumes(tmp_path):
    pytest.importorskip("torch")
    from svrdun.data import SyntheticDataset
    from svrdun.model import SVRDUN, SVRDUNConfig
    from svrdun.train import TrainConfig, evaluate_model, train_model

    ds = SyntheticDataset(n_train=12, n_test=4, size=64, C=31, seed=1)
    m = SVRDUN(SVRDUNConfig(C=31, L=3, K_max=6, T=2, w=8, s=8, width=16))
    R = approximate_rgb_response(31)
    cfg = TrainConfig(mode="QUICK", epochs=2, batch_size=4, seed=1, patch=64, scale=8)

    res = train_model(m, ds.train, R, cfg, str(tmp_path), resume=False)
    h = res["history"]
    assert len(h) == 2 and h[-1]["loss"] < h[0]["loss"]

    cfg2 = TrainConfig(mode="QUICK", epochs=4, batch_size=4, seed=1, patch=64, scale=8)
    res2 = train_model(m, ds.train, R, cfg2, str(tmp_path), resume=True)
    assert res2["epochs_run"] == 2, "resume must not retrain finished epochs"

    ev = evaluate_model(m, ds.test, R, lambda_rho=1e-3, scale=8)
    assert ev["n_images"] == 4
    assert set(ev["mean"]) >= {"PSNR", "SAM", "ERGAS", "UIQI"}
    assert ev["provenance"] == "COMPUTED"
