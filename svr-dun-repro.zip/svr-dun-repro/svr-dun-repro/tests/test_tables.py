"""Internal consistency of the published tables.

These are DERIVED_REPORTED checks: genuine arithmetic on transcribed inputs.
They answer "are the printed tables consistent with each other?", not "do the
experiments reproduce?". If one fails, either the transcription in
svrdun/reported.py is wrong or the paper disagrees with itself -- both worth
knowing before anyone tries to reproduce anything.
"""
from __future__ import annotations

import statistics as st

import pytest

from svrdun import reported as R
from svrdun.verify import (
    NOT_RECOMPUTABLE,
    check_qnr_components,
    check_table_xii,
    check_table_xiii,
    check_table_xiv_ci,
    check_table_xiv_deltas,
    check_wilcoxon_floors,
    run_all_checks,
)


def test_all_checks_pass():
    res = run_all_checks()
    failures = [c for c in res["checks"] if c["status"] != "OK"]
    assert not failures, f"{len(failures)} inconsistent: {failures[:3]}"
    assert res["n_checks"] == 70, "the check count changed; update this test"


@pytest.mark.parametrize("fn,expected", [
    (check_table_xiii, 24),
    (check_table_xiv_deltas, 18),
    (check_table_xiv_ci, 18),
    (check_wilcoxon_floors, 3),
    (check_qnr_components, 1),
    (check_table_xii, 6),
])
def test_each_group(fn, expected):
    out = fn()
    assert len(out) == expected
    assert all(c["status"] == "OK" for c in out)


def test_table_xiii_means_recompute():
    for method, cols in R.TABLE_XIII["methods"].items():
        for key, vals in cols.items():
            printed_mean, printed_sd = R.TABLE_XIII["printed_mean_sd"][method][key]
            assert st.mean(vals) == pytest.approx(printed_mean, abs=5e-5)
            tol = 5e-4 if printed_sd >= 0.01 else 5e-5
            assert st.stdev(vals) == pytest.approx(printed_sd, abs=tol)


def test_svrdun_beats_every_baseline_on_every_seed():
    """Section V-K claims this; it is checkable from Table XIII alone."""
    svr = R.TABLE_XIII["methods"]["SVR-DUN (ours)"]
    others = {k: v for k, v in R.TABLE_XIII["methods"].items() if k != "SVR-DUN (ours)"}
    for ds in ("CAVE", "ICVL", "KAIST"):
        for name, m in others.items():
            for i in range(3):
                assert svr[f"{ds}_PSNR"][i] > m[f"{ds}_PSNR"][i], (ds, name, i)
                assert svr[f"{ds}_SAM"][i] < m[f"{ds}_SAM"][i], (ds, name, i)


def test_qnr_equals_its_components():
    c = R.TABLE_IV["_svrdun_components"]
    assert (1 - c["D_lambda"][0]) * (1 - c["D_s"][0]) == pytest.approx(c["QNR"][0], abs=5e-4)


def test_table_xii_obeys_proposition_2():
    for row in R.TABLE_XII["rows"]:
        L, sig = row[1], row[2:8]
        for k in range(len(sig)):
            if k + 1 > L:
                assert sig[k] == 0.0, f"{row[0]}: k={k+1} > L={L} must be zero"
        assert all(sig[i] >= sig[i + 1] - 1e-12 for i in range(len(sig) - 1)), row[0]


def test_every_interval_excludes_zero():
    for row in R.TABLE_XIV["rows"]:
        delta, lo, hi = row[3], row[4], row[5]
        assert lo <= delta <= hi
        assert lo > 0, f"{row[:3]} interval includes zero"


def test_reported_tables_are_tagged():
    for name, tbl in R.ALL_TABLES.items():
        assert tbl.get("_provenance") == R.PROVENANCE or name == "III", name
        assert tbl.get("_source", "").startswith("Paper"), name


def test_known_limits_are_documented():
    """The three columns that cannot be recomputed must stay documented."""
    quantities = " ".join(n["quantity"] for n in NOT_RECOMPUTABLE).lower()
    assert "wilcoxon" in quantities
    assert "confidence interval" in quantities
    assert "rank-biserial" in quantities
    for n in NOT_RECOMPUTABLE:
        assert n["reason"] and n["available_if"]


def test_paper_config_matches_protocol():
    c = R.PAPER_CONFIG
    assert (c["C_bands"], c["scale_s"], c["L_default"]) == (31, 8, 3)
    assert (c["blur_kernel_size"], c["blur_variance"]) == (8, 3.0)
    assert (c["T_stages"], c["K_max"], c["window_w"]) == (5, 6, 8)
    assert c["epochs"] == {"CAVE": 1000, "ICVL": 120, "KAIST": 300}
    assert c["window_w"] == c["scale_s"], "w = s = 8: one window per LRHSI pixel"
