"""The degradation operators of equations (1)-(2).

The adjoint tests matter: equation (14) takes a gradient step through
(BS)^T and R^T, so an operator whose adjoint is wrong trains against the
wrong gradient while still looking plausible. Both bugs this catches were
real -- an even-length Gaussian kernel offsets the naive adjoint, and
F.conv2d is cross-correlation rather than convolution.
"""
from __future__ import annotations

import numpy as np
import pytest

from svrdun.degradation import (
    add_noise_snr,
    apply_BS,
    apply_BS_adjoint,
    apply_R,
    apply_R_adjoint,
    blur_cube,
    blur_cube_adjoint,
    cube_to_matrix,
    downsample,
    gaussian_kernel,
    matrix_to_cube,
    simulate_pair,
)
from svrdun.responses import gaussian_response


def test_gaussian_kernel_normalised():
    k = gaussian_kernel(8, 3.0)
    assert k.shape == (8,)
    assert k.sum() == pytest.approx(1.0)
    assert np.all(k > 0)
    # symmetric about the centre of an even-length kernel
    assert k == pytest.approx(k[::-1])


def test_blur_preserves_mean():
    """A unit-gain blur must not change the DC level."""
    rng = np.random.default_rng(0)
    x = rng.random((32, 32, 4))
    assert blur_cube(x).mean() == pytest.approx(x.mean(), rel=1e-12)


def test_blur_adjoint_is_exact():
    rng = np.random.default_rng(1)
    x = rng.random((32, 32, 3))
    y = rng.random((32, 32, 3))
    lhs = float(np.sum(blur_cube(x) * y))
    rhs = float(np.sum(x * blur_cube_adjoint(y)))
    assert lhs == pytest.approx(rhs, rel=1e-12)


@pytest.mark.parametrize("s", [2, 4, 8])
def test_BS_adjoint_inner_product(s):
    """<BS x, y> == <x, (BS)^T y> to machine precision."""
    rng = np.random.default_rng(2)
    H = W = 8 * s
    x = rng.random((H, W, 5))
    y = rng.random((H // s, W // s, 5))
    lhs = float(np.sum(apply_BS(x, s=s) * y))
    rhs = float(np.sum(x * apply_BS_adjoint(y, s=s, out_hw=(H, W))))
    assert lhs == pytest.approx(rhs, rel=1e-10)


def test_R_adjoint_inner_product():
    rng = np.random.default_rng(3)
    R = gaussian_response(4, 31)
    x = rng.random((16, 16, 31))
    y = rng.random((16, 16, 4))
    lhs = float(np.sum(apply_R(x, R) * y))
    rhs = float(np.sum(x * apply_R_adjoint(y, R)))
    assert lhs == pytest.approx(rhs, rel=1e-12)


def test_downsample_shape_and_stride():
    x = np.arange(16 * 16 * 2, dtype=float).reshape(16, 16, 2)
    d = downsample(x, s=8)
    assert d.shape == (2, 2, 2)
    assert d[0, 0, 0] == x[0, 0, 0]
    assert d[1, 1, 0] == x[8, 8, 0]


def test_simulate_pair_shapes():
    rng = np.random.default_rng(4)
    X = rng.random((64, 64, 31))
    R = gaussian_response(3, 31)
    sim = simulate_pair(X, R, s=8)
    assert sim["Yh"].shape == (8, 8, 31)
    assert sim["Ym"].shape == (64, 64, 3)


def test_noise_free_is_identity():
    x = np.ones((4, 4, 2))
    assert np.array_equal(add_noise_snr(x, None), x)


def test_add_noise_hits_requested_snr():
    rng = np.random.default_rng(5)
    x = rng.random((128, 128, 8))
    for snr in (20.0, 30.0, 40.0):
        y = add_noise_snr(x, snr, np.random.default_rng(0))
        measured = 10 * np.log10(np.mean(x ** 2) / np.mean((y - x) ** 2))
        assert measured == pytest.approx(snr, abs=0.5)


def test_matrix_round_trip():
    rng = np.random.default_rng(6)
    c = rng.random((7, 5, 3))
    assert matrix_to_cube(cube_to_matrix(c), 7, 5) == pytest.approx(c)


def test_torch_and_numpy_operators_agree():
    """The network's operators must match the analysis code exactly."""
    torch = pytest.importorskip("torch")
    from svrdun.model import SVRDUN, SVRDUNConfig

    rng = np.random.default_rng(7)
    cube = rng.random((32, 32, 31))
    m = SVRDUN(SVRDUNConfig(C=31, L=3, s=8)).double()
    m.ops.set_response(torch.as_tensor(gaussian_response(3, 31), dtype=torch.float64))

    t = torch.as_tensor(cube.transpose(2, 0, 1)[None], dtype=torch.float64)
    got = m.ops.BS(t)[0].permute(1, 2, 0).numpy()
    want = apply_BS(cube, s=8)
    assert np.abs(got - want).max() < 1e-9
