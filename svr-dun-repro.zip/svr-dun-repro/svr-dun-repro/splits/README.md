# Split files

Each file fixes a train/test split for one dataset. A file is in one of two
states:

* **SPECIFIED** — the rule, the ordering assumption, the seed and the expected
  counts are fixed, but the file names are not yet known. This is what ships,
  because the datasets are gated and cannot be bundled.
* **MATERIALISED** — the rule has been applied to a real directory, so the file
  names and a SHA-256 over them are fixed. Section 7 of the notebook writes
  this once you set `DATA_ROOT`.

## Two gaps the paper leaves, stated rather than hidden

**Ordering.** The paper says "the last 12 images" (CAVE) and "its last 10
images" (KAIST) without stating an order. These files assume alphabetical order
by scene name. If the authors ordered by the dataset's own numbering, the test
sets differ and the numbers are not comparable.

**ICVL's seed.** The paper draws 40 ICVL scenes "at random" and does not state
a seed, so an exactly matching ICVL split cannot be reconstructed from the
paper. These files record the seed this repository used (20240501). If you have
the authors' split file, use it instead — drop it in here and the notebook will
pick it up.

## Verifying

`svrdun.splits.verify_split` compares a materialised split against a directory
and fails on any mismatch: a different file set, an overlap between train and
test, a test count that contradicts the rule, or a SHA-256 that does not match
the file's own contents. It never silently re-derives a split.
