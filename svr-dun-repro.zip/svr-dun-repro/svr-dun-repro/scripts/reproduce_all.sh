#!/usr/bin/env bash
# Run everything that needs no dataset, then report what it established.
#
#   ./scripts/reproduce_all.sh [OUTPUT_DIR]
#
# For the runs that DO need data, see docs/REPRODUCING.md.
set -euo pipefail

OUT="${1:-outputs/reproduce_all}"
mkdir -p "$OUT"

echo "=== 1/5  tests ==="
pytest -q

echo
echo "=== 2/5  published tables are self-consistent ==="
svrdun verify-tables -o "$OUT"

echo
echo "=== 3/5  configs and splits regenerate identically ==="
svrdun make-configs -o "$OUT/configs" >/dev/null
diff -r --exclude=baselines.yaml configs "$OUT/configs" && echo "  configs: identical"
svrdun make-splits -o "$OUT/splits" >/dev/null
diff -r splits "$OUT/splits" && echo "  splits:  identical"

echo
echo "=== 4/5  recoverability (Proposition 2) ==="
svrdun recoverability -o "$OUT"

echo
echo "=== 5/5  QUICK end-to-end run and figures ==="
svrdun run -c configs/quick.yaml -o "$OUT/quick_run"
svrdun figures -o "$OUT/figures"

echo
svrdun manifest "$OUT" -n MANIFEST_reproduce_all | tail -20
echo
echo "Everything above is COMPUTED or DERIVED_REPORTED on a synthetic scene."
echo "None of it reproduces the paper's accuracy numbers; see docs/GAPS.md."
